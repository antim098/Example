else:
    date_range_schema = get_date_range_schema()
    range_info_schema = get_range_info_schema()
    today = datetime.datetime.strptime('20200304', '%Y%m%d').date()
    default_since_param = config['initial_timestamp']
    survey_start_date = config['survey_start_date']
    survey_start_date = datetime.datetime.strptime(survey_start_date, '%Y%m%d').date()
    month_range_val = config['month_range']

    if ctx.is_incremental:
        partial_conf = partial_configuration.dataframe(
            'previous', schema=partial_configuration.dataframe().schema).toPandas()
        two_month_conf = two_month_configuration.dataframe(
            'previous', schema=two_month_configuration.dataframe().schema).toPandas()
        range_info_df = range_info.dataframe(
            'previous', schema=range_info.dataframe().schema)
        partial_conf = partial_conf[partial_conf.last_updated_time == partial_conf.last_updated_time.max()]
        two_month_conf = two_month_conf[two_month_conf.last_updated_time == two_month_conf.last_updated_time.max()]
    else:
        range_info_df = spark.createDataFrame([], range_info_schema)
        partial_conf = spark.createDataFrame([], date_range_schema).toPandas()
        two_month_conf = spark.createDataFrame([], date_range_schema).toPandas()

    month_range = month_range.dataframe()
    two_month_ingestion_check = False
    partial_ingestion_check = True
    month_range_check = False

    if(bool(month_range.head(1))):
        month_range_pandas = month_range.toPandas()
        max_range_num = int(month_range_pandas['range_num'].max())
        month_range_check = True

    partial_last_updated_time = partial_conf['last_updated_time'].values[0] if (
        partial_conf['last_updated_time']).size > 0 else ''
    two_month_last_updated_time = two_month_conf['last_updated_time'].values[0] if (
        two_month_conf['last_updated_time']).size > 0 else ''

    # Start date for the first time for weekly ingestion
    partial_from_date = (survey_start_date).strftime('%Y%m%d')
    partial_to_date = (today).strftime('%Y%m%d')
    partial_since_date = default_since_param

    if(bool(partial_last_updated_time)):
        date_check = partial_conf['to_date'].values[0]
        if(date_check == (today).strftime('%Y%m%d')):
            partial_ingestion_check = False
        else:
            partial_from_date = '20200101'
            #partial_from_date = partial_conf['from_date'].values[0]

    if(not bool(two_month_last_updated_time)):
        # This conition will be processed when last updated time is empty
        # Checking if we can run the two month ingestion process.
        two_month_ago_date = (today - relativedelta(months=2)).strftime('%Y%m%d')
        two_month_ago_date = datetime.datetime.strptime(two_month_ago_date, '%Y%m%d').date()
        if two_month_ago_date >= survey_start_date:
            logger.info('Two month interval reached for first time.Configuration will be updated')
            two_month_ingestion_check = True
            complete_from_date = survey_start_date.strftime('%Y%m%d')
            complete_to_date = (today.replace(day=1)-relativedelta(days=1)).strftime('%Y%m%d')
            complete_since_date = default_since_param
            # Since new month interval has been encountered.Taking first day of current month as new from date for weekly ingestion
            partial_from_date = (today.replace(day=1)).strftime('%Y%m%d')
        else:
            logger.info('Writing empty dataframe in month configuration,as two month threshold not reached')
            updated_monthly_conf_df = spark.createDataFrame([], date_range_schema)
            two_month_configuration.write_dataframe(updated_monthly_conf_df)
    else:
        previous_to_date_month = datetime.datetime.strptime(
            two_month_conf['to_date'].values[0], '%Y%m%d').strftime('%Y%m')
        month_check = (today - relativedelta(months=2)).strftime('%Y%m')
        if previous_to_date_month >= month_check:
            logger.info('Iterating over the same two months present in configuration as new month interval not reached')
            logger.info('Month ranges are being iterated from month range dataset.')
            #This will now be done by the month range logic
            # Iterating over the same two months as we have not reached new
            # complete_from_date = two_month_conf['from_date'].values[0]
            # complete_to_date = two_month_conf['to_date'].values[0]
            # complete_since_date = datetime.datetime.fromtimestamp(
            #     two_month_last_updated_time).strftime('%Y-%m-%d %H:%M:%S')
        else:
            # Previous two month duration has been completed. Updating the two month interval
            two_month_ingestion_check = True
            logger.info('Changing month interval for ingestion')
            complete_from_date = (today - relativedelta(months=2)).replace(day=1).strftime('%Y%m%d')
            complete_to_date = (today.replace(day=1)-relativedelta(days=1)).strftime('%Y%m%d')
            complete_since_date = default_since_param
            # Since new month interval has been encountered.Taking first day of current month as new from date for weekly ingestion
            partial_from_date = today.replace(day=1).strftime('%Y%m%d')

    json_string_partial = []
    json_string_complete = []
    monthly_conf =[]
    logger.info('LOG::ingest_cb_response_function: since_timestamp: ' + str(default_since_param))
    input_schema = getInputSchema()
    scroll = ''
    epoch = int(time.time())
    if partial_ingestion_check == True:
        json_string_partial, total_count, epoch = get_cb_data_in_json(partial_from_date, partial_to_date, partial_since_date, baseurl, headers, json_string_partial)
        # while True:
        #     params = {'scroll': scroll} if len(scroll) > 0 else {}
        #     query_part = generateSinceQuery(partial_from_date, partial_to_date, partial_since_date)
        #     url = baseurl + "?" + query_part
        #     page_size, total_count, scroll, sentence_json = getExportFromCB(url, params, headers)
        #     json_string_data = getJsonString(sentence_json)
        #     json_string_partial.extend(json_string_data)
        #     if page_size == 0:
        #         epoch = int(time.time())
        #         break
        if(len(json_string_partial) > 0):
            epoch = epoch - config['since_param_time_adjustment']
            count = int(total_count)
            data = [(partial_from_date, partial_to_date, partial_since_date, epoch, count)]
            updated_partial_conf_df = spark.createDataFrame(data, date_range_schema)
            partial_configuration.write_dataframe(updated_partial_conf_df)

    if two_month_ingestion_check == True:
        scroll = ''
        while True:
            params = {'scroll': scroll} if len(scroll) > 0 else {}
            query_part = generateSinceQuery(complete_from_date, complete_to_date, complete_since_date)
            url = baseurl + "?" + query_part
            page_size, total_count, scroll, sentence_json = getExportFromCB(url, params, headers)
            json_string_data = getJsonString(sentence_json)
            json_string_complete.extend(json_string_data)
            if page_size == 0:
                epoch = int(time.time())
                break
        if(len(json_string_complete) > 0):
            epoch = epoch - config['since_param_time_adjustment']
            count = int(total_count)
            data = [(complete_from_date, complete_to_date, complete_since_date, epoch, count)]
            monthly_conf.extend(data)

    if month_range_check == True:
        range_info_df = range_info_df.toPandas()
        range_num_reached = range_info_df['range_num'].values[0] if (
            range_info_df['range_num']).size > 0 else int(0)
        if(range_num_reached != max_range_num):
            range_num_reached += 1
            logger.info('Ingesting data for month ranges with range_num = %s' % range_num_reached)
            from_date = month_range_pandas.loc[month_range_pandas['range_num'] == str(range_num_reached), 'from_date'].iloc[0]
            to_date = month_range_pandas.loc[month_range_pandas['range_num'] == str(range_num_reached), 'to_date'].iloc[0]
            last_updated_time = month_range_pandas.loc[month_range_pandas['range_num'] == str(range_num_reached), 'last_updated_time'].iloc[0]
            since_date = datetime.datetime.fromtimestamp(
                int(last_updated_time)).strftime('%Y-%m-%d %H:%M:%S')
            json_string_complete, total_count, epoch = get_cb_data_in_json(from_date, to_date, since_date, baseurl, headers, json_string_complete)
            if(len(json_string_complete) > 0):
                epoch = epoch - config['since_param_time_adjustment']
                count = int(total_count)
                data = [(from_date, to_date, since_date, epoch, count)]
                monthly_conf.extend(data)

            range_info_df = spark.createDataFrame([(range_num_reached,)], schema=range_info_schema)
            range_info.set_mode('replace')
            range_info.write_dataframe(range_info_df)
        else:
            logger.info('Ingestion for all range numbers is already done. Replacing range_info dataframe')
            range_info_df = spark.createDataFrame([], schema=input_schema)
            range_info.set_mode('replace')
            range_info.write_dataframe(range_info_df)

    updated_monthly_conf_df = spark.createDataFrame(monthly_conf, date_range_schema)
    two_month_configuration.write_dataframe(updated_monthly_conf_df)

    # Merging all the lists contating json data to write in final output
    json_string_partial.extend(json_string_complete)
    final_json_string = json_string_partial
    df = spark.createDataFrame(final_json_string, schema=input_schema)
    final_df = df.withColumn('ingestion_hour', lit(time.strftime("%Y-%m-%d-%H")))
    final_df = df.withColumn('partition_month', lit(time.strftime("%Y-%m")))
    output.set_mode('replace')
    output.write_dataframe(final_df)


def get_cb_data_in_json(from_date, to_date, since_date, baseurl, headers, json_string):
    scroll = ''
    while True:
        params = {'scroll': scroll} if len(scroll) > 0 else {}
        query_part = generateSinceQuery(from_date, to_date, since_date)
        url = baseurl + "?" + query_part
        page_size, total_count, scroll, sentence_json = getExportFromCB(url, params, headers)
        json_string_data = getJsonString(sentence_json)
        json_string.extend(json_string_data)
        if page_size == 0:
            epoch = int(time.time())
            break
    return json_string, total_count, epoch


def getJsonString(sentence_json):
    json_string = []
    for item in sentence_json:
        attributes = item['attributes']
        stringify_attributes = str(json.dumps(attributes))
        item['attributes'] = stringify_attributes
        classification = item['classifications']
        stringify_classification = str(json.dumps(classification))
        item['classifications'] = stringify_classification
        classification_timestamp = item['classification_timestamps']
        stringify_classification_timestamp = str(json.dumps(classification_timestamp))
        item['classification_timestamps'] = stringify_classification_timestamp
        json_string.append(item)
    return json_string


def generateSinceQuery(from_date, to_date, since_timestamp):
    since_date = since_timestamp.replace(" ", "%20")
    query = "_doc_time:%5B" + from_date + \
        "000000 TO " + \
        to_date + "235959%5D" + \
        "&since=" + since_date

    return query


def getExportFromCB(url, params, headers):
    logger.info('LOG:getExportFromCB: URL: ' + url)
    logger.info('LOG:getExportFromCB: params: ' + json.dumps(params))
    response = requests.get(url, params=params, verify=False, headers=headers)
    try:
        payload = json.loads(response.content)
        scroll = payload['scroll_id']
        page_size = payload['page_size']
        total_count = payload['total_count']
    except Exception as e:
        logger.info('LOG:getExportFromCB:: error while parsing payload ' + str(response.content))
        logger.info('LOG:getExportFromCB:: Error ' + repr(e))
        raise errors.InternalError("Exception:getExportFromCB: Unable to pase response data into valid valid response")
    return page_size, total_count, scroll, payload['sentences']


def getInputSchema():
    input_schema = T.StructType([
        T.StructField('attributes', T.StringType(), True),
        T.StructField('autodetected_language', T.StringType(), True),
        T.StructField('classifications', T.StringType(), True),
        T.StructField('classification_timestamps', T.StringType(), True),
        T.StructField('content_subtype', T.StringType(), True),
        T.StructField('content_type', T.StringType(), True),
        T.StructField('document_date', T.StringType(), True),
        T.StructField('document_id', T.LongType(), True),
        T.StructField('natural_id', T.StringType(), True),
        T.StructField('processed_language', T.StringType(), True),
        T.StructField('sentence_end_pos', T.LongType(), True),
        T.StructField('sentence_id', T.LongType(), True),
        T.StructField('sentence_start_pos', T.LongType(), True),
        T.StructField('cb_date_updated', T.LongType(), True),
        T.StructField('created_date', T.LongType(), True),
        T.StructField('sentence', T.StringType(), True),
        T.StructField('sentiment', T.DoubleType(), True),
        T.StructField('session_id', T.LongType(), True),
        T.StructField('source', T.StringType(), True),
        T.StructField('verbatim_id', T.LongType(), True),
        T.StructField('verbatim_type', T.StringType(), True)
    ])
    return input_schema


def get_date_range_schema():
    date_range_schema = T.StructType([
               T.StructField('from_date', T.StringType(), True),
               T.StructField('to_date', T.StringType(), True),
               T.StructField('since_date', T.StringType(), True),
               T.StructField('last_updated_time', T.LongType(), True),
               T.StructField('count', T.IntegerType(), True)])
    return date_range_schema


def getConfigurationSchema():
    configuration_schema = T.StructType([
               T.StructField('since_timestamp', T.StringType(), True),
               T.StructField('last_updated_time', T.LongType(), True),
               T.StructField('count', T.IntegerType(), True)])
    return configuration_schema


def get_range_info_schema():
    range_info_schema = T.StructType([
               T.StructField('range_num', T.StringType(), True)])
    return range_info_schema
