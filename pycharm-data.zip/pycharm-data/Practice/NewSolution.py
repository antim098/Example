import json,re,ast

jsonString = {   "tns3:RcptOutp\tutEvent":
            {     "Txn\"Id": "Txn-8e5\c0d35-de37-42d\9\"-8e93-a27f600aacfa",
                  "Rc\p\Data": {       "RcptId": "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa",
                                      "Text": "Your personal data will be p\"rocessed in accordance with the applicable carriers privacy policy and if your booking is made via a reservation system provider (\"GDS\"), "
                                              "with its privacy policy. These are available at"     }   } }

print("string json",jsonString.__str__())
newStr = jsonString.__str__()

slashString = newStr.replace("\\\\", '*')
new = re.sub("[\\\]", '', slashString).replace('*',"\\")
#n = re.sub("\\\\", '*',new)
#print("....",n)
print("value of new",new)

Dict = ast.literal_eval(new)
print("Dict", new)

jsonStr = json.dumps(Dict)
print("jsonStr ",jsonStr)

jsonObj = json.loads(jsonStr)
print(jsonObj.get('tns3:RcptOutptutEvent'))

text =str (jsonObj.get('tns3:RcptOutptutEvent'))
print("....",text)
fo = open("foo.txt", "r+")
fo.write(str(jsonObj.get('tns3:RcptOutptutEvent')))