import json



class FlattenJson3:

    def __init__(self): pass


def merge(dict1, dict2):
    dict3 = dict1.copy()
    dict3.update(dict2)
    return dict3


aCount = 0


def flatten_cAttachments(x, name=''):
    global aCount
    if type(x) is dict:
        for a in x:
            flatten_cAttachments(x[a], a)
    elif type(x) is list:
        if name in {'cases', 'correspondence', 'attachments'}:
            print(temp)
            if name == 'attachments':
                # print(temp['correspondenceId'])
                data = {'ccaiCaseId': caseId, 'correspondenceId': temp['correspondenceId']}
                length = x.__len__()
                for a in x:
                    flatten_cAttachments(a, name)
                    aCount += 1
                    data.update(temp)
                    if aCount <= length:
                        cAttachmentsList.append(data)
            else:
                flatten_cAttachments(a, name)
    else:
        temp[name] = x


cCount = 0


def flatten_correspondence(x, name=''):
    global cCount
    global aCount
    if type(x) is dict:
        for a in x:
            flatten_correspondence(x[a], a)
    elif type(x) is list:
        if name in {'cases', 'correspondence'}:
            temp.clear()
            length = x.__len__()
            for a in x:
                flatten_correspondence(a, name)
                cCount += 1
                data = dict(temp)
                data['ccaiCaseId'] = caseId
                temp.clear()
                if cCount <= length:
                    correspondenceList.append(data)
    else:
        temp[name] = x


notesCount = 0


def flatten_notes(x, name=''):
    global notesCount
    if type(x) is dict:
        for a in x:
            flatten_notes(x[a], a)
    elif type(x) is list:
        if name in {'notes'}:
            temp.clear()
            length = x.__len__()
            for a in x:
                flatten_notes(a, name)
                notesCount += 1
                data = dict(temp)
                data['ccaiCaseId'] = caseId
                temp.clear()
                if notesCount <= length:
                    notesList.append(data)
    else:
        temp[name] = x


passengerCount = 0


def flatten_passenger(x, name=''):
    global passengerCount
    if type(x) is dict:
        for a in x:
            flatten_passenger(x[a], a)
    elif type(x) is list:
        if name in {'passengers'}:
            temp.clear()
            length = x.__len__()
            for a in x:
                flatten_passenger(a, name)
                passengerCount += 1
                data = dict(temp)
                temp.clear()
                if passengerCount <= length:
                    passengerList.append(data)
    else:
        temp[name] = x


tripCount = 0
recordIndex = 0
backup = {}


def flatten_tripdata(x, name=''):
    global tripCount
    global recordIndex
    global backup
    if type(x) is dict:
        for a in x:
            flatten_tripdata(x[a], a)
    elif type(x) is list:
        if name in {'tripSegments'}:
            if recordIndex == 0:
                backup = dict(temp)
            length = x.__len__()
            for a in x:
                flatten_tripdata(a, name)
                tripCount += 1
                data = dict(temp)
                if tripCount <= length:
                    tripsList.append(data)
                else:
                    tripCount = 0
                    recordIndex += 1
                    temp.clear()
                    temp.update(backup)

        elif name in {'passengerIds'}:
            temp[name] = x
    else:
        temp[name] = x


if __name__ == "__main__":
    with open('latest.json', 'r') as fh:
        jsonDict = json.load(fh)
        tripsList = list()
        passengerList = []
        notesList = []
        resultList = []
        correspondenceList = []
        cAttachmentsList = []
        temp = {}
        caseId = ''
        #flatten_tripdata(jsonDict)
        # Extracting the case id from the trip records
       # caseId = tripsList[0].get('id')
        #flatten_cAttachments(jsonDict)
        flatten_notes(jsonDict)
        # flatten_correspondence(jsonDict)
        # flatten_cAttachments(jsonDict)
        # for Dict in passengerList:
        #     Dict['passenger_type'] = Dict['_type']
        #     del Dict['_type']

        # for y in cAttachmentsList:
        #     print(y)

        # for tripRecord in tripsList:
        #     for passengerRecord in passengerList:
        #         resultList.append(merge(tripRecord, passengerRecord))
        #
        # for record in resultList:
        #     print(record)
        if len(notesList) == 0:
            print("yes")
