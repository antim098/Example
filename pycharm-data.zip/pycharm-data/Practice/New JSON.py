import json,re

read = {   "tns3:Rc\ptOut\putEve(\"sast\")": {     "TxnId": "Txn-8e\sa5c0d\35-de37-42d9-8e93-a27\f600aacfa",     "RcptData": {       "RcptId": "Rcpt-(\"sast\")8e5c0d35-de37-42d9-8e93-a27f600aacfa",       "Text": "Your personal data will be processed in accordance with the applicable carriers privacy policy and if your booking is made via a reservation system provider (\"GDS\"), with its privacy policy. These are available at"     }   } }
s =input("Please enter JSON Data")
print("Data given in Input " ,s)

sample_json ={"tns3":"Rc\ptOut\putEve(\"sast\")"}

strjson = sample_json.__str__()

data = re.sub('[\\\]', '', strjson)



print(data)

jsonstring = json.dumps(sample_json)

jsonObj = json.loads(jsonstring)
output = jsonObj['tns3']



valid_data = re.sub('[\\\]', '', s)

#valid = re.sub('[\\\]', '', read)

#valid_data = s.replace("\\'", '"')
#line = s.translate(None, '\\')
print(valid_data)



#s = re.sub('\"GDS\"', '\ms\\"GDS\\\"', s)
#s = s.replace("\'", '"')
#print("New JSON String",s)

#dumpJSON = json.dumps(s)
#dumpJSON = dumpJSON.replace("\'", '"')
#JSON = json.loads(dumpJSON)
#print(JSON)

#sources = JSON['tns3:RcptOutputEvent']
#print("JSON OUTPUT",sources)
#print("Value of TxnId",sources['TxnId'])