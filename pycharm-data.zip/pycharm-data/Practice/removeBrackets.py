


a = str([{'booleanOperator': ['OR'], 'docType': 'criteria', 'value': 'es_AR', 'criteriaId': 'mc123', 'criteria': 'feedbackCategory', 'comparativeOperator': 'CONTAINS', 'type': 'matchCriteria'}, {'booleanOperator': 'OR', 'docType': 'criteria', 'value': 'es_AR', 'criteriaId': 'mc123', 'criteria': 'iPosIndicator', 'comparativeOperator': 'EQ', 'type': 'matchCriteria'}, {'booleanOperator': 'OR', 'docType': 'criteria', 'value': 'es-AR', 'criteriaId': 'mc123', 'criteria': 'iPosIndicator', 'comparativeOperator': 'CONTAINS', 'type': 'matchCriteria'}])

print(a)

a = a.strip('[]')

print(a)


a = []

if a is not None:
    print('not none')
else:
    print('none')

inputString ='qbcddfafafadfad'
inputString += '=' * (-len(inputString) % 4)
print(inputString)