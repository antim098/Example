import json,re,codecs
import ast



s = {   "tns3:RcptOutp\tutEvent":
            {     "Txn\"Id": "Txn-8e5\c0d35-de37-42d\9-8e93-a27f600aacfa",
                  "Rcp\Data": {       "Rcp\btId": "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa",
                                      "Text": "Your personal data will be p\"rocessed in accordance with the applicable carriers privacy policy and if your booking is made via a reservation system provider (\"GDS\"), "
                                              "with its privacy policy. These are available at"     }   } }


stringJSON = s.__str__()
print("Original String", stringJSON)


decoded = stringJSON.encode().decode('unicode_escape')
print("decoded :",decoded)


dict = eval(decoded)
print("Dictionary", dict)


data = json.dumps(dict)
print(data)

jsonString = eval(data)
#loadedJson = json.loads(decoded)