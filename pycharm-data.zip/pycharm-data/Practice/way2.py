import re,json



s = {   "tns3:Rc\\ptOutputEv\tent": {     "Txn\Id": "Txn-8e5c0d35-de37-42d9-8e\93-a2\7f600aacfa",     "RcptData": {       "RcptId": "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa",       "Text": "Your personal data will be processed in accordance with the applicable carriers privacy policy and if your booking is made via a reservation system provider (\"GDS\"), with its privacy policy. These are available at"     }   } }

#print(s)
stringJSON = s.__str__()
print("After Converting to string", stringJSON)
data = re.sub("[\s+']+", '', stringJSON)
print("After removing escape characters", data)
newdata = eval(data)
print("After Eval :", newdata)
jsonObj = json.loads(json.dumps(newdata))
print("Final Output is here: ",jsonObj.get('tns3:RcptOutputEvent'))