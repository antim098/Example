import json,re,ast


s = {   "tns3:RcptOutputEvent":
            {     "TxnId": "Txn-8e5c0d35-de37-42d9-8e93-a27f600aacfa",
                  "RcptData": {       "RcptId": "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa",
                                      "Text": "Your pers\onal data w\ill be processed in accordance with the applicable carriers privacy policy and if your booking is made via a reservation system provider (\"GDS\"), "
                                              "with its privacy policy. These are available at"     }   } }

print(s)
#jsonObj = json.loads(json.dumps(s))
keys_list = s.keys()
values_list = s.values().__str__()
print("list of values :",values_list)
formatted_values = re.sub('[\\\]', '', values_list)
print("after formatting :",formatted_values)
final_dict = [keys_list,formatted_values]
print(final_dict)
d = {(key, value) for (key, value) in formatted_values}
print("Dict is :" ,d)
#formatted_dict = dict(zip(keys_list,val))
#print(formatted_dict)








#print("New value is ",s)