import datetime

from pytz import timezone


def getGMTDateTime(inputString, reqField):
    if inputString is not None and len(inputString) > 9:

        try:
            formatted_GMT = str(datetime.datetime.strptime(inputString, '%Y-%m-%dT%H:%M:%SZ'))
            if reqField == 'date':
                return formatted_GMT.split(" ")[0]
            else:
                return formatted_GMT.split(" ")[1]
        except:
            return ''
    else:
        return ''


def getCSTDateTime(inputString, reqField):
    central = timezone('US/Central')
    utc = timezone('utc')
    if inputString is not None and len(inputString) > 9:
        try:
            formatted_CST = str(utc.localize(datetime.datetime.strptime(
                inputString, '%Y-%m-%dT%H:%M:%SZ')).astimezone(central))
            if reqField == 'date':
                return formatted_CST.split(" ")[0]
            elif reqField == 'dateTime':
                return formatted_CST[:-6]
            else:
                return formatted_CST.split(" ")[1].split("-")[0]
        except:
            return ''

    else:
        return ''
