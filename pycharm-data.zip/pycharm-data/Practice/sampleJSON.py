import json,re,codecs
import ast



json_input = {   "tns3:RcptOutp\tutEvent":
            {     "Txn\"Id": "Txn-8e5\c0d35-de37-42d\9\"-8e93-a27f600aacfa",
                  "R\cp\Data": {       "RcptId": "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa",
                                      "Text": "Your personal data will be p\"rocessed in accordance with the applicable carriers privacy policy and if your booking is made via a reservation system provider (\"GDS\"), "
                                              "with its privacy policy. These are available at"     }   } }

j = {"Txn\"Id": "Txn-8\e5\tc0d35-\nde37-42d\9-8\re93-a27f600aacfa"}

print ("normal j",j)
print("string j",j.__str__())
newStr = j.__str__()

snt="aaa\n\t\n a\"sd123a\esd water's tap413 water blooe's"

"".join(re.findall("[^\\\"\n\t\d:.,]+",newStr))
print(j)

s = "aaa\n\t\n\'asd123asd water's tap413 water blooe's"
p = json_input.__str__()
print("p is",p)
replaced = re.sub("[^\\\\][^a-zA-Z0-9{}\-\" :,()@#$%&*'][^\\\\]", '',json_input.__str__())
print("replaced is ", replaced)



jsonStr = json.dumps(eval(replaced))
print("jsonStr",jsonStr)
loadedJson = json.dumps(jsonStr)
print("json loaded",loadedJson)

#print(''.join(p.split()))

#data = ''.join(c for c in p if not c.isspace())

#print("Data is ",data)
r"[\n\t\s]*"

#newData  = re.sub(r'[\n\t\s]*', '', newStr)
#print("New Data is :", newData)


#str = '\"'
#print(str)
#new = re.sub("[^a-zA-Z0-9{}\-\" :,()\\\\']", '', p)
#n = re.sub("\\\"", '"',new)
#print("....",new)








