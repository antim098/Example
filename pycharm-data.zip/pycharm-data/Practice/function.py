from func import print_func


# Function definition is here
def changeme( mylist ):
   "This changes a passed list into this function"
   mylist = [1,2,3,4] # This would assi new reference in mylist
   print ("Values inside the function: ", mylist)
   return mylist

# Now you can call changeme function
mylist = [10,20,30]
print("changed version",changeme( mylist ))
print ("Values outside the function: ", mylist)
print(mylist==mylist)


# Function definition is here
sum = lambda arg1, arg2, antim: ((arg1 + arg2)-antim)

# Now you can call sum as a function
print ("Value of total : ", sum( 10, 20,10))
print ("Value of total : ", sum( 20, 20 ,30))


length = lambda arg1,arg2 :(str(arg1).__len__()-str(arg2).__len__())*10
print(length("antim","kant"))

print(print_func("antim"))


def temp_convert(var):
   try:
      return int(var)
   except ValueError as Argument:
      print ("The argument does not contain numbers\n", Argument)

# Call above function here.
temp_convert("xyz")




Money = 2000
def AddMoney():
   # Uncomment the following line to fix the code:
   global Money
   Money= Money + 1

print (Money)
AddMoney()
print (Money)