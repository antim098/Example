import json
import pandas as pd

class FlattenJson:

    def __init__(self): None


def merge(dict1, dict2):
    dict1.update(dict2)
    return dict1


passengerCount = 0


def flatten_passenger(x, name=''):
    global passengerCount
    if type(x) is dict:
        for a in x:
            flatten_passenger(x[a], a)
    elif type(x) is list:
        if name in {'cases', 'passengers'}:
            temp.clear()
            length = x.__len__()
            for a in x:
                flatten_passenger(a, name)
                passengerCount += 1
                data = dict(temp)
                temp.clear()
                if passengerCount <= length:
                    passengerList.append(data)
    else:
        temp[name] = x


tripCount = 0


def flatten_tripdata(x, name=''):
    global tripCount
    if type(x) is dict:
        for a in x:
            flatten_tripdata(x[a], a)
    elif type(x) is list:
        if name in {'cases', 'tripSegments'}:
            # if i in {0, 1, 2}:
            length = x.__len__()
            for a in x:
                tripCount = 0
                flatten_tripdata(a, name)
                tripCount += 1
                data = dict(temp)
                if tripCount <= length:
                    tripsList.append(data)
        else:
            temp[name] = x
    else:
        temp[name] = x


if __name__ == "__main__":
    with open('samplejson5_14.json', 'r') as fh:
        jsonDict = json.load(fh)
        tripsList = []
        passengerList = []
        resultList = []
        temp = {}

        # flatten_tripdata(jsonDict)
        # flatten_passenger(jsonDict)
        #
        # for Dict in passengerList:
        #     Dict['passenger_type'] = Dict['_type']
        #     del Dict['_type']
        #
        # for x in tripsList:
        #     print(x)
        #
        # for tripRecord in tripsList:
        #     for passengerRecord in passengerList:
        #         resultList.append(merge(tripRecord, passengerRecord))
        #
        # for record in resultList:
        #     print(record)

    data = {
        'A': ['A1', 'A2', 'A3', 'A4', 'A5'],
        'B': ['B1', 'B2', 'B3', 'B4', 'B4'],
        'C': ['C1', 'C2', 'C3', 'C3', 'C3'],
        'D': ['D1', 'D2', 'D2', 'D2', 'D2'],
        'E': ['E1', 'E1', 'E1', 'E1', 'E1']}

    df = pd.DataFrame(data)
    unique = list(df['E'].unique())
    print(unique)
    print(type(unique))