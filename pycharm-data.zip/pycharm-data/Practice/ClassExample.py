class Employee:
  empCount = 0
  def __init__(self,name, salary):
    self.name = name
    self.salary = salary
    Employee.empCount += 1

  def displayCount(self):
    empCount = 1
    print("Total Employee %d" % Employee.empCount)

  def displayEmployee(self):
    print("Name : ", self.name, ", Salary: ", self.salary)





class SubClass(Employee):
  empCount = 10
  def __int__(self):
        print("Sub class constructor")

  def displaydata(self):
    print(self.empCount)



# This would create first object of Employee class"
#emp1 = Employee("Zara", 2000)
# This would create second object of Employee class"
#emp2 = Employee("Manni", 5000)
#emp1.displayEmployee()
#emp2.displayEmployee()

s = SubClass()
s.displaydata()
