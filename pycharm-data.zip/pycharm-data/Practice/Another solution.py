case_df = case_input.dataframe()
if not case_df.rdd.isEmpty:
    session = ctx.spark_session
    # defining partitioning column for the output dataset
    partition_col = ['date_created_gmt_month']
    # case_input is representing the dataset consisting latest enriched json records.
    case_df = case_input.dataframe()
    metadata_df = metadata.dataframe().toPandas()
    # using the metadata dataset to extract column names required in output
    schema = metadata_df['INPUTCOLUMNNAME'].tolist()
    latest_version_deltadf = helper.get_casedraft_parsed(case_df, parser, session)
    # Applying the parsing function to every record of the case_df
    case_df = latest_version_deltadf.rdd.map(lambda x: parser.parse_data(json.loads(x['copilot_enrichedJson']), schema))
    if case_df.isEmpty():
        logger.info("No case data found in input dataset")
        return
    else:
        final_case_delta_df = session.createDataFrame(case_df)
        final_case_cleaned = helper.clean_case_dataset(final_case_delta_df, metadata)
        if ctx.is_incremental:
            filtered_output = helper.filter_data(case_output, final_case_cleaned, partition_col)
            if bool(filtered_output.head(1)):
                updated_final_case_cleaned = final_case_cleaned.alias("final_case_cleaned").join(
                    filtered_output.alias("filtered_output"),
                    final_case_cleaned.ccai_case_id == filtered_output.ccai_case_id, how='left').withColumn(
                    "agent_name_updated", expr(
                        "case when final_case_cleaned.agent_id = filtered_output.agent_id then filtered_output.agent_name else final_case_cleaned.agent_name end")).withColumn(
                    "supervisor_name_updated", expr(
                        "case when final_case_cleaned.agent_id=filtered_output.agent_id then filtered_output.supervisor_name else final_case_cleaned.supervisor_name end")).select(
                    "final_case_cleaned.*", "agent_name_updated", "supervisor_name_updated").drop("agent_name").drop(
                    "supervisor_name").withColumnRenamed("agent_name_updated", "agent_name").withColumnRenamed(
                    "supervisor_name_updated", "supervisor_name")
            unchanged_df = filtered_output.alias("filtered_output").join(updated_final_case_cleaned.alias(
                "updated_final_case_cleaned"), filtered_output.ccai_case_id == updated_final_case_cleaned.ccai_case_id,
                how='left_anti').select("filtered_output.*")
            # COP-116 - sequence number change
            # changed_master_df = filtered_output.subtract(unchanged_df)
            # unioned_df = changed_master_df.union(final_case_cleaned.select(changed_master_df.columns))
            # unioned_df.createOrReplaceTempView('masterDeltaChangedTable')
            final_changed_df = mergeUtility.fetchLatestDatasets(
                filtered_output, final_case_cleaned, unchanged_df, 'case', session)
            final_latest_version_df = unchanged_df.union(final_changed_df.select(unchanged_df.columns))
            repartitioned_df = final_latest_version_df.repartition(col('date_created_gmt_month'))
            case_output.write_dataframe(repartitioned_df, partition_cols=partition_col)
            partition_overwrite.overwrite_partitions(case_output, partition_col)
            logger.info("Incremental ingestion done for case_output")
        else:
            logger.info("No changed partitions found in the input data, creating fresh build for case_output")
            repartitioned_df = final_case_cleaned.repartition(col('date_created_gmt_month'))
            case_output.write_dataframe(repartitioned_df, partition_col)
            partition_overwrite.overwrite_partitions(case_output, partition_col)
    else:
    logger.info("No build history found for output dataset, creating fresh build for case_output")
    repartitioned_df = final_case_cleaned.repartition(col('date_created_gmt_month'))
    case_output.write_dataframe(repartitioned_df, partition_col)
    partition_overwrite.overwrite_partitions(case_output, partition_col)

else:
