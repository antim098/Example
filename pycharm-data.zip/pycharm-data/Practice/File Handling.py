import os

# Open a file

fo = open("foo.txt", "r+")
fo.write("Python is a great language.\nYeah its great!!\n")

print ("Name of the file: ", fo.name)
print ("Closed or not : ", fo.closed)
print ("Opening mode : ", fo.mode)


str =fo.read(49)
print(str)

cur_p=fo.seek(94)

# Check current position
position = fo.tell()
print ("Current file position : ", position)

print("remaining lines",fo.read())

print(os.getcwd())

#os.rmdir('/home/impadmin/PycharmProjects/Practice/antim')

try:
   fh = open("foo.txt", "r")
   fh.read(10)
except IOError:
   print ("Error: can\'t find file or read data")
else:
   print ("Written content in the file successfully")