




import re
import json
s = '{   "tns3:RcptOutputEvent": {     "TxnId": "Txn-8e5c0d35-de37-42d9-8e93-a27f600aacfa",     "RcptData": {       "RcptId": "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa",       "Text": "Your personal data will be processed in accordance with the applicable carriers privacy policy and if your booking is made via a reservation system provider (\"GDS\"), with its privacy policy. These are available at"     }   } }'
print(s)
s = s.replace("\'", '"')
print("New json string",s)
input = json.dumps(s)
input_json = json.loads(input)
data = input_json['tns3:RcptOutputEvent']