# import sys, time, calendar
#
cars = 100
name = ['antim','kant']
name = str(name).strip('[]').replace("'",'')
print(name)
# speed_in_a_car = 4.0
# drivers = 30
passengers = 90
# name = "Dangerous"
#
# print(name[1:11])
#
print("There are %d cars available and %d passengers" % (cars, passengers))
#
# print("Mary had a little lamb")
# print("Its fur was %s as snow" % 'whiteads sds sdasd')
# print('.' * 110)  # what would that do.this is comment
# print("I am 6'2\" tall")
print("""
Hello how are
you...we can write anything using these.
""")
# try:
#     print(a)
# except IndexError as Argument:
#     print("there is some error", Argument)
#
# a, b, c, d = 1, 2, 'antim', 5
#
# list = ['antim', 1, 2, 3, 'zero']
# name = ('hello', 'people', 0, 9, 8, 'mic', 'check')
# list[2] = 'newvalue'
# print(list[2:])
# print(name)
# print(a)
#
# del list[0]
# first = 8.89
# second = 6.989
#
# print("Sum of %d and %d is %d" % (first, second, float(first + second)))
# print("Sum of {0} and {1} is {2}".format(first, second, first + second))
#
# x = input("Please enter the value")
# y = input("input second value")
#
# for x in name:
#     print(str(x))
#
# print("Current time is", time.time(), "Hello")
# print(time.asctime(time.localtime()))
#
# cal = calendar.month(2018, 10)
# print(cal)
#
# var1 = 'Hello World!'
# print("Updated String :- ", var1[:6] + 'Python')
# print(var1)
#
# print("Result is %d")
#
x = "'foo'"
y='antim'
print(x.__add__(y))
print(x)
name ='antim'
surname = 'kant'
print("({},'{}')".format(name,surname))
# sys.stdout.write(x)
# l1 = [1, 2, 3]
# l2 = [4, 5, 6]
#
# t = tuple(l1, l2)
#
