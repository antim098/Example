import datetime, re

# import dateutil.parser
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType
from pytz import timezone

from time import time
import pyspark.sql.functions as F
import math
from dateutil.parser import parse
from dateutil.relativedelta import relativedelta


class DateTimeConversion:

    def __init__(self): pass


if __name__ == "__main__":
    spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()
    dateCreated = '2018-12-18T06:27:07Z'
    dateAssigned = "2019-01-18T00:05:07Z"
    dateClosed = "2019-06-04T20:52:48Z"
    sample = '2018-12-16T09:45:00.8990'
    newDateClosedFormat = "2019-06-03T10:15:06.54-03:00"
    "2019-06-03T13:15:06.54Z"
    dt1 = '2019-07-10T08:30:43+0600'
    dt2 = '2019-07-08T17:47.13-06:00'
    test = "2019-06-03 10:15:06.549000"
    central = timezone('US/Central')
    utc = timezone('utc')
    newDate = "10/04/2018 08:03:25.261"


    # 'yyyy-MM-dd'T'HH:mm:ssZZZZ	2017-10-14T22:11:20+0000'
    # print(datetime.datetime.strptime(dt1, "yyyy-MM-dd'T'HH:mm:ssZZZZ"))
    # print(datetime.datetime.strptime(
    # '2018-12-18T06:27:07Z+05:30', '%Y-%m-%dT%H:%M:%SZ'))

    def getDateClosedGMTDateTime(inputString, reqField):
        central = timezone('US/Central')
        utc = timezone('utc')
        if inputString is not None:
            try:
                if 'Z' in inputString:
                    formatted_GMT = str(central.localize(datetime.datetime.strptime(
                        inputString, '%Y-%m-%dT%H:%M:%SZ')).astimezone(utc))
                else:
                    formatted_GMT = str(central.localize(datetime.datetime.strptime(
                        inputString[:-6], '%Y-%m-%dT%H:%M:%S.%f')).astimezone(utc))
                if reqField == 'date':
                    return formatted_GMT.split(" ")[0]
                elif reqField == 'dateTime':
                    return formatted_GMT
                else:
                    return formatted_GMT.split(" ")[1].split("+")[0]
            except ValueError:
                return ''
        else:
            return ''


    # a = utc.localize(datetime.datetime.strptime(dateCreated, '%Y-%m-%dT%H:%M:%SZ'))
    # print(a.timestamp())
    # result = curr_timestamp = time() - a.timestamp()
    # print("original result",result)
    # print("original hours", result/3600000)
    # print("hours1",round(result/3600000))
    # print("hours2",int(result/3600000))
    # print("hours3",math.floor(result/3600000))
    # print("hours4", math.ceil(result / 3600000))

    #
    # formatted_dateCreated_CST = str(
    #     utc.localize(datetime.datetime.strptime(dateCreated, '%Y-%m-%dT%H:%M:%SZZ')).astimezone(central))
    # dateCreated_CST_date = formatted_dateCreated_CST.split(" ")[0]
    # dateCreated_CST_time = formatted_dateCreated_CST.split(" ")[1].split("-")[0]
    # print(dateCreated_CST_time, dateCreated_CST_date)
    # print(formatted_dateCreated_CST)
    # formatted_dateAssigned_CST = str(
    #     utc.localize(datetime.datetime.strptime(dateAssigned, '%Y-%m-%dT%H:%M:%SZ')).astimezone(central))
    # dateAssigned_CST_date = formatted_dateAssigned_CST.split(" ")[0]
    # dateAssigned_CST_time = formatted_dateAssigned_CST.split(" ")[1].split("-")[0]
    # print(dateAssigned_CST_time, dateAssigned_CST_date)
    #
    # formatted_dateClosed_GMT = str(central.localize(datetime.datetime.strptime(dateClosed, '%Y-%m-%dT%H:%M:%SZ')).astimezone(utc))
    # print('gmt date closed',formatted_dateClosed_GMT[:-6])
    # print("check",formatted_dateClosed_GMT)
    # date = newDateClosedFormat[:-6]
    # print(newDateClosedFormat[:-6])
    # formatted_dateClosed_GMT = str(
    #     central.localize(datetime.datetime.strptime(newDateClosedFormat[:-6], '%Y-%m-%dT%H:%M:%S.%f')).astimezone(utc))
    # print(formatted_dateClosed_GMT)

    # format = 'yyyy-mm-dd'
    # print(str(format).upper())
    # print(dateCreated)
    # date = getDateClosedGMTDateTime('2019-05-30T11:35:02.976-05:00', 'dateTime')
    # print(date)

    # print(F.to_timestamp('2019-01-18T00:05:07Z'))
    # print(getDateClosedGMTDateTime(newDateClosedFormat,'dateTime'))
    # print(newDateClosedFormat[:-6])

    datestr = 'a'
    format = "%Y-%m-%d"
    # print(type(datetime.datetime.strptime(datestr, format).date()))

    antim = []
    # print("len", len(antim))
    three_yrs_ago = str(datetime.datetime.utcnow() - relativedelta(years=3, days=1)).split(" ")[0]
    # print(three_yrs_ago)
    # print("obtained gmt",str(datetime.datetime.utcnow()))
    print(".........................", '-'.join('2019-'.split('-')[:2]))
    # print(dateCreated.split('T')[0])
    if datestr != None and datestr != '':
        print("working")
    else:
        print("correct")
    # print(parse("2018-03-01T17:20:33-05:00"))
    print('gmt', getDateClosedGMTDateTime(newDateClosedFormat, 'dateTime'))
    # print('cst',str(datetime.datetime.strptime(
    # newDateClosedFormat[:-6], '%Y-%m-%dT%H:%M:%S.%f')).split('.')[0])
    "2019-05-16T11:57:33.814-05:00"

    dateClosedGMT = ''
    dateClosedCST = ''


    def get_local_start_time(inputString):
        # logger.info(inputString)
        inputString = str(inputString)
        central = timezone('US/Central')
        utc = timezone('utc')
        if len(inputString) > 0:
            try:
                formatted_CST = str(utc.localize(datetime.datetime.strptime(
                    inputString, '%Y-%m-%d %H:%M:%S')).astimezone(central))[:-6]
                return formatted_CST
            except ValueError:
                # If inputString has different date format then the above specified format,ValueError expection is raised.
                # logger.error("Incorrect date format encountered,empty string returned")
                return ''
        else:
            return ''


    def evaluate_date_closed(inputString):
        """
        Converts the DateTime field from GMT to CST and returns output according to the reqField parameter
        :param inputString:the GMT DateTime field
        :param reqField:required output field can be date,time or datetime
        :return: the reqField from the inputString
        """
        global dateClosedCST
        global dateClosedGMT
        central = timezone('US/Central')
        utc = timezone('utc')
        if len(inputString) > 0:
            try:
                if 'Z' in inputString:
                    dateClosedGMT = str(datetime.datetime.strptime(
                        inputString, '%Y-%m-%dT%H:%M:%SZ'))
                    dateClosedCST = str(utc.localize(datetime.datetime.strptime(
                        inputString, '%Y-%m-%dT%H:%M:%SZ')).astimezone(central))[:-6]
                else:
                    dateClosedCST = str(datetime.datetime.strptime(
                        inputString[:-6], '%Y-%m-%dT%H:%M:%S.%f'))
                    dateClosedGMT = str(central.localize(datetime.datetime.strptime(
                        inputString[:-6], '%Y-%m-%dT%H:%M:%S.%f')).astimezone(utc)).split("+")[0]

            except ValueError:
                # If inputString has different date format then the above specified formats,ValueError expection is raised.
                # logger.error("Incorrect date format encountered,empty string returned")
                return ''
        else:
            # If inputString has zero length then no operation takes place and empty string is returned
            return ''


    def evaluate_timestamp_CST(inputString):
        global flight_dtml
        global time
        global cstTime
        central = timezone('US/Central')
        utc = timezone('utc')
        cstTime = -5
        if len(inputString) > 0:
            try:
                if 'Z' in inputString:
                    flight_dtml = str(datetime.datetime.strptime(
                        inputString, '%Y-%m-%dT%H:%M:%SZ'))
                else:
                    if '+' in inputString:
                        None
                    else:
                        time = -(int(inputString.split('-')[3].split(':')[0]))
                        cstTime = cstTime - time

                        if cstTime > 0:
                            flight_dtml = datetime.datetime.strptime(
                                inputString[:-6], '%Y-%m-%dT%H:%M:%S.%f') + timedelta(hours=cstTime)
                        else:
                            flight_dtml = datetime.datetime.strptime(
                                inputString[:-6], '%Y-%m-%dT%H:%M:%S.%f') - timedelta(hours=abs(cstTime))
            except ValueError:
                # If inputString has different date format then the above specified formats,ValueError expection is raised.
                # logger.error("Incorrect date format encountered,empty string returned")
                return ''
        else:
            # If inputString has zero length then no operation takes place and empty string is returned
            return ''


    sent_timestamp_dtl = datetime.datetime(2019, 8, 18, 9, 55, 22, 300)
    # print(sent_timestamp_dtl)

    print(getDateClosedGMTDateTime(dateCreated, 'dateTime'))

    start_time = F.udf(get_local_start_time, StringType())
    df = spark.read.csv('date.csv', header=True)
    print(df.schema['date'].dataType)

    df = df.withColumn('date', F.to_timestamp(start_time('date')))
    print(df.schema['date'].dataType)
    df.show()
    new_df = df.select('date').alias('new_date').select('name')
    new_df.show()



    # evaluate_timestamp_CST(newDateClosedFormat)
    # print('corr date', correspondence_dtmz)
    # print('time', cstTime)
    # print('corr', flight_dtml)
