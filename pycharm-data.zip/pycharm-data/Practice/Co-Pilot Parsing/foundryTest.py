import json
import base64

passengerCount = 0

temp = {}

passengerList = []


def decodeJson(inputString):
    return base64.b64decode(inputString)


def parseUserJson(inputString):
    # jsonDict = json.loads(inputString)
    myout = decodeJson(inputString['payload']['content'])
    #print(myout)
    outputjson = json.loads(myout)
    outputjson['key'] = inputString['payload']['key']
    return outputjson


def extractPassenger(x, caseId, name=''):
    global passengerCount
    global temp
    if type(x) is dict:
        for a in x:
            extractPassenger(x[a], caseId, a)
    elif type(x) is list:
        if name in {'cases', 'passengers'}:
            temp.clear()
            length = x.__len__()
            for a in x:
                extractPassenger(a, caseId, name)
                passengerCount += 1
                data = dict(temp)
                data['ccaiCaseId'] = caseId
                temp.clear()
                if passengerCount <= length:
                    passengerList.append(data)
    else:
        temp[name] = x


if __name__ == "__main__":
    with open('/home/impadmin/PycharmProjects/Practice/demo.txt', 'r') as fh:
        x = json.load(fh)
    passengerList = []
    passengerCount = 0
    temp = {}
    decodedDic = parseUserJson(x)
    #print('..............', decodedDic['ccaiCaseId'])
    ccaiCaseId = decodedDic['ccaiCaseId']
    extractPassenger(decodedDic, ccaiCaseId)
    for a in passengerList:
        print(a)
