import json


class feedback_suggestion:

    def __init__(self): pass


data = {}
feedback_suggestionList = []


def extractFeedback(x, caseId, name=''):
    global feedbackCount
    global temp
    global data
    global suggestionCount
    if type(x) is dict:
        for a in x:
            extractFeedback(x[a], caseId, a)
    elif type(x) is list:
        if name in {'feedback'}:
            for a in x:
                feedbackCount += 1
                suggestionCount = 0
                extractFeedback(a, caseId, name)
        elif name in {'suggestions'}:
            if not None in x:
                temp.clear()
                length = x.__len__()
                for a in x:
                    suggestionCount += 1
                    if suggestionCount <= length:
                        suggData = {}
                        extractFeedback(a, caseId, name)
                        suggData.update(temp)
                        suggData['ccaiCaseId'] = caseId
                        suggData['feedbackId'] = feedbackCount
                        temp.clear()
                        feedback_suggestionList.append(suggData)

    else:
        temp[name] = x


def printList():
    print("list is", feedback_suggestionList)


if __name__ == "__main__":
    with open('enriched.json', 'r') as fh:
        x = json.load(fh)

    feedbackCount = 0
    suggestionCount = 0

    temp = {}
    # decodedDic = parseUserJson(x)
    # print('..............', decodedDic['ccaiCaseId'])
    ccaiCaseId = x['ccaiCaseId']
    extractFeedback(x, ccaiCaseId)
    for a in feedback_suggestionList:
        print(a)
