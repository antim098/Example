import base64
import datetime
import json

correspondence_list = []
correspondence_count = 0
attachment_count = 0
backup_dict = {}
attachments = []


def extract_correspondence(record, caseId, name=''):
    """
    Parses the input json record by iterating over its fields and stores the
    flattened correspondence fields as dictionary in a list
    There can be multiple correspondence for each record,
    thus producing multiple dictionaries for a single record in list.
    :param record:enriched input json record
    :param caseId:the ccaiCaseId of the case
    :param name: the name (or key) of the field
    """
    global attachments
    global backup_dict
    global attachment_count
    global correspondence_count
    if type(record) is dict:
        for key in record:
            extract_correspondence(record[key], caseId, key)
    elif type(record) is list:
        if name in {'correspondence'}:
            attachments = []
            temp_dict.clear()
            clength = record.__len__()
            for item in record:
                attachment_count = 0
                temp_dict['ccaiCaseId'] = caseId
                extract_correspondence(item, caseId, name)
                if not bool(backup_dict):
                    if correspondence_count <= clength:
                        print(clength)
                        correspondence = {}
                        correspondence.update(temp_dict)
                        # correspondence = {k: temp_dict.get(k, '') for k in correspondence_column_names}
                        correspondence['ccaiCaseId'] = caseId
                        # correspondence['sequence_number'] = sequence_number
                        # correspondence['caseCreatedGMTMonth'] = caseCreatedGMTMonth
                        correspondence_count += 1
                        print('hello')
                        correspondence_list.append(correspondence)
                        temp_dict.clear()
                else:
                    temp_dict.update(backup_dict)
                    if correspondence_count <= clength:
                        correspondence_count += 1
                        for attachment in attachments:
                            attachment.update(temp_dict)
                            # correspondence = {k: attachment.get(k, '') for k in correspondence_column_names}
                            attachment['ccaiCaseId'] = caseId
                            # attachment['caseCreatedGMTMonth'] = caseCreatedGMTMonth
                            # attachment['sequence_number'] = sequence_number
                            correspondence_list.append(attachment)
                        print(clength)
                        temp_dict.clear()
        elif name in {'attachments'}:
            if None not in record:
                del attachments[:]
                backup_dict = dict(temp_dict)
                # print("backup is ",backup)
                alength = record.__len__()
                for item in record:
                    temp_dict.clear()
                    data = {}
                    extract_correspondence(item, caseId, name)
                    data.update(temp_dict)
                    attachment_count += 1
                    if attachment_count <= alength:
                        attachments.append(data)
                    temp_dict.clear()
        else:
            if None in record:
                temp_dict[name] = ''
            else:
                temp_dict[name] = str(record)
    else:
        temp_dict[name] = record


if __name__ == "__main__":

    temp_dict = {}

    with open('new_data.json', 'r') as fh:
        x = json.load(fh)

    ccaiCaseId = x['ccaiCaseId']
    print(ccaiCaseId)
    extract_correspondence(x, ccaiCaseId)
    for a in correspondence_list:
        print(a)
