import base64
import datetime
import json

from pytz import timezone

passengerCount = 0

temp = {}

passengerList = []


def decodeJson(inputString):
    return base64.b64decode(inputString)


def extract_tripSegmets(x, caseId, name=''):
    global tripCount
    if type(x) is dict:
        for a in x:
            extract_tripSegmets(x[a], caseId, a)
    elif type(x) is list:
        if name in {'tripSegments'}:
            temp.clear()
            length = x.__len__()
            for a in x:
                extract_tripSegmets(a, caseId, name)
                tripCount += 1
                data = dict.fromkeys(PassengerKeys)
                # setPassengers(data)
                data['ccaiCaseId'] = caseId
                data.update(temp)
                if tripCount <= length:
                    tripsList.append(data)
        elif name in {'passengerIds'}:
            i = 0
            print(len(x))
            while i < len(x):
                temp["Passenger_" + str(i + 1)] = x[i]
                i += 1

    else:
        temp[name] = x


aCount = 0
backup = {}
cCount = 0
attachments = {}
backup_dict = {}
correspondence_list = []
correspondenceList = []


def extract_correspondence(x, caseId, name=''):
    global attachments
    global aCount
    global cCount
    global backup
    if type(x) is dict:
        for a in x:
            extract_correspondence(x[a], caseId, a)
    elif type(x) is list:
        if name in {'correspondence'}:
            attachments = []
            temp.clear()
            length = x.__len__()
            for a in x:
                aCount = 0
                temp['ccaiCaseId'] = caseId
                extract_correspondence(a, caseId, name)
                # print(temp)
                if not bool(backup):
                    if (cCount <= length):
                        output = dict(temp)
                        cCount += 1
                        correspondenceList.append(output)
                    temp.clear()
                else:
                    temp.update(backup)
                    if (cCount <= length):
                        cCount += 1
                        print(attachments.__len__())
                        for attachment in attachments:
                            attachment.update(temp)
                            print('.....', attachment)
                            correspondenceList.append(attachment)
                        backup.clear()
                        temp.clear()

        elif name in {'attachments'}:
            if None not in x:
                del attachments[:]
                backup = dict(temp)
                # print(backup)
                # print("backup is ",backup)
                len = x.__len__()
                for a in x:
                    temp.clear()
                    data = {}
                    extract_correspondence(a, caseId, name)
                    data.update(temp)
                    aCount += 1
                    if aCount <= len:
                        attachments.append(data)
                    temp.clear()


        else:
            temp[name] = x
    else:
        temp[name] = x


def GMT_to_CST(correspondenceList):
    for item in correspondenceList:
        date = item['date']
        item['date'] = str(
            utc.localize(datetime.datetime.strptime(item['date'], '%Y-%m-%dT%H:%M:%SZ')).astimezone(central))
        # item['date'] = cstDate
    # print(item)


if __name__ == "__main__":
    temp_dict = {}
    central = timezone('US/Central')
    utc = timezone('utc')
    with open('new.json', 'r') as fh:
        x = json.load(fh)

    tripCount = 0
    recordIndex = 0
    passengerList = []
    tripsList = list()
    PassengerKeys = ['Passenger_1', 'Passenger_2', 'Passenger_3', 'Passenger_4', 'Passenger_5', 'Passenger_6',
                     'Passenger_7', 'Passenger_8', 'Passenger_9']

    # decodedDic = parseUserJson(x)
    # fo = open("output.json", "r+")
    # fo.write(json.dumps(decodedDic))
    # print("Passenger_", passengerId_count)
    # print('..............', x['ccaiCaseId'])
    ccaiCaseId = x['ccaiCaseId']
    print(ccaiCaseId)
    # extract_correspondence(x, ccaiCaseId)
    # GMT_to_CST(correspondenceList)
    # extractPassenger(x, x['ccaiCaseId'])
    extract_correspondence(x, ccaiCaseId)
    # print(len(correspondenceList))
    # print(correspondenceList)

    for a in correspondenceList:
        print(a)

    # for b in passengerList:
    #     print(b)
