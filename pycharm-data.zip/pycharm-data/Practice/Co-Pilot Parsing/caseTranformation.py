import json
from datetime import datetime
import datetime
import pyspark.sql.functions as F

from pytz import timezone


# def inputDateFormats(caseData):
#     dateCreated = caseData['dateCreated']
#     caseData['dateCreatedGMTTime'] = getGMTDateTime(dateCreated, 'time')
#     caseData['dateCreatedCSTTime'] = getCSTDateTime(dateCreated, 'time')
#     caseData['dateCreatedCSTDate'] = getCSTDateTime(dateCreated, 'date')
#     caseData['dateCreatedCST'] = getCSTDateTime(dateCreated, 'dateTime')
#
#     dateAssigned = caseData['dateAssigned']
#     caseData['dateAssignedGMTTime'] = getGMTDateTime(dateAssigned, 'time')
#     caseData['dateAssignedCSTTime'] = getCSTDateTime(dateAssigned, 'time')
#     caseData['dateAssignedCSTDate'] = getCSTDateTime(dateAssigned, 'date')
#     caseData['dateAssignedCST'] = getCSTDateTime(dateAssigned, 'dateTime')


class caseTransformation:
    def __init__(self): pass


count = 0


def extractCase(record, name=''):
    global count
    """
    Parses the input json record by iterating over its fields and stores the flattened output in a dictionary
    :param record:enriched input json record
    :param name: the key of the field
    """
    if type(record) is dict:
        for key in record:
            extractCase(record[key], key)
    elif type(record) is list:
        if name in {'passengers'}:
            for item in record:
                count += 1
                if item['isPrimary'] == True:
                    extractCase(item, name)
                    # inputDateFormats(temp)
                    break
            print(count)

    else:
        temp[name] = record


def getGMTDateTime(inputString, reqField):
    """
    Separates the DateTime field and returns the output according to the reqField parameter
    :param inputString: the DateTime field
    :param reqField:required output field can be date,time
    :return: the reqField from the inputString
    """
    if inputString is not None and len(inputString) > 9:
        try:
            formatted_GMT = str(datetime.datetime.strptime(inputString, '%Y-%m-%dT%H:%M:%SZ'))
            if reqField == 'date':
                return formatted_GMT.split(" ")[0]
            else:
                return formatted_GMT.split(" ")[1]
        except:
            return ''
    else:
        return ''


def getCSTDateTime(inputString, reqField):
    """
    Converts the DateTime field from GMT to CST and returns reqField
    :param inputString:the GMT DateTime field
    :param reqField:required output field can be date,time or datetime
    :return: the reqField from the inputString
    """
    central = timezone('US/Central')
    utc = timezone('utc')
    if inputString is not None and len(inputString) > 9:
        try:
            formatted_CST = str(utc.localize(datetime.datetime.strptime(
                inputString, '%Y-%m-%dT%H:%M:%SZ')).astimezone(central))
            if reqField == 'date':
                return formatted_CST.split(" ")[0]
            elif reqField == 'dateTime':
                return formatted_CST[:-6]
            else:
                return formatted_CST.split(" ")[1].split("-")[0]
        except:
            return ''

    else:
        return ''


def schema_cleanse_explicit(mapping, input_df):
    for key, value in mapping.iteritems():
        if value[1] is None:
            expr = "convert_" + mapping[key][0].encode('utf8') + "_to_" + mapping[key][2].encode(
                'utf8') + "('" + key.encode('utf8') + "', 'string', " + "input_df)"
        else:
            expr = "convert_" + mapping[key][0].encode('utf8') + "_to_" + mapping[key][2].encode(
                'utf8') + "('" + key.encode('utf8') + "', '" + mapping[key][1].encode('utf8') + "', " + "input_df)"
        input_df = eval(expr)
    return input_df


if __name__ == "__main__":
    with open('enriched.json', 'r') as fh:
        enrichedRecord = json.load(fh)
        newEnriched = json.dumps(enrichedRecord)
    temp = {}
    casesList = []

    if 'dateAssigned' not in enrichedRecord:
        enrichedRecord['dateAssigned'] = ''
    if 'dateCreated' not in enrichedRecord:
        enrichedRecord['dateCreated'] = ''
    if 'ezCareCaseId' not in enrichedRecord:
        enrichedRecord['ezCareCaseId'] = ''
    if 'dateClosed' not in enrichedRecord:
        enrichedRecord['dateClosed'] = ''
    if 'agentId' not in enrichedRecord:
        enrichedRecord['agentId'] = ''
    print('testing....', enrichedRecord['dateCreated'])
    extractCase(enrichedRecord)
    sorted_dict = sorted(temp)
    dateCreated = '2018-12-05T09:02:47Z'
    dateCreatedCSTDate = '2018-12-05'

    # print(F.to_timestamp(dateCreated, format="yyyy-MM-dd HH:mm:ss"))

    dateInfo = {}

    # new = ['antim','kant','verma','passengerId']

    # dict2 = {k:temp.get(k,'') for k in new}
    test = len(temp) if len(temp) > 40 else 40
    print(test)
    print("dict length {}", len(temp.keys()))
    print(temp)
    print(sorted_dict)

    # # #
    # for b in feedback_suggestionList:
    #     print(b)
