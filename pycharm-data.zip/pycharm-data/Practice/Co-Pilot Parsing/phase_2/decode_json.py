from pyspark.sql import SparkSession
from pyspark.sql import  functions as F
import ast
from pyspark.sql import  types as T
import json
import yaml
import base64

spark = SparkSession.builder.appName('abc').master('local[*]').getOrCreate()


def decodeJson(inputString):
    """
    Decode input json string and return decoded content

    Parameters
        inputString : Input Json String

    Returns
        returns decoded content
    """
    if inputString is not None:
        inputString += "=" * ((4 - len(inputString) % 4) % 4)
        try:
            return base64.b64decode(inputString).decode('ascii')
        except(TypeError, ValueError):
            return 'null'
    else:
        return json.dumps({})

def decode_level2(inputString):
    """
    Decode input json string and return decoded content

    Parameters
        inputString : Input Json String

    Returns
        returns decoded content
    """
    if inputString is not None:
        return base64.b64decode(inputString)
    else:
        return json.dumps({})



def is_json(myjson):
    """
    Validate input json and return True if valid

    Parameters
        mysjon : Input Json

    Returns
        boolean : returns True if valid json
    """
    try:
        json.loads(myjson)
    except ValueError:
        return False
    return True


def parserInputJson(inputString):
    """
    Parse input json string and extract required fields

    Parameters
        inputString : Input Json String

    Returns
        finalDict : returns dictionary object with extracted fields
    """
    finalDict = {}
    print('input string type', type(inputString))
    inputString = json.dumps(inputString)
    if is_json(inputString):
        print('.....type....')
        print(type(inputString))
        jsonDict = json.loads(inputString)
        print('.....type....', type(jsonDict))
        #print('json Dict',jsonDict)
        myout = decode_level2(jsonDict['payload']['content'])
        outputjson = {}
        decoded_data = json.loads(myout)
        #print('decoded_data', decoded_data)
        outputjson['docType'] = decoded_data.get('docType', '')
        outputjson['vBucketUuid'] = jsonDict['payload']['vBucketUuid']
        outputjson['event'] = jsonDict['payload']['event']
        outputjson['partition'] = jsonDict['payload']['partition']
        outputjson['ingest_timestamp'] = jsonDict['payload']['ingest_timestamp']
        outputjson['key'] = jsonDict['payload']['key']
        outputjson['sequence_number'] = jsonDict['payload']['bySeqno']
        outputjson['data'] = json.dumps(decoded_data)
        finalDict['ingest_timestamp'] = outputjson.get('ingest_timestamp', '')
        finalDict['ccaiCaseId'] = outputjson.get('ccaiCaseId', '')
        finalDict['key'] = outputjson.get('key', '')
        # finalDict['sequence_number'] = jsonDict['payload']['bySeqno']
        #print(finalDict)
    return finalDict

def utf(value):
    new_val = str(value).strip('b').strip("'")
    return new_val


input_df = spark.read.csv('sample.csv', header=True)
print('.........input_df.....')
input_df.show()
get_val = F.udf(utf)
base_decode = F.udf(decodeJson)
input_df.createOrReplaceTempView('input_df')
decoded_df = spark.sql('''select *, decode(unbase64(value),"utf-8") as decoded_data,'antim' as name from input_df''')
partition_cols = ['name']
name =['antim']
# decoded_df = decoded_df.filter(decoded_df[partition_cols[0]].isin(name))
# decoded_df = decoded_df.repartition()
# decoded_df.show()
# decoded_df = input_df.withColumn(
#             'decoded_data', base_decode('value'))
error_df = decoded_df.filter(decoded_df.decoded_data == 'null')
error_df.show(truncate=False)
base_decoded_df = decoded_df.filter(decoded_df.decoded_data != 'null')
#base_decoded_df = base_decoded_df.withColumn('decoded_data', get_val('decoded_data'))
base_decoded_df.show(truncate=False)
print('error count', error_df.count())
print('non error count',base_decoded_df.count())
decoded_data = base_decoded_df.rdd.map(lambda x: parserInputJson(json.loads(x['decoded_data']))).toDF()
print('decoded_data count', decoded_data.count())
#decoded_df = spark.createDataFrame(decoded_data)
#decoded_df.show()
#
# data = {'A':'B'}
#
# print(data.keys())
