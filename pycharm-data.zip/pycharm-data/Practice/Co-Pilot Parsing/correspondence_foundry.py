import base64
import datetime
import json

from pytz import timezone

caseCreatedGMTMonth = ''
attachment_count = 0
correspondence_count = 0
backup_dict = {}


def extract_correspondence(record, caseId, sequence_number, name=''):
    """
    Parses the input json record by iterating over its fields and stores the
    flattened correspondence fields as dictionary in a list
    There can be multiple correspondence for each record,
    thus producing multiple dictionaries for a single record in list.
    :param record:enriched input json record
    :param caseId:the ccaiCaseId of the case
    :param name: the name (or key) of the field
    """
    global attachments
    global backup_dict
    global attachment_count
    global correspondence_count
    global caseCreatedGMTMonth
    if type(record) is dict:
        for key in record:
            extract_correspondence(record[key], caseId, sequence_number, key)
    elif type(record) is list:
        if name in {'correspondence'}:
            attachments = []
            temp_dict.clear()
            clength = record.__len__()
            for item in record:
                attachment_count = 0
                temp_dict['ccaiCaseId'] = caseId
                extract_correspondence(item, caseId, sequence_number, name)
                if not bool(backup_dict):
                    if correspondence_count <= clength:
                        correspondence = temp_dict
                        # correspondence = {k: temp_dict.get(k, '') for k in correspondence_column_names}
                        correspondence['ccaiCaseId'] = caseId
                        correspondence['sequence_number'] = sequence_number
                        correspondence['caseCreatedGMTMonth'] = caseCreatedGMTMonth
                        correspondence_count += 1
                        correspondence_list.append(correspondence)
                        temp_dict.clear()
                else:
                    temp_dict.update(backup_dict)
                    if correspondence_count <= clength:
                        correspondence_count += 1
                        for attachment in attachments:
                            attachment.update(temp_dict)
                            correspondence = temp_dict
                            # correspondence = {k: attachment.get(k, '') for k in correspondence_column_names}
                            correspondence['ccaiCaseId'] = caseId
                            correspondence['caseCreatedGMTMonth'] = caseCreatedGMTMonth
                            correspondence['sequence_number'] = sequence_number
                            correspondence_list.append(correspondence)
                        backup_dict.clear()
                        temp_dict.clear()
        elif name in {'attachments'}:
            if None not in record:
                del attachments[:]
                backup_dict = dict(temp_dict)
                # print("backup is ",backup)
                alength = record.__len__()
                for item in record:
                    temp_dict.clear()
                    data = {}
                    extract_correspondence(item, caseId, sequence_number, name)
                    data.update(temp_dict)
                    attachment_count += 1
                    if attachment_count <= alength:
                        attachments.append(data)
                    temp_dict.clear()
        else:
            if None in record:
                temp_dict[name] = ''
            else:
                temp_dict[name] = str(record)
    else:
        temp_dict[name] = record


if __name__ == "__main__":
    temp_dict = {}
    correspondence_list =[]
    central = timezone('US/Central')
    utc = timezone('utc')
    with open('new.json', 'r') as fh:
        x = json.load(fh)

    ccaiCaseId = x['ccaiCaseId']
    extract_correspondence(x, ccaiCaseId, 100)
    for a in correspondence_list:
        print(a)
