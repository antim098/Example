import json


class feedback:

    def __init__(self): pass


data = {}
feedbackList = []
feedback_suggestionList = []


def extractFeedback(x, caseId, name=''):
    global feedbackCount
    global temp
    global data
    global suggestionCount
    if type(x) is dict:
        for a in x:
            extractFeedback(x[a], caseId, a)
    elif type(x) is list:
        if name in {'feedback'}:
            temp.clear()
            length = x.__len__()
            for a in x:
                feedbackCount += 1
                suggestionCount = 0
                temp['ccaiCaseId'] = caseId
                temp['feedbackId'] = feedbackCount
                extractFeedback(a, caseId, name)
                # print("temp is", temp)
                data.update(temp)
                # if feedbackCount <= length:
                feedbackList.append(data)
        elif name in {'suggestions'}:
            data = dict(temp)
            temp.clear()
            length = x.__len__()
            for a in x:
                suggestionCount += 1
                if suggestionCount <= length:
                    suggData = {}
                    extractFeedback(a, caseId, name)
                    suggData.update(temp)
                    suggData['ccaiCaseId'] = caseId
                    suggData['feedbackId'] = feedbackCount
                    temp.clear()
                    feedback_suggestionList.append(suggData)

    else:
        temp[name] = x


def printList():
    print("list is", feedback_suggestionList)


if __name__ == "__main__":
    with open('latest.json', 'r') as fh:
        x = json.load(fh)

    feedbackCount = 0
    suggestionCount = 0
    temp = {}
    ccaiCaseId = x['ccaiCaseId']
    extractFeedback(x, ccaiCaseId)
    oldkeys = ['type',
               'feedbackCategory',
               'selectedTypeDescription',
               'selectedTypeCode',
               'selectedDepartmentDescription',
               'selectedDepartmentCode',
               'selectedPrimaryDescription',
               'selectedPrimaryCode', 'suggestedPrimarySelected', 'overrideDate', 'agentId',
               'issueLocation',
               'state']

    newkeys = ['type',
               'feedbackCategory',
               'selectedTypeDescription',
               'selectedTypeCode',
               'selectedDepartmentDescription',
               'selectedDepartmentCode',
               'selectedPrimaryDescription',
               'selectedPrimaryCode', 'suggestedPrimarySelected', 'overrideDate', 'agentId',
               'issueLocation',
               'state',
               'mentionedEmployeeName',
               ]

    newcolumns = list(set(newkeys) - (set(newkeys).intersection(set(oldkeys))))
    data = dict.fromkeys(newcolumns, '')
    # print(temp)
    sorted_dict = sorted(temp)
    print(sorted_dict)
    print(temp.get('antim'))
    suggestions = [None]
    if None in suggestions:
        suggestions = ''
    for key,value in temp.items():
        print(key,value)

