import json


class feedback_compensation:
    def __init__(self): pass


def setPassengers(jsonDict):
    for i in range(1, 10):
        jsonDict['Passenger_' + str(i)] = ''


data = {}
feedbackList = []
additional_passengers = []


def extractFeedback_Compensation(x, caseId, name=''):

    global feedback_compensationList
    global compensationCount
    global temp
    global data
    global feedbackCount
    if type(x) is dict:
        for a in x:
            extractFeedback_Compensation(x[a], caseId, a)
    elif type(x) is list:
        if name in {'feedback'}:
            temp.clear()
            flen = x.__len__()
            for a in x:
                feedbackCount += 1
                if (flen <= flen):
                    extractFeedback_Compensation(a, caseId, name)
                    compensationCount = 0
        elif name in {'compensation'}:
            if not None in x:
                temp.clear()
                length = x.__len__()
                for a in x:
                    compensationCount += 1
                    if compensationCount <= length:
                        data = {}

                        data['feedbackId'] = feedbackCount
                        data['ccaiCaseId'] = ccaiCaseId
                        setPassengers(data)
                        extractFeedback_Compensation(a, caseId, name)
                        data.update(temp)
                        data['additional_passengers'] = additional_passengers
                        temp.clear()
                        feedback_compensationList.append(data)
        elif name in {'suggestions'}:
            for a in x:
                extractFeedback_Compensation(a, caseId, name)
        elif name in {'passengerIds'}:
            i = 0
            length = len(x)
            print(length)
            if not length > 9:
                while i < length:
                    temp["Passenger_" + str(i + 1)] = x[i]
                    i += 1
            else:
                while i < 9:
                    temp["Passenger_" + str(i + 1)] = x[i]
                    i += 1
                for i in range(i, length):
                    additional_passengers.append(x[i])
    else:
        temp[name] = x


if __name__ == "__main__":
    with open('latest.json', 'r') as fh:
        x = json.load(fh)
    feedbackCount = 0
    compensationCount = 0
    feedback_compensationList = []
    temp = {}
    ccaiCaseId = x['ccaiCaseId']
    extractFeedback_Compensation(x, ccaiCaseId)
    # if len(feedbackList) == 0:
    #     print("yes")

    for a in feedback_compensationList:
        print(a)
