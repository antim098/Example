from struct import Struct
import json
from datetime import datetime

from dateutil.relativedelta import relativedelta
from pyspark import rdd
from datetime import timedelta
from pyspark.sql.types import DecimalType
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, unix_timestamp, Column as col, trim
import pyspark.sql.functions as F
import pandas as pd
def one():
    print('One')

def two():
    print('two')
    one()

row = '{"schema":{"type":"struct","fields":[{"type":"string","optional":false,"field":"event"},{"type":"int16","optional":false,"field":"partition"},{"type":"string","optional":false,"field":"key"},{"type":"int64","optional":false,"field":"cas"},{"type":"int64","optional":false,"field":"bySeqno"},{"type":"int64","optional":false,"field":"revSeqno"},{"type":"int32","optional":true,"field":"expiration"},{"type":"int32","optional":true,"field":"flags"},{"type":"int32","optional":true,"field":"lockTime"},{"type":"bytes","optional":true,"field":"content"},{"type":"int64","optional":true,"field":"ingest_timestamp"},{"type":"string","optional":true,"field":"bucket"},{"type":"int64","optional":true,"field":"vBucketUuid"}],"optional":false,"name":"com.couchbase.DcpMessage"},"payload":{"event":"mutation","partition":683,"key":"154827841050170","cas":1548278443322245120,"bySeqno":40,"revSeqno":30,"expiration":0,"flags":33554432,"lockTime":0,"content":"eyJwYXNzZW5nZXJzIjpbeyJsYXN0TmFtZSI6IkNJUE9ERVFBIiwiY2l0eSI6ImhvdXN0b24iLCJwb3N0YWxDb2RlIjoiNzcwMDItNzM2MiIsImNvbXBhbnlOYW1lIjoiIiwidGl0bGUiOiJNUiIsInN1ZmZpeCI6IiIsInByZW1pZXJlUXVhbGlmeWluZ1NlZ21lbnRzIjowLjAsImN1c3RvbWVyVmFsdWVTY29yZSI6MC4wLCJtaWxlYWdlUGx1c051bWJlciI6IkNGMzkyMzMxIiwiaXNQcmltYXJ5Ijp0cnVlLCJjb3VudHJ5Q29kZSI6IlVTIiwidGlja2V0VG90YWxDb3N0IjowLjAsImN1c3RvbWVySWQiOiIxMjI5MDAzNzMiLCJzdGF0ZSI6IlRYIiwibGlmZXRpbWVNaWxlcyI6MCwiZW1haWwiOiJhamF5c2FudG9zaC5ib2xpc2V0dHlAdW5pdGVkLmNvbSIsInBob25lRXh0IjoiIiwicGhvbmVUeXBlIjoiUEgiLCJwcmVtaWVyZVF1YWxpZnlpbmdEb2xsYXJzIjowLjAsImFkZHJlc3MzIjoiIiwiY3VycmVudE1QU3RhdHVzQ29kZSI6IjAiLCJhZGRyZXNzMiI6IiIsImFkZHJlc3MxIjoiMTYwMCBzbWl0aCBzdCIsImFkZHJlc3NUeXBlIjoiSCIsIm5vdGVXb3J0aHlQZXJzb24iOiJmYWxzZSIsImRhdGVPZkJpcnRoIjoiMTk4OC0wOC0zMVQwMDowMDowMC0wNTowMCIsImN1cnJlbnRNaWxlYWdlQmFsYW5jZSI6ODg0NzQ5LCJmcmVxdWVudEZseWVyUHJvZ3JhbSI6IlVBIiwiZmlyc3ROYW1lIjoiUkVEIiwibWVtYmVyU2luY2VEYXRlIjoiMjAxNC0xMS0xM1QwMDowMDowMCIsInBob25lTnVtYmVyIjoiKzE3MTMzMjQxMjM0IiwicHJlbWllcmVRdWFsaWZ5aW5nTWlsZXMiOjAsImN1cnJlbnRNUFN0YXR1cyI6Ik5vbi1FbGl0ZSIsInBhc3NlbmdlcklkIjoxLCJtaWRkbGVOYW1lIjoiIn1dLCJub3RlcyI6W10sInByZWZlcnJlZENvbnRhY3RFbWFpbCI6ImdhdXJhdi5kYXZlQHVuaXRlZC5jb20iLCJkb2NUeXBlIjoiY2FzZSIsImNvcnJlc3BvbmRlbmNlIjpbeyJkYXRlIjoiMjAxOS0wMS0yM1QyMToyMDoxMFoiLCJjb3JyZXNwb25kZW5jZUlkIjoxLCJib2R5VGV4dCI6IkdEIGRpcnR5IGJhdGhyb29tICBHRCBDcmVkaXQgY2FyZCB0byBidXkgbWVhbHMgZGlkIG5vdCB3b3JrIiwidHlwZSI6IndlYmZvcm0iLCJyZXNwb25zZVJlcXVlc3RlZCI6dHJ1ZX1dLCJjY2FpQ2FzZVN0YXR1cyI6InJlcm91dGVkIiwiY2NhaUNhc2VJZCI6MTU0ODI3ODQxMDUwMTcwLCJpUG9zSW5kaWNhdG9yIjoiZW4tVVMiLCJmZWVkYmFjayI6W3sidHlwZSI6IkNvbmNlcm4iLCJzZWxlY3RlZFByaW1hcnlDb2RlIjoiMTIzIiwiZmVlZGJhY2tDYXRlZ29yeSI6IkFpcnBvcnQgZXhwZXJpZW5jZSJ9XSwiZGF0ZUNyZWF0ZWQiOiIyMDE5LTAxLTIzVDIxOjIwOjEwWiIsInRyaXAiOnt9LCJfY2xhc3MiOiJjb20udW5pdGVkLmN1c3RvbWVyY2FyZS5tb2RlbC5Nb2RlbENhc2UifQ==","ingest_timestamp":1582131481011,"bucket":"CustomerCare","vBucketUuid":165023013210437}}'

two()

