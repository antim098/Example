




import json,re


s = {   "tns3:RcptOutputEvent":
            {     "TxnId": "Txn-8e5c0d35-de37-42d9-8e93-a27f600aacfa",
                  "RcptData": {       "RcptId": "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa",
                                      "Text": "Your personal data will be processed in accordance with the applicable carriers privacy policy and if your booking is made via a reservation system provider (\"GDS\"), "
                                              "with its privacy policy. These are available at"     }   } }
print(s)

#s = re.sub('\"GDS\"', '\\\"GDS\\\"', s)
#s = s.replace("\'", '"')
#print("New JSON String",s)

dumpJSON = json.dumps(s)
dumpJSON = dumpJSON.replace("\'", '"')
#dumpJSON = dumpJSON.strip()
JSON = json.loads(dumpJSON)
print(JSON)

sources = JSON['tns3:RcptOutputEvent']
print("JSON OUTPUT",sources)
print("Value of TxnId",sources['TxnId'])


