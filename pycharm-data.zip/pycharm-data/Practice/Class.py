class AntimKant:

    value = 0

    def __init__(self,name="antim",salary=1000):
        self.name = name
        self.salary = salary

    def display(self):
            print("Values are",self.name,self.salary)


a = AntimKant("antim",10000)
b = AntimKant()
a.display()
b.display()
print(AntimKant.value)