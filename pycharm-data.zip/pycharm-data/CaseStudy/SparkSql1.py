import os

from pyspark import SparkContext, rdd, SparkConf
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils

if __name__ == "__main__":
    os.environ['PYSPARK_SUBMIT_ARGS'] = '--jars spark-streaming-kafka-0-8-assembly_2.11-2.4.3.jar pyspark-shell'
   # os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages spark-streaming-kafka-0-8_2.11-2.4.3.jar pyspark-shell'
    sc = SparkContext("local[*]", "context")
    ssc = StreamingContext(sc, 30)
    topic = "website"
    brokers = "localhost:9092"
    kafkaParams = {"bootstrap.servers": 'localhost:9092'}

    kafkaStream = KafkaUtils.createDirectStream(ssc, [topic], {"metadata.broker.list": brokers})
    kafkaStream.map(lambda line: line.value())
    print("Code Done")
    ssc.start()
    ssc.awaitTermination()

