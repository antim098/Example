from struct import Struct
import json
import datetime

from pyspark import rdd,from pyspark.sql import functions as F
import logging
import time

from pyspark.sql.types import DecimalType, IntegerType
from pyspark.sql import SparkSession,functions as F,types as T
from pyspark.sql import types
from pyspark.sql.functions import lit, unix_timestamp, Column as col, trim

import time

import numpy as np
from pyspark.sql.types import FloatType
import pandas
from pyspark.sql.types import StructType, ArrayType, TimestampType, DateType, StringType


def flattenSchema(schema, prefix=''):
    schema.fields.flatMap(lambda f: rows(f, prefix))


def rows(f, prefix):
    if prefix is None:
        colName = f.name
    else:
        colName = prefix + "." + f.name

    if type(f) == StructType:
        flattenSchema(f, colName)
    else:
        return f.array(colName)


def flatten(schema, prefix=None):
    fields = []
    for field in schema.fields:
        name = prefix + '.' + str(field.name) if prefix else field.name
        dtype = field.dataType
        if isinstance(dtype, ArrayType):
            dtype = dtype.elementType

        if isinstance(dtype, StructType):
            fields += flatten(dtype, prefix=name)
        else:
            fields.append(name)

    return fields


spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()

df = spark.read.json('samplejson5_14.json', multiLine=True)

# df.select(flattenSchema(df.schema))

# list = flatten(df.schema)

# elements = ['_state', '_type', 'agentId', 'attachments', 'bodyText', 'bodyTextHtml', 'correspondenceId',
# 'customerEmail', 'date', 'responseRequested', 'selectedTemplateId', 'suggestedBodyText', 'suggestions']
# for x in list:
#     print(x)

# df.rdd.flatMap(lambda x:x.show())


oldkeys = ['type',
           'feedbackCategory',
           'selectedTypeDescription',
           'selectedTypeCode',
           'selectedDepartmentDescription',
           'selectedDepartmentCode',
           'selectedPrimaryDescription',
           'selectedPrimaryCode', 'suggestedPrimarySelected', 'overrideDate', 'agentId',
           'issueLocation',
           'state']

newkeys = ['type',
           'feedbackCategory',
           'selectedTypeDescription',
           'selectedTypeCode',
           'selectedDepartmentDescription',
           'selectedDepartmentCode',
           'selectedPrimaryDescription',
           'selectedPrimaryCode', 'suggestedPrimarySelected', 'overrideDate', 'agentId',
           'issueLocation',
           'state',
           'mentionedEmployeeName',
           ]

newcolumns = list(set(newkeys) - (set(newkeys).intersection(set(oldkeys))))
data = dict.fromkeys(newcolumns, '')
value = "antim"

df = df.withColumn('Timestamp', lit('2018-12-18T06:27:07Z'))
df.createOrReplaceGlobalTempView("demo")
df.withColumn('A',lit('antim')).withColumn('B',lit('Kant'))
print('.............................................................')
df.show()
# df = df.withColumn('Timestamp',unix_timestamp(df['Timestamp'],'%Y-%m-%d').cast("long").cast(DateType()))

# df = df.withColumn('Timestamp', F.to_timestamp('Timestamp', "yyyy-MM-dd'T'hh:mm:ss'Z'"))
# newdf = spark.sql("CAST(demo.Timestamp AS timestamp)")

# def dummy_function(data_str):
#     if data_str is not '':
#         data_str = datetime.datetime.strptime(
#             data_str, '%Y-%m-%dT%H:%M:%SZ')
#         print("type",type(data_str))
#     return data_str

# dummy_function_udf = F.udf(dummy_function, StringType())
def trim_and_delimiter_replace(input_df):
    print("converted through method")
    for column in df.columns:
        input_df = input_df.withColumn(column,
                                       F.regexp_replace(F.trim(F.col(column).cast('string')), "[\\\|*~\$#\t]", "d"))
    input_df.show()
    return input_df


def isBlank(myString):
    return not (myString and myString.strip())


def remove_zeroes(flight_number):
    new_flight_number = str(flight_number).lstrip('0')
    return new_flight_number


def get_dtype(df, colname):
    return [dtype for name, dtype in df.dtypes if name == colname]


def get_range_info_schema():
    range_info_schema = T.StructType([
               T.StructField('range_num', T.StringType(), True)])
    return range_info_schema

df = df.withColumn('Timestamp', F.to_timestamp('Timestamp', "yyyy-MM-dd'T'hh:mm:ss'Z'"))
df = df.withColumn('sentTimestamp', lit(1563408000000))
# print(df.select('Timestamp'))
print(df.schema['sentTimestamp'].dataType)

schema = StructType([])
empty = spark.createDataFrame(spark.sparkContext.emptyRDD(), schema)
empty.createOrReplaceTempView("empty")

df = df.withColumn('sentTimestamp',
                   ((df['sentTimestamp'] / 1000).cast("Timestamp"))).withColumn('cases', lit('')).withColumn(
    'Timestamp', F.date_format(df['Timestamp'], "yyyy-MM-dd").cast("date")).withColumn('number', lit(20)).withColumn(
    'flight_num', lit('\\ant#*$|\t'))
df.show()
# df = df.withColumn('Combined',F.to_date(F.concat_ws("-
# df = df.withColumn("flight_num",df['flight_num'].cast('int').cast('string'))
# df = df.withColumn('flight_num', F.regexp_replace('flight_num', '^0*', ''))
ndf = df.withColumn('flight_num', F.regexp_replace(
    'flight_num', "[\\\|*~\$#\t]", "e"))
trim_and_delimiter_replace(df)
sample = '6090000'
# since_date = datetime.now()
# today = datetime.today().strftime('%Y%m%d')
# datetime.strptime(today, "%Y%m%d").strftime('%Y%m%d')

since_df = spark.read.csv('since_range.csv', header=True)
since_df.show()
panda_df = since_df.toPandas()
flight_num = sample.__len__() if (sample.__len__()) > 0 else int(1)
print('......type', type(flight_num))
df.distinct().show()
# print('using location',panda_df.loc[panda_df['range_num'] == '5', 'from_date'].item())
ndf = spark.read.csv('single_data.csv', header=True)
panda = ndf.toPandas()
daily_ingest_indicator = panda['name'].values[0] if (
                                                        panda['name']).size > 0 else ''

print(isBlank(daily_ingest_indicator))
print('size', (panda['name']).size)

column_list = ['ACCT_YYYYMM', 'ACT_PAX_MILES', 'AGE', 'BASIC_ECON_IND', 'BOOKED_CABIN', 'BOOKING_AGENCY_ID', 'CABIN',
               'CLEAN_TOUR_CD', 'COUPON_LEG_SEQ', 'COUPON_NUM', 'CREDIT_CRD_TYPE', 'CRS_CD', 'CUR_PNR_PAX_CNT',
               'DEST_CD', 'DISCOUNT_CD', 'DIST_CHANNEL', 'ELITE_LVL_CD_AT_LIFT', 'EQUIP_TYPE_CD', 'EQUIV_CURR_OPER_COS',
               'ETKT_IND', 'FARE_CD', 'FFP_CARR_CD', 'FFP_CUST_ID', 'FLT_NUM', 'FOP_IND', 'FPS_PRORATE_BYND_AMT',
               'FPS_PRORATE_RVNU_AMT', 'FUEL_SURCHARGE_AMT', 'GENDER_CD', 'INITIAL_PNR_PAX_CNT', 'ISSUED_DT',
               'L4_NUMCAT_CD', 'MILES_EARN', 'MKTG_CARR_CD', 'MKTG_COS', 'OA_BYND_RVNU_AMT', 'ONEWAY_IND',
               'OPER_CARR_CD', 'OPER_COS', 'ORIG_CD', 'ORIG_DIST_CHANNEL', 'ORIG_ISSUED_DT', 'ORIG_RECORD_ID',
               'ORIG_TKT_NUM', 'ORIG_TKTG_AGENCY_ID', 'OUT_RET_CD', 'PNR_CREATION_DT', 'POS_COUNTRY_CD', 'RCRD_LOC',
               'RECORD_ID', 'REISSUED_FLG', 'RVNU_AMT', 'SCH_ARRV_TIME', 'SCH_DPRT_DTL', 'Sch_dprt_dtmz',
               'SCH_DPRT_TIME', 'SEAT', 'SYS_BYND_PAX_MILES', 'SYS_BYND_RVNU_AMT', 'sys_lof_act_carr_cds',
               'SYS_LOF_CITY_CDS', 'SYS_LOF_DEST_act_CARR_CD', 'SYS_LOF_DEST_CD', 'SYS_LOF_DEST_MKTG_CARR_CD',
               'SYS_LOF_DOM_INTL_CD', 'SYS_LOF_LEG_SEQ', 'SYS_LOF_LOCAL_FLOW_CD', 'SYS_LOF_MKTG_CARR_CDS',
               'SYS_LOF_ORIG_act_CARR_CD', 'SYS_LOF_ORIG_CD', 'SYS_LOF_ORIG_MKTG_CARR_CD', 'SYS_LOF_TOTAL_SEGS',
               'SYS_ORIG_DEST_DIR', 'SYS_ORIG_DEST_NON_DIR', 'SYS_PATH_PAX_CNT', 'TKT_DESIGNATOR',
               'TKT_DESIGNATOR_LEFT', 'TKT_NUM', 'TKT_ORIG_CD', 'TKTNG_AGENCY_ID', 'TRUE_LOF_DEST_CD',
               'TRUE_LOF_DEST_MKTG_CARR_CD', 'TRUE_LOF_DEST_OPER_CARR_CD', 'TRUE_LOF_LEG_SEQ', 'TRUE_LOF_LOCAL_FLOW_CD',
               'TRUE_LOF_MKTG_CARR_CDS', 'TRUE_LOF_OPER_CARR_CDS', 'true_lof_orig_act_carr_cd', 'TRUE_ORIG_DEST_DIR',
               'UPDATE_DT']
metadata_df = spark.read.csv('dm_metadata.csv', header=True)
metadata_df.show()
final_df = metadata_df.filter(metadata_df['INPUTCOLUMNNAME'].isin(column_list))
final = final_df.toPandas()
out_list = final['OUTPUTCOLUMNNAME'].tolist()

one_df = spark.read.csv('one.csv', header=True)
two_df = spark.read.csv('two.csv', header=True)
three_df = spark.read.csv('three.csv', header=True)
#print(sample_df.schema['Name'].dataType)

final = one_df.union(two_df).union(three_df)
final.show()



# types = [f.dataType for f in df.fields]
# types_dict = {f.dataType: f for f in final_df.fields}
# print(types)

current_epoch = int(time.time())
# current_time = datetime.now()
# one_minutes_ago = datetime.now() - timedelta(minutes=1)  # use datetime.datetime.utcnow() for UTC time
one_minute_ago = int(time.time() - 60)
# int((datetime.datetime.now() - datetime.timedelta(minutes=1)).strftime('%s'))
print('epoch', current_epoch)
print('time', one_minute_ago)

# names = metadata_df.schema.names

# columns = metadata_df.columns

df = final_df.filter(final_df.OUTPUTCOLUMNNAME == 'ticket_number')
df.show()
# print('............',panda_df.loc[panda_df['flight_num'] == '6094']['number'][0])
print('*****',panda_df['range_num'].values[0] )

#panda_df.insert(loc=0, column='A', value=np.arange(len(panda_df)))

print(panda_df)
i=1
seq =[]
# while i <= len(panda_df):
#     seq.append(i)
#     i = i+1

for i in range(1,len(panda_df)+1):
    seq.append(i)

panda_df['counter'] = range(len(panda_df))
panda_df.reindex(['range_num', *panda_df.columns], axis=1).assign(range_num=seq)
panda_df['seq'] = seq
print(panda_df)

range_num_reached = 4
schema = get_range_info_schema()
range_info_df = spark.createDataFrame([(range_num_reached,)], schema=schema, samplingRatio=1)
range_info_df.show()


# since_date = since_date.replace(year=2019, month=10, day=15)
# since_date = since_date.strftime("%Y-%m-%d %H:%M:%S")
# print(since_date)

# df.createOrReplaceTempView('test')
# print("converted date from timestamp is")
# print(df.select('sentTimestamp').collect())
# print(type(df.schema['Timestamp'].dataType))



# final_df.show()
# collect()[0]['sentTimestamp'])
# 08:41:40
# 14:11:40
# 2019, 8, 22, 8, 41, 40, 893000

# print("Count is %d" % df.count())
# split_col = F.split(df['my_str_col'], '[+]')
# df = df.withColumn('NAME1', split_col.getItem(0))
# df.show(truncate=False)

# metadata_df = spark.read.csv('map_jumpseat_transaction_view_metadata.csv', header=True)
# metadata_df.show(truncate=False)
# for a in range(0, metadata_df.count()):
#     print("\n", metadata_df.collect()[a])

# spark.sql("show partitions test partition(year = '2009')").show()

# spark.sql(
# "INSERT OVERWRITE TABLE demo PARTITION (Timestamp) SELECT * FROM demo WHERE Timestamp = Timestamp")

# spark.sql("show partitions <tablename>").as[String].first.split('/').map(_.split("=").head)
# columns = spark.sql("select Timestamp from %s"%('demo'))
# columns.show()
# yyyy-MM-dd'T'hh:mm:ss'Z'

# df = df.withColumn('Timestamp', F.to_timestamp('Timestamp', format='%Y-%m-%dT%H:%M:%SZ'))

# df = df.withColumn('Date', F.to_date('Date'))
# value1 = df.select('Date')
# value1.show()
# print(value1.schema)
# df.select('cases.trip.tripSegments.segmentId').show()
# df.show(truncate=False)
#
# casesDF = df.select('cases')
# casesDF.show(truncate=False)
# casesDF.createOrReplaceTempView("jd")
#
# sqlDF = spark.sql("SELECT explode(cases) FROM jd")
#
# sqlDF.printSchema()
#
# tripDF = casesDF.select('cases.trip')
# tripDF.show()
# tripDF.printSchema()
