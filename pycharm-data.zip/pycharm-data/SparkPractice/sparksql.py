from pyspark.sql import HiveContext,Row
from pyspark.context import  SparkContext
from pyspark.sql import  SparkSession
spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()



emp = spark.sql("""select * from testdata""")




