from pyspark.context import SparkContext
from pyspark.sql import  SQLContext
from pyspark.sql import  SparkSession
spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()

#sc = SparkContext()
#sql = SQLContext(sc)
#data = sc.parallelize([('Amber', 22), {'Alfred': 23}, [('Skye',4), ('Albert', 12),
#     ('Amber', 9)]])
#print(data.collect())

#data_heterogenous = sc.parallelize([('Ferrari', 'fast'), {'Porsche': 100000}]).collect()
#print(data_heterogenous[1]['Porsche'])

#Generating DataFrames
stringJSONRDD = spark.sparkContext.parallelize((""" 
  { "id": "123",
    "name": "Katie",
    "age": 19,
    "eyeColor": "brown"
  }""",
   """{
    "id": "234",
    "name": "Michael",
    "age": 22,
    "eyeColor": "green"
  }""",
  """{
    "id": "345",
    "name": "Simone",
    "age": 23,
    "eyeColor": "blue"
  }""")
)


swimmersJSON = spark.read.json(stringJSONRDD)
swimmersJSON.createOrReplaceTempView("swimmersJSON")
swimmersJSON.show()
print(spark.sql("select id from swimmersJSON").collect())
print(swimmersJSON.printSchema)
#swimmers = spark.createDataFrame()

#another way to create Data Frame

df = spark.createDataFrame([
        (1, 144.5, 5.9, 33, 'M'),
        (2, 167.2, 5.4, 45, 'M'),
        (3, 124.1, 5.2, 23, 'F'),
        (4, 144.5, 5.9, 33, 'M'),
        (5, 133.2, 5.7, 54, 'F'),
        (3, 124.1, 5.2, 23, 'F'),
        (5, 129.2, 5.3, 42, 'M'),
    ], ['id', 'weight', 'height', 'age', 'gender'])

rdd = df.rdd
print(rdd.collect())

df.select("id","age").filter("age>33").show()
df.select("gender").where("id==1").show()
df.select("age").distinct().show()
print('Count of rows: {0}'.format(df.count()))
print('Distinct Count is : %s' %(df.distinct().count()))
print('Distinct Count of age is: %s' % (df.select("age").distinct().count()))
df = df.dropDuplicates()
df.show()

df.groupby('gender').count().show()


