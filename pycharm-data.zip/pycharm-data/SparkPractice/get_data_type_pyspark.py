from struct import Struct
import json
from datetime import datetime

from dateutil.relativedelta import relativedelta
from pyspark import rdd
from datetime import timedelta
from pyspark.sql.types import DecimalType
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, unix_timestamp, Column as col, trim
import pyspark.sql.functions as F


def restore_datatypes(input_df, datatype_dict):
    for key, value in datatype_dict.items():
        input_df = input_df.withColumn(key, input_df[key].cast(value))
    return input_df


def trim_and_delimiter_replace(input_df):
    print("converted through method")
    for column in df.columns:
        input_df = input_df.withColumn(column,
                                       F.regexp_replace(F.trim(F.col(column).cast('string')), "[\\\|*~\$#\t]", "d"))
    return input_df


spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()

df = spark.read.json('samplejson5_14.json', multiLine=True)

df = df.withColumn('Timestamp', lit('2018-12-18T06:27:07Z'))
df = df.withColumn('Timestamp', F.to_timestamp('Timestamp', "yyyy-MM-dd'T'hh:mm:ss'Z'"))
df = df.withColumn('sentTimestamp', lit(1563408000000))

df = df.withColumn('sentTimestamp',
                   ((df['sentTimestamp'] / 1000).cast("Timestamp"))).withColumn('cases', lit('')).withColumn(
    'Timestamp', F.date_format(df['Timestamp'], "yyyy-MM-dd").cast("date")).withColumn('number', lit(20)).withColumn(
    'flight_num', lit('\\ant#*$|\t'))
df = df.drop('ack')
print(df.schema['sentTimestamp'].dataType)
types_dict = {name: df.schema[name].dataType for name in df.schema.names}

df = trim_and_delimiter_replace(df)
df = restore_datatypes(df, types_dict)
df.show()
print(df.schema)
print(df.rdd.collect()[0])
one_month = datetime.today()
one_month_ago = int((datetime.today() - relativedelta(months=1)).strftime('%Y%m'))
# print(type(int(one_month_ago)))
# datetime.strptime(today, "%Y%m%d").strftime('%Y%m%d')
print(one_month_ago)
print("the value is", one_month_ago)


# name_dict = {name: name.dataType for name in df.schema.fields}
# print('name',name_dict)

def get_schema():
    schema = StructType([StructField("docType", StringType(), True),
                         StructField("sequence_number", StringType(), True),
                         StructField("event", StringType(), True),
                         StructField("agentId", StringType(), True),
                         StructField("dateCreated", StringType(), True),
                         StructField("ccaiCaseId", StringType(), True),
                         StructField("ccaiCaseStatus", StringType(), True),
                         StructField("sessionID", StringType(), True),
                         StructField("userId", StringType(), True),
                         StructField("status", StringType(), True),
                         StructField("groupId", StringType(), True),
                         StructField("createdDate", StringType(), True),
                         StructField("queueId", StringType(), True),
                         StructField("data", StringType(), True)
                         ])
    return schema

