from pkg_resources import resource_stream
import yaml


def load_configs():
    stream = resource_stream(__name__, "/config.yaml")
    configs = yaml.load(stream)
    return configs