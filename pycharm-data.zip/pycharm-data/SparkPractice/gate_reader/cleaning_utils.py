'''
    File name : CleanMetadata.py
    Author : Sakshi Sharma, Vijay Raj R
    Date created : 7/05/2019
    Date last modified : 7/15/2019
    Python Version : 2.x
    Status : Development
'''
import pyspark.sql.functions as F
import logging

log = logging.getLogger(__name__)


def schema_cleanse_basic(mapping, input_df):
    '''Step 1 - Typecast, and clean using supplied mapping'''
    for column, dtype in mapping.iteritems():
        try:
            dtype = str(dtype).lower()
            '''step A - Trim all White Spaces'''
            input_df = input_df.withColumn(column, F.trim(F.col(column)))

            if dtype == "string":
                input_df = input_df.withColumn(column, input_df[column].cast("string"))

            elif dtype == "long":
                input_df = input_df.withColumn(column, input_df[column].cast("long"))

            elif dtype == "bigint":
                input_df = input_df.withColumn(column, input_df[column].cast("bigint"))

            elif dtype == "integer" or dtype == "int":
                input_df = input_df.withColumn(column, input_df[column].cast("integer"))

            elif dtype == 'double':
                input_df = input_df.withColumn(column, input_df[column].cast('double'))

            elif dtype == 'decimal':
                input_df = input_df.withColumn(column, input_df[column].cast('decimal'))

            elif dtype == 'boolean':
                input_df = input_df.withColumn(column, input_df[column].cast('boolean'))
        except TypeError as ex:
            log.error('Casting Exception: ' + ex)
        # elif dtype == 'date':
        #    input_df = input_df.withColumn(column, input_df[column].cast('date'))
    return input_df


def rename_columns(rename_columns_dictionary, input_df):
    for col in rename_columns_dictionary:
        input_df = input_df.withColumnRenamed(col, rename_columns_dictionary[col])
    return input_df


def downcase_columns(input_df):
    input_df = input_df.toDF(*[c.lower() for c in input_df.columns])
    return input_df


def reorder_columns(input_df, columns_to_go_first):
    cols = input_df.columns
    for col in columns_to_go_first:
        cols.remove(col)
    return input_df.select(columns_to_go_first + cols)


def clean_metadata_df(input_df):
    metadata_df_pandas = input_df.toPandas()
    metadata_df_pandas = metadata_df_pandas[metadata_df_pandas['OUTPUTCOLUMNNAME'].str.strip().notnull()]
    # metadata_df_pandas ['OUTPUTCOLUMNNAME'] = metadata_df_pandas ['OUTPUTCOLUMNNAME'].str.strip()
    metadata_df_pandas.INPUTDATATYPE = metadata_df_pandas.INPUTDATATYPE.str.lower()
    metadata_df_pandas.OUTPUTDATATYPE = metadata_df_pandas.OUTPUTDATATYPE.str.lower()
    metadata_df_pandas.fillna(
        value={'INPUTDATATYPE': 'string', 'OUTPUTDATATYPE': metadata_df_pandas.INPUTDATATYPE}, inplace=True)
    return metadata_df_pandas


def gen_schema_dict(metadata_df_pandas):
    schema_dict = {row["INPUTCOLUMNNAME"]: row["OUTPUTDATATYPE"] for lab, row in metadata_df_pandas.iterrows()}
    return schema_dict


def gen_rename_cols_dict(metadata_df_pandas):
    rename_cols_dict = {row["INPUTCOLUMNNAME"]: row["OUTPUTCOLUMNNAME"] for lab, row in metadata_df_pandas.iterrows()}
    return rename_cols_dict


def gen_schema_dict_explicit(metadata_df_pandas):
    schema_dict_explicit = {
        row["INPUTCOLUMNNAME"]: [row["INPUTDATATYPE"], row["INPUTFORMAT"], row["OUTPUTDATATYPE"]] for lab, row in
        metadata_df_pandas.iterrows()
        if row["INPUTDATATYPE"] != row["OUTPUTDATATYPE"] and row["OUTPUTDATATYPE"] != 'string' and (
            row["OUTPUTDATATYPE"] == 'timestamp' or row["OUTPUTDATATYPE"] == 'date')}
    return schema_dict_explicit


def convert_long_to_timestamp(input_column, input_format, input_df):
    try:
        if input_format == 'millisec':
            input_df = input_df.withColumn(input_column, (input_df[input_column].cast("long") / 1000).cast("Timestamp"))
        elif input_format == 'epochtime':
            input_df = input_df.withColumn(input_column, (input_df[input_column] / 1000).cast("Timestamp"))
    except TypeError as ex:
        log.error('Timestamp casting Exception: ' + ex)
    return input_df


def convert_bigint_to_timestamp(input_column, input_format, input_df):
    try:
        if input_format == 'millisec':
            input_df = input_df.withColumn(input_column, (input_df[input_column].cast("long") / 1000).cast("Timestamp"))
        elif input_format == 'epochtime':
            input_df = input_df.withColumn(input_column, (input_df[input_column] / 1000).cast("Timestamp"))
    except TypeError as ex:
        log.error('Timestamp casting Exception: ' + ex)
    return input_df


def convert_long_to_date(input_column, input_format, input_df):
    try:
        if input_format == 'millisec':
            input_df = input_df.withColumn(input_column, (input_df[input_column].cast("long") / 1000).cast(
                "Timestamp").cast("Date"))
        elif input_format == 'epochtime':
            input_df = input_df.withColumn(input_column, (input_df[input_column] / 1000).cast(
                "Timestamp").cast("Date"))
    except TypeError as ex:
        log.error('Timestamp casting Exception: ' + ex)
    return input_df


def convert_string_to_timestamp(input_column, string_format, input_df):
    # For converting timestamps
    # if string_format == 'yyyy-MM-dd hh:mm:ss.SSS':
    #    input_df = input_df.withColumn(input_column, input_df[input_column].cast("timestamp"))
    #    input_df = input_df.withColumn(input_column, F.to_timestamp(input_column, format="yyyy-MM-dd HH:mm:ss"))
    # input_df = input_df.withColumn(input_column, F.to_timestamp(input_column, format="yyyy-MM-dd HH:mm:ss"))
    try:
        input_df = input_df.withColumn(input_column, input_df[input_column].cast("timestamp"))
    except ValueError as ex:
        log.error('Invalid literal for timestamp: ' + ex)
    return input_df


def convert_string_to_int(input_column, input_df):
    try:
        input_df = input_df.withColumn(input_column, input_df[input_column].cast("integer"))
    except ValueError as ex:
        log.error('Invalid literal for Integer: ' + ex)
    return input_df


# convert string/int to date format
def convert_string_to_date(input_column, string_format, input_df):
    string_format = str(string_format).upper()
    # For converting 12/26/2015
    if string_format == 'MM/DD/YYYY':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'MM/dd/yyyy'))
    # For converting 26/12/2015
    elif string_format == 'DD/MM/YYYY':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'dd/MM/yyyy'))
    # For converting 2015/12/26
    elif string_format == 'YYYY/MM/DD':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'yyyy/MM/dd'))
    # For converting 2015-12-26
    elif string_format == 'YYYY-MM-DD':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'yyyy-MM-dd'))
    # For converting 12262015
    elif string_format == 'MMDDYYYY':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'MMddyyyy'))
    # For converting 26122015
    elif string_format == 'DDMMYYYY':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'ddMMyyyy'))
    # For converting 20151226
    elif string_format == 'YYYYMMDD':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'yyyyMMdd'))
    # For converting DEC262015
    elif string_format == 'MONDDYYYY':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'MMMddyyyy'))
    # For converting 26DEC2015
    elif string_format == 'DDMONYYYY':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'ddMMMyyyy'))
    # For converting 26DEC15
    elif string_format == 'DDMONYY':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'ddMMMyy'))
    # For converting 122615
    elif string_format == 'DDMMYY':
        input_df = input_df.withColumn(input_column, F.to_date(input_df[input_column], 'ddMMyy'))

    return input_df


def convert_excel_days_to_date(string_column, string, input_df):
    try:
        input_df = input_df.withColumn(string_column, F.date_add(F.lit('1899-12-30'), int(string)))
    except ValueError as ex:
        log.error('Invalid literal for Integer: ' + ex)
    return input_df


# Timestamp functions
def convert_long_to_ts_from_sec(column, input_df):
    try:
        input_df = input_df.withColumn(column, (input_df[column].cast("long").cast("timestamp")))
    except TypeError as ex:
        log.error('Timestamp casting exception: ' + ex)
    return input_df


def convert_long_to_ts_from_millisec(column, input_df):
    try:
        input_df = input_df.withColumn(column, (input_df[column].cast("long") / 1000).cast("timestamp"))
    except TypeError as ex:
        log.error('Timestamp casting exception: ' + ex)
    return input_df


def add_current_gmt(gmt_column, input_df):
    input_df = input_df.withColumn(gmt_column, F.current_timestamp())
    return input_df


def convert_zonespecific_ts(ts_column, input_df, zone):
    input_df = input_df.withColumn(ts_column, F.from_utc_timestamp(F.ts_column, zone))
    return input_df


def schema_cleanse_explicit(mapping, input_df):
    for key, value in mapping.iteritems():
        expr = "convert_" + mapping[key][0].encode('utf8') + "_to_" + mapping[key][2].encode('utf8') + "('" + key.encode('utf8') + "', '" + mapping[key][1].encode('utf8') + "', " + "input_df)"
        input_df = eval(expr)
    return input_df


def identity(x):
    return x
