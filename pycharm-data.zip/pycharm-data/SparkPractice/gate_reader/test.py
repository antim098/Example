import datetime
from pyspark.sql import DataFrame, Column, Row
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField
from pyspark.sql.types import BooleanType, IntegerType, LongType, StringType, TimestampType
from gate_reader.event_log import cleanandparse


def test_GENERATED_TEST(spark_session):
    input_0_records = [
        Row(EventId=107346734, EventTypeId=11040, EventTimestamp=1566463277290, PcdrId=None, AirlineCode='UA',
            FlightNumber='2139', DepartureStation='EWR', ArrivalStation='ORD', DepartureDate=1566432000000, Sent=True,
            SentTimestamp=1566463278020, SendAttempts=1),
        Row(EventId=107346735, EventTypeId=11020, EventTimestamp=1566463278793, PcdrId=None, AirlineCode='UA',
            FlightNumber='0928', DepartureStation='LHR', ArrivalStation='ORD', DepartureDate=1566432000000, Sent=True,
            SentTimestamp=1566463280083, SendAttempts=1),
        Row(EventId=107346736, EventTypeId=4000, EventTimestamp=1566463279397, PcdrId=13262887, AirlineCode='UA',
            FlightNumber='0953', DepartureStation='MUC', ArrivalStation='ORD', DepartureDate=1566432000000, Sent=True,
            SentTimestamp=1566463280330, SendAttempts=1),
        Row(EventId=107346737, EventTypeId=11030, EventTimestamp=1566463283500, PcdrId=None, AirlineCode='UA',
            FlightNumber='1858', DepartureStation='MCO', ArrivalStation='IAH', DepartureDate=1566432000000, Sent=True,
            SentTimestamp=1566463284460, SendAttempts=1),
        Row(EventId=107346738, EventTypeId=11030, EventTimestamp=1566463300587, PcdrId=None, AirlineCode='UA',
            FlightNumber='0928', DepartureStation='LHR', ArrivalStation='ORD', DepartureDate=1566432000000, Sent=True,
            SentTimestamp=1566463300893, SendAttempts=1)
    ]
    input_0_schema = StructType([
        StructField('EventId', IntegerType(), True),
        StructField('EventTypeId', IntegerType(), True),
        StructField('EventTimestamp', LongType(), True),
        StructField('PcdrId', IntegerType(), True),
        StructField('AirlineCode', StringType(), True),
        StructField('FlightNumber', StringType(), True),
        StructField('DepartureStation', StringType(), True),
        StructField('ArrivalStation', StringType(), True),
        StructField('DepartureDate', LongType(), True),
        StructField('Sent', BooleanType(), True),
        StructField('SentTimestamp', LongType(), True),
        StructField('SendAttempts', IntegerType(), True)
    ])
    input_0 = spark_session.createDataFrame(input_0_records, input_0_schema)

    input_1_records = [
        Row(INPUTCOLUMNNAME='EventId', INPUTDATATYPE='numeric() identity', INPUTFORMAT=None,
            OUTPUTCOLUMNNAME='event_id', OUTPUTDATATYPE='integer', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None,
            COMMENT=None, STARTPOSITION=None, LENGTH=None),
        Row(INPUTCOLUMNNAME='EventTypeId', INPUTDATATYPE='int', INPUTFORMAT=None, OUTPUTCOLUMNNAME='event_type_id',
            OUTPUTDATATYPE='integer', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None,
            LENGTH=None),
        Row(INPUTCOLUMNNAME='EventTimestamp', INPUTDATATYPE='long', INPUTFORMAT='epochtime',
            OUTPUTCOLUMNNAME='event_timestamp_dtl', OUTPUTDATATYPE='timestamp', OUTPUTFORMAT='yyyy-MM-dd HH:mm:ss.sss',
            COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None, LENGTH=None),
        Row(INPUTCOLUMNNAME='PcdrId', INPUTDATATYPE='numeric', INPUTFORMAT=None, OUTPUTCOLUMNNAME='passenger_record_id',
            OUTPUTDATATYPE='integer', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None,
            LENGTH=None),
        Row(INPUTCOLUMNNAME='AirlineCode', INPUTDATATYPE='char', INPUTFORMAT=None, OUTPUTCOLUMNNAME='airline_code',
            OUTPUTDATATYPE='string', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None,
            LENGTH=None),
        Row(INPUTCOLUMNNAME='FlightNumber', INPUTDATATYPE='varchar', INPUTFORMAT=None, OUTPUTCOLUMNNAME='flight_number',
            OUTPUTDATATYPE='string', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None,
            LENGTH=None),
        Row(INPUTCOLUMNNAME='DepartureStation', INPUTDATATYPE='char', INPUTFORMAT=None,
            OUTPUTCOLUMNNAME='departure_station', OUTPUTDATATYPE='string', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None,
            COMMENT=None, STARTPOSITION=None, LENGTH=None),
        Row(INPUTCOLUMNNAME='ArrivalStation', INPUTDATATYPE='char', INPUTFORMAT=None,
            OUTPUTCOLUMNNAME='arrival_station', OUTPUTDATATYPE='string', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None,
            COMMENT=None, STARTPOSITION=None, LENGTH=None),
        Row(INPUTCOLUMNNAME='DepartureDate', INPUTDATATYPE='long', INPUTFORMAT='epochtime',
            OUTPUTCOLUMNNAME='departure_dtl', OUTPUTDATATYPE='timestamp', OUTPUTFORMAT='yyyy-MM-dd HH:mm:ss.sss',
            COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None, LENGTH=None),
        Row(INPUTCOLUMNNAME='Sent', INPUTDATATYPE='bit', INPUTFORMAT=None, OUTPUTCOLUMNNAME='sent',
            OUTPUTDATATYPE='boolean', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None,
            LENGTH=None),
        Row(INPUTCOLUMNNAME='SentTimestamp', INPUTDATATYPE='long', INPUTFORMAT='epochtime',
            OUTPUTCOLUMNNAME='sent_timestamp_dtl', OUTPUTDATATYPE='timestamp', OUTPUTFORMAT='yyyy-MM-dd HH:mm:ss.sss',
            COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None, LENGTH=None),
        Row(INPUTCOLUMNNAME='SendAttempts', INPUTDATATYPE='int', INPUTFORMAT=None, OUTPUTCOLUMNNAME='send_attempts',
            OUTPUTDATATYPE='integer', OUTPUTFORMAT=None, COLUMNDESCRIPTION=None, COMMENT=None, STARTPOSITION=None,
            LENGTH=None)
    ]
    input_1_schema = StructType([
        StructField('INPUTCOLUMNNAME', StringType(), True),
        StructField('INPUTDATATYPE', StringType(), True),
        StructField('INPUTFORMAT', StringType(), True),
        StructField('OUTPUTCOLUMNNAME', StringType(), True),
        StructField('OUTPUTDATATYPE', StringType(), True),
        StructField('OUTPUTFORMAT', StringType(), True),
        StructField('COLUMNDESCRIPTION', StringType(), True),
        StructField('COMMENT', StringType(), True),
        StructField('STARTPOSITION', StringType(), True),
        StructField('LENGTH', StringType(), True)
    ])
    #input_1 = spark_session.createDataFrame(input_1_records, input_1_schema)
    input_1 =

    actual_output = cleanandparse(input_0, input_1)

    expected_output_records = [
        Row(event_id=107025565, event_type_id=11010, event_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 45),
            passenger_record_id=None, airline_code='UA', flight_number='0951', departure_station='BRU',
            arrival_station='IAD', departure_dtl=datetime.datetime(2019, 8, 18, 0, 0, 0), sent=True,
            sent_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 47), send_attempts=1),
        Row(event_id=107025566, event_type_id=11040, event_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 49),
            passenger_record_id=None, airline_code='UA', flight_number='0975', departure_station='GVA',
            arrival_station='IAD', departure_dtl=datetime.datetime(2019, 8, 18, 0, 0, 0), sent=True,
            sent_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 51), send_attempts=1),
        Row(event_id=107025567, event_type_id=11020, event_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 51),
            passenger_record_id=None, airline_code='UA', flight_number='0951', departure_station='BRU',
            arrival_station='IAD', departure_dtl=datetime.datetime(2019, 8, 18, 0, 0, 0), sent=True,
            sent_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 53), send_attempts=1),
        Row(event_id=107025568, event_type_id=11050, event_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 55),
            passenger_record_id=None, airline_code='UA', flight_number='0975', departure_station='GVA',
            arrival_station='IAD', departure_dtl=datetime.datetime(2019, 8, 18, 0, 0, 0), sent=True,
            sent_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 57), send_attempts=1),
        Row(event_id=107025569, event_type_id=11030, event_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 57),
            passenger_record_id=None, airline_code='UA', flight_number='0951', departure_station='BRU',
            arrival_station='IAD', departure_dtl=datetime.datetime(2019, 8, 18, 0, 0, 0), sent=True,
            sent_timestamp_dtl=datetime.datetime(2019, 8, 18, 8, 36, 59), send_attempts=1)
    ]
    expected_output_schema = StructType([
        StructField('event_id', IntegerType(), True),
        StructField('event_type_id', IntegerType(), True),
        StructField('event_timestamp_dtl', TimestampType(), True),
        StructField('passenger_record_id', IntegerType(), True),
        StructField('airline_code', StringType(), True),
        StructField('flight_number', StringType(), True),
        StructField('departure_station', StringType(), True),
        StructField('arrival_station', StringType(), True),
        StructField('departure_dtl', TimestampType(), True),
        StructField('sent', BooleanType(), True),
        StructField('sent_timestamp_dtl', TimestampType(), True),
        StructField('send_attempts', IntegerType(), True)
    ])
    expected_output = spark_session.createDataFrame(expected_output_records, expected_output_schema)

    assert (str(actual_output.collect()) == str(expected_output.collect())) and True
test_GENERATED_TEST(SparkSession)
