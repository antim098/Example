from gate_reader import cleaning_utils as utils

def cleanandparse(raw_df, metadata_df):
    # Generic cleaning logic
    metadata_df_pandas = utils.clean_metadata_df(metadata_df)
    schema_dict = utils.gen_schema_dict(metadata_df_pandas)
    schema_dict_explicit = utils.gen_schema_dict_explicit(metadata_df_pandas)
    rename_cols_dict = utils.gen_rename_cols_dict(metadata_df_pandas)
    raw_df = utils.schema_cleanse_basic(schema_dict, raw_df)
    raw_df = utils.schema_cleanse_explicit(schema_dict_explicit, raw_df)
    raw_df = utils.rename_columns(rename_cols_dict, raw_df)
    raw_df = utils.downcase_columns(raw_df)
    # Return final dataframe
    return raw_df