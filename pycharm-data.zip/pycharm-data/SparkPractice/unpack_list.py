import datetime


def find_len(one, two, three, four):
    print('len is', len(one), len(two), len(three), len(four))


list = ['one', 'two', 'three']
new = 'newname'
find_len(*[c for c in list], new)
new_list = []
twp = ['antim']
list.extend(twp)
print(list)

today = datetime.datetime.today() - datetime.timedelta(2)
from_date = today - datetime.timedelta(29)
to_date = today + datetime.timedelta(1)
print(from_date.strftime("%Y-%m-%d"))
print(to_date.strftime("%Y-%m-%d"))
