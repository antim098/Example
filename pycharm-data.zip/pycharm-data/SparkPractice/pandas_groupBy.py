from datetime import datetime

from dateutil.relativedelta import relativedelta
from pyspark import rdd
from datetime import timedelta
from pyspark.sql.types import DecimalType

from pyspark.sql.functions import lit, unix_timestamp, Column as col, trim
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()

df = spark.read.csv('pandas_date.csv', header=True)
df = df.toPandas()
df = df[df.groupby(['execution_date'])['last_updated_time'].transform(max) == df['last_updated_time']]

last_updated_time = df.loc[df['execution_date'] == '19-20-12','last_updated_time'].iloc[0] if (df.loc[df['execution_date'] == '19-20-12']).size > 0 else ''
#last_updated_time = df.loc[df['execution_date'] == '19-20-12','last_updated_time'].iloc[0] if '19-20-12' in df.execution_date.values else ''
print(last_updated_time)