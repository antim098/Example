from struct import Struct
import json
import datetime

import pandas as pd
from dateutil.relativedelta import relativedelta
import numpy as np
from pyspark import rdd, SQLContext
from datetime import timedelta
from pyspark.sql.types import DecimalType
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, unix_timestamp, Column as col, trim
import pyspark.sql.functions as F
from pyspark.sql import types as T
from pyspark import SparkContext


def getSchema():
    schema = T.StructType([
        T.StructField('document_id', T.StringType(), True),
        T.StructField('call_driver_level_1', T.StringType(), True),
        T.StructField('call_driver_level_2', T.StringType(), True),
        T.StructField('call_driver_level_3', T.StringType(), True),
        T.StructField('call_driver_level_4', T.StringType(), True),
        T.StructField('call_driver_level_5', T.StringType(), True), ])

    return schema


def decode_code_driver(document_id, call_driver):
    value_list = []
    value_list.append(document_id)
    temp_list = call_driver.split('>>')
    value_list.extend(temp_list)
    while len(value_list) < 6:
        value_list.append(None)
    return value_list


columns = ['sentence', 'ua_call_driver']
spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()
df = spark.read.csv('sample_export.csv', header=True)
df.show(truncate=False)

df = df.withColumn('ua_call_driver', F.explode(F.split(df['ua_call_driver'], '[|]')))
df.show()

# df_pandas = df.toPandas()
# ndf[['call_driver_level_1', 'call_driver_level_2', 'call_driver_level_3']] = df_pandas['ua_call_driver'].str.split(
#     pat='>>', expand=True)
# df_pandas[['First','Last']] = df_pandas.ua_call_driver.str.split("_",expand=True).fillna(np.nan)
# df_pandas[['call_driver_level_1','call_driver_level_2','call_driver_level_3']] = df_pandas.ua_call_driver.apply(lambda x: pd.Series(str(x).split(">>")))
# df_pandas = df_pandas.join(df_pandas['ua_call_driver'].str.split('>>', expand=True).add_prefix('sec').fillna(np.nan))
# print(df_pandas['call_driver_level_3'])
# df_pandas['new'] = df_pandas['ua_call_driver'].str.split('>>').tolist()

temp_drivers = df.rdd.map(lambda x: decode_code_driver(x['document_id'], x['ua_call_driver']))
print(temp_drivers.collect())
schema = getSchema()
df = spark.createDataFrame(temp_drivers, schema=schema)
repartitioned_df = df.repartition(F.col('document_id'))
# empty_df = spark.createDataFrame([], schema=schema)
# empty_df = empty_df.withColumn('document_id', lit('1234566'))
# repartitioned_df = empty_df.repartition(1, F.col('document_id'))
# repartitioned_df.show()
repartitioned_df.show()
test_df = repartitioned_df.filter(repartitioned_df.document_id == '123')
test_df.show()
if bool(test_df.head(1)):
    print("test_df is not empty")
else:
    print("test_df is empty")

input_schema = T.StructType([T.StructField('Temp', T.StringType(), True)])
empty_df = spark.createDataFrame([('Deleted',)], input_schema)
empty_df.show()
# df.createOrReplaceTempView('call_driver_df')

# df.show()
# final_df = spark.sql('''SELECT document_id,
#     CAST(collect_set(call_driver_level_1) as string) as call_driver_level_1,
#     CAST(collect_set(call_driver_level_2) as string) as call_driver_level_2,
#     CAST(collect_set(call_driver_level_3) as string) as call_driver_level_3
#     from final_df where
#     (call_driver_level_1 is not null and call_driver_level_1 not like '') OR
#     (call_driver_level_2 is not null and call_driver_level_2 not like '') OR
#     (call_driver_level_3 is not null and call_driver_level_3 not like '')
#     group by document_id
#     ''')
#
# final_df.show()

# temp_drivers = [df_pandas['document_id'],df_pandas['ua_call_driver'].str.split('>>').tolist()]
# # print(temp_drivers)
# # for item in temp_drivers:
# #     if type(item) is list:
# #         while len(item) < 5:
# #             item.append(None)
#
# print(temp_drivers)
new_cols = ['call_driver_level_1', 'call_driver_level_2', 'call_driver_level_3', 'call_driver_level_4',
            'call_driver_level_5']
#
# final_df = df_pandas.join(pd.DataFrame(temp_drivers,
#                                        columns=new_cols))
# print('Creating spark dataframe')
# schema = getSchema()
# # final_df = spark.createDataFrame(final_df, schema=schema)
# print(final_df.to_string())
# print('\n')
# print('\n')
#
# spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()
# df = spark.read.csv('stt_metadata.csv', header=True)
# panda_df = df.toPandas()
# column_list = panda_df['INPUTCOLUMNNAME'].to_list()
# print(column_list)


# columns = ['document_id', 'ua_call_driver']
# final_df.drop(columns, inplace=True, axis=1)
#
# print(final_df.to_string())
# final_df.to_csv('pd_df.csv', index=False)
# final_df.select('ua_call_driver')
# final_df = final_df.orderBy('datestr').dropDuplicates(subset=['col1'])
# final_df = final_df.sort_values('sentence_start_pos', ascending=True).drop_duplicates(
#     subset=['document_id', 'call_driver_level_1'], keep='first')
# final_df = spark.read.csv('demo.csv', header=True)
# final_df.createOrReplaceTempView('final_df')
