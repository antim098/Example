from pyspark.sql import SparkSession, functions as F, types as T, Window
from pyspark.sql.functions import  Column as col

import time

import numpy as np
from pyspark.sql.types import FloatType
import pandas
from pyspark.sql.types import StructType, ArrayType, TimestampType, DateType, StringType


def get_range_info_schema():
    range_info_schema = T.StructType([
        T.StructField('range_num', T.StringType(), True),
        T.StructField('execution_date', T.StringType(), True)])
    return range_info_schema


spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()

df = spark.createDataFrame([('1', '20200129')], schema=get_range_info_schema())

sample_df = spark.read.csv('one.csv',header=True)

sample_df.createOrReplaceTempView('demo')

# df = spark.sql('''SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY call_id,verbatim_type ORDER BY ingestion_date desc)
#              RN FROM demo) T WHERE RN = 1''')
df = sample_df.withColumn("row_num", F.rank().over(Window.partitionBy("call_id",'verbatim_type').orderBy(F.col("ingestion_date").desc())))
df = df.filter('row_num != 1')
df.show()