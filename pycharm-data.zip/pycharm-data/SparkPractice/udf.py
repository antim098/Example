from pyspark.sql.functions import udf
from pyspark.context import  SparkContext

schema = StructType([
    StructField("Value1",DoubleType(),False),
StructField("Value2",DoubleType(),False)
])

