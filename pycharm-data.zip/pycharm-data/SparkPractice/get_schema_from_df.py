from pyspark.sql.types import DecimalType, IntegerType, StructType, StructField
from pyspark.sql import SparkSession
import ast
from pyspark.sql import types
from pyspark.sql.functions import lit, unix_timestamp, Column as col, trim
import pyspark.sql.functions as F
import time

spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()

metadata_df = spark.read.csv('demo.csv', header=True)
# schema_list = [metadata_df.collect()[a] for a in range(0, metadata_df.count())]
# print(schema_list)
# print("\n", metadata_df.collect()[a])
names = [name for name in metadata_df.schema.names]
datatypes = [f.dataType for f in metadata_df.schema.fields]

schema = [('%s' % f) for f in metadata_df.schema.fields]



daily = ast.literal_eval('False')
since = ast.literal_eval('False')

if (not (not since and not daily)):
    print('inside if')
else:
    print('inside else')



