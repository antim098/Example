from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, unix_timestamp, Column as col, concat
import pyspark.sql.functions as F
import numpy as np
from pyspark.sql.types import FloatType
from pyspark.sql.types import StructType, ArrayType, TimestampType, DateType, StringType


def find_median(values_list):
    try:
        median = np.median(values_list)  # get the median of values in a list in each row
        return float(median)  # round(float(median), 2)
    except Exception:
        return None  # if there is anything wrong with the given values


median = F.udf(find_median, FloatType())

spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()
parsed_df = spark.read.csv('parsed_stt.csv', header=True)
parsed_df.createOrReplaceTempView('parsed_df')
input_df = spark.sql(
    '''select *, concat(routercallkeycallid,routercallkeyday) as call_id from parsed_df limit 10''')

input_df = input_df.withColumn('agent_clarity', input_df['agent_clarity'].cast('double')).withColumn('sentiment',
                                                                                                     input_df[
                                                                                                         'sentiment'].cast(
                                                                                                         'double'))
average_agent_clarity_df = input_df.groupBy('verbatim_type', 'call_id').avg(
    'agent_clarity', 'sentiment').withColumnRenamed("avg(agent_clarity)", "average_agent_clarity").withColumnRenamed(
    "avg(sentiment)", "average_sentiment")

join_condition = (input_df.verbatim_type == average_agent_clarity_df.verbatim_type) & (
        input_df.call_id == average_agent_clarity_df.call_id)
final_df = input_df.join(average_agent_clarity_df, join_condition).select(
    input_df["*"], average_agent_clarity_df["average_agent_clarity"], average_agent_clarity_df['average_sentiment'])

median_agent_clarity_df = final_df.groupBy('verbatim_type', 'call_id').agg(
    median(F.collect_list(col("agent_clarity"))).alias("median_agent_clarity"))

join_condition = (final_df.verbatim_type == median_agent_clarity_df.verbatim_type) & (
        final_df.call_id == median_agent_clarity_df.call_id)

final_df = final_df.join(median_agent_clarity_df, join_condition).select(
    final_df["*"], median_agent_clarity_df["median_agent_clarity"])

final_df.select('*').where('call_id = 637.06719744525712032187').show()

final_df = final_df.withColumn('interaction_duration', unix_timestamp(final_df['biinteractionduration'], 'HH:mm:ss'))

sum_interaction_df = final_df.groupBy('verbatim_type', 'call_id').sum('interaction_duration')
sum_interaction_df = sum_interaction_df.withColumn('interaction_duration',
                                                   F.from_unixtime(sum_interaction_df['sum(interaction_duration)'],
                                                                   "HH:mm:ss"))

final_df = final_df.drop('interaction_duration')
sum_interaction_df.show(3)

join_condition = (final_df.verbatim_type == sum_interaction_df.verbatim_type) & (
        final_df.call_id == sum_interaction_df.call_id)

final_df = final_df.join(sum_interaction_df, join_condition).select(
    final_df["*"], sum_interaction_df["interaction_duration"])

sum_word_count_df = final_df.groupBy('verbatim_type', 'call_id').sum('cb_document_word_count').withColumnRenamed(
    'word_count')

join_condition = (final_df.verbatim_type == sum_word_count_df.verbatim_type) & (
        final_df.call_id == sum_word_count_df.call_id)

final_df = final_df.join(sum_word_count_df, join_condition).select(
    final_df["*"], sum_word_count_df["word_count"])

transform = input_df.groupBy('verbatim_type', 'call_id').avg('cb_sentence_ease_score').withColumnRenamed(
    'avg(cb_sentence_ease_score)','cb_effort')

    input_df = input_df.join(transform, join_condition).select(
            input_df["*"], transform["cb_effort"])


final_df.show(100)
