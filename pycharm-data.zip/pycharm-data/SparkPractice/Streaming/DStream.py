from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.sql import HiveContext
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()

df = spark.read.json('/home/impadmin/Downloads/samplejson5_14.json', multiLine=True)

df.printSchema()



# ssc = StreamingContext(sc, 5)
#
# lines = ssc.socketTextStream("localhost", 7777)
#
# words = lines.flatMap(lambda line: line.split(" "))
#
# pairs = words.map(lambda word: (word, 1))
# wordCounts = pairs.reduceByKey(lambda x, y: x + y)
#
# wordCounts.pprint()
#
# ssc.start()
# ssc.awaitTermination()
