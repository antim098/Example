from datetime import date
import datetime
from pytz import timezone
from dateutil.relativedelta import relativedelta
import time

import pytz

A = ['z', 'b', 'a', 'f', 'e']
B = ['1', '7', '2', '4', '5']
A.sort()
print(A)
C = zip(A, B)



for i, j in C:
    print(i, j)

# print(datetime.date.today())
A = {'name': 'aa'}
A = 1


if A.get('name') in {'a', 'b', 'c'}:
    print('here')
else:
    print('there')

current_date_time = datetime.datetime.now() - relativedelta(days=0)
print('now', current_date_time)
current_date_time = current_date_time.strftime("%Y-%m-%d-%H-%M")
current_date_time = datetime.datetime.strptime(current_date_time, "%Y-%m-%d-%H-%M")
print("Current Date Time : ", str(current_date_time))
back_date_time = current_date_time.replace(hour=00, minute=00)
print("Current Date Time : ", str(back_date_time))



central = timezone('US/Central')
utc = timezone('utc')
print('...................')
print('gmt_time', time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(1579860001)))
print('hour is', datetime.datetime.fromtimestamp(1580698800).strftime('%Y-%m-%d-%H'))

# since_date = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(
#     since_config_df.loc[since_config_df['from_date'] == from_date, 'last_updated_time'].iloc[0])) \
#     if from_date in since_config_df.from_date.values else \
#     time.strftime("%Y-%m-%d %H:%M:%S",
#                   time.gmtime(config_df.loc[config_df['last_queried_date'] == from_date, 'last_updated_time'].iloc[0]))
print(central.localize(datetime.datetime.fromtimestamp(1578693992)).astimezone(utc).strftime('%Y-%m-%d %H:%M:%S'))
print(datetime.datetime.strptime(
    str(datetime.datetime.fromtimestamp(1578693992)), '%Y-%m-%d %H:%M:%S') + datetime.timedelta(minutes=int(1)))

range1 = '20191201'
range2 = '20200229'
today = (datetime.datetime.today() - relativedelta(days=1)).strftime('%Y%m%d')
print('-----', type(today))

date1 = datetime.datetime.strptime(range1, '%Y%m%d')
date2 = datetime.datetime.strptime(range2, '%Y%m%d')
A = ''
B = 'A'

print(bool(A))
print(bool(B))

# print('today is ',today)
# print(range1)
# print(type(range1))
# print(date1 < today < date2)

central = timezone('US/Central')
current_time = datetime.datetime.now(central)
cst_time_check = current_time.replace(hour=10, minute=00) + relativedelta(hours=4)
print('entral time', current_time)
print('time', cst_time_check)
if today.weekday() == 6:
    print('Sunday')
else:
    print('wrong index')

# print(datetime.datetime.now(pytz.timezone('US/Central')))
# convert string to datetime
date = '20200304'
check = datetime.datetime.strptime('20200304', '%Y%m%d')
string_to_date = datetime.datetime.strptime(date, '%Y%m%d').date()
print(',,,,,', string_to_date.strftime('%Y%m%d'))
print('last day of month', (string_to_date.replace(day=1) - relativedelta(days=1)).strftime('%Y%m%d'))

feb_date = datetime.datetime.strptime('2020229', '%Y%m%d')
previous_month = (feb_date).strftime('%Y%m')
month_check = (check - relativedelta(months=2)).replace(day=1).strftime('%Y%m')

print('previous month', previous_month)
print('month check', month_check)
if previous_month >= month_check:
    print('no need to change month')
else:
    print('month needs to be changed')
date_check = string_to_date - relativedelta(months=2)
if date_check >= check:
    print("date has reached jan")
else:
    print("date has not reached jan")
print('***', string_to_date)
print(type(string_to_date))

current_date_time = datetime.datetime.now(central)
cur_date = current_date_time
new_date = current_date_time.replace(hour=10, minute=00)

# d1=datetime.strptime(cur_date,'%I:%M %p')
# d2 = datetime.strptime(new_date,'%I:%M %p')
# print(type(d1))


print(cur_date)
print(new_date)
if new_date > cur_date:
    print("true")
else:
    print("false")
