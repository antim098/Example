from pyspark.sql import SparkSession, functions as F, types as T, Window
from pyspark.sql import types
from pyspark.sql.functions import lit, unix_timestamp, Column as col, trim
import json
import datetime
import time

import numpy as np
from pyspark.sql.types import FloatType
import pandas
from pyspark.sql.types import StructType, ArrayType, TimestampType, DateType, StringType
name = ' antim '
print(name)
print(name.strip())
value_list =[]
value_list.extend([1,2])
print(len(value_list))
print(value_list)
print(time.strftime("%Y-%m-%d-%H"))
print(datetime.date.today())

def get_classification_timestamp(model, timestamps):
    classification_timestamp = ''
    if timestamps is not None:
        data = json.loads(timestamps)
        print('data', data)
        # for classification_model in data:
        classification_timestamp = str(data.get(model, ''))

    return classification_timestamp


def get_range_info_schema():
    range_info_schema = T.StructType([
        T.StructField('classifications', T.StringType(), True),
        T.StructField('classification_dtmz', T.StringType(), True)])
    return range_info_schema


spark = SparkSession.builder.appName('abc').master('local[*]').enableHiveSupport().getOrCreate()

get_classification_timestamp = F.udf(get_classification_timestamp)
df = spark.read.option("delimiter", "|").option("header", "true").csv("classification_sample.csv")
#df = df.withColumn('classification_timestamp', get_classification_timestamp('classifications', 'classification_dtmz'))
df = df.withColumn('classification_dtmz', (F.trim(get_classification_timestamp('classifications', 'classification_dtmz')).cast('double')/1000).cast('timestamp'))
#df = df.withColumn('classification_dtmz',F.to_timestamp(df['classification_timestamp'].cast('double')))
df = df.withColumn('new',F.concat(F.year('classification_dtmz').cast('string'),lit('-'),F.month('classification_dtmz').cast('string')))
df = df.withColumn('ingestion_hour', F.from_unixtime("epoch", 'yyyy-MM-dd-HH'))
df = df.withColumn('hour', F.unix_timestamp("ingestion_hour", 'yyyy-MM-dd-HH'))
df.show(truncate=False)
new_df = df.filter(df['ingestion_hour'] == '2020-01-31-10')
new_df.show()

w = Window.partitionBy('natural_id').orderBy(F.col('ingestion_hour').desc())
final_df = df.withColumn('rn', F.row_number().over(w)).where(F.col('rn') == 1).drop(F.col('rn')).drop(F.col('ingestion_time'))
print('final_df')
final_df.show()
