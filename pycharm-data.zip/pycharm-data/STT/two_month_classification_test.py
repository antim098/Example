import datetime
from pytz import timezone
from dateutil.relativedelta import relativedelta

today = '1'
a = ''

today = a if a is not '' else 1
print()

one = '1599000000'
print(one)
on = str(int(one))
print(on)
if one == on:
    print('one is one')
else:
    print('one is not one')

print('1') if bool(a) else print('2')
weekly_last_updated_time = ''
print('bool value is',bool(weekly_last_updated_time))
two_month_last_updated_time = 'pp'
today = datetime.datetime.today()
print(today.replace(day=1))
#today = datetime.datetime.strptime('20200501', '%Y%m%d').date()
default_since_param = "2020-01-01 00:00:00"
survey_start_date = datetime.datetime.strptime('20200101', '%Y%m%d').date()

if (bool(weekly_last_updated_time)):
    print('weekly time is empty')
# weekly_to_date = weekly_conf['to_date'].values[0]
# if(weekly_to_date == (today - relativedelta(days=1)).strftime('%Y%m%d')):
#     weekly_ingestion_check = False

if (not bool(two_month_last_updated_time)):
    print('monthly time is empty')
    # This conition will be processed when last updated time is empty
    # Checking if we can run the two month ingestion process.
    two_month_ago_date = (today - relativedelta(months=2)).strftime('%Y%m%d')
    two_month_ago_date = datetime.datetime.strptime(two_month_ago_date, '%Y%m%d').date()
    print('two month ago date', two_month_ago_date)
    print('survey start date', survey_start_date)
    if two_month_ago_date >= survey_start_date:
        two_month_ingestion_check = True
        print('two month interval can now be taken into account for ingestion')
        complete_from_date = survey_start_date.strftime('%Y%m%d')
        print('from_date', complete_from_date)
        complete_to_date = (today.replace(day=1) - relativedelta(days=1)).strftime('%Y%m%d')
        print('to_date', complete_to_date)
        complete_since_date = default_since_param
    else:
        print('Still not reached the two month threshold')
        # updated_monthly_conf_df = spark.createDataFrame([], date_range_schema)
        # two_month_configuration.write_dataframe(updated_monthly_conf_df)
else:
    two_month_ingestion_check = True
    previous_to_date_month = datetime.datetime.strptime('20200221', '%Y%m%d').strftime('%Y%m')
    # previous_to_date_month = datetime.datetime.strptime(two_month_conf['to_date'].values[0], '%Y%m%d').strftime('%Y%m')
    month_check = (today - relativedelta(months=2)).strftime('%Y%m')
    print('previous to date', previous_to_date_month)
    print('month check', month_check)
    if previous_to_date_month >= month_check:
        # Iterating over the same two months as we have not reached new
        print(' Iterating over the same two months as we have not reached new')
        # complete_from_date = two_month_conf['from_date'].values[0]
        # complete_to_date = two_month_conf['to_date'].values[0]
        # complete_since_date = datetime.datetime.fromtimestamp(
        #     two_month_last_updated_time).strftime('%Y-%m-%d %H:%M:%S')
    else:
        print('Previous two month duration has been completed. Updating the two month interval')
        # Previous two month duration has been completed. Updating the two month interval
        complete_from_date = (today - relativedelta(months=2)).replace(day=1).strftime('%Y%m%d')
        print('new from date', complete_from_date)
        complete_to_date = (today.replace(day=1) - relativedelta(days=1)).strftime('%Y%m%d')
        print('new to date', complete_to_date)
        # complete_since_date = default_since_param
