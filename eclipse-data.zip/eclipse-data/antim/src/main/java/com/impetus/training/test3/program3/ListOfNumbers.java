
package com.impetus.training.test3.program3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** ListOfNumbers : This class contains methods which read data from a file and write only the integer values found in another file. */
public class ListOfNumbers {

    /** The log which is used to log messages on the console. We have used slf4j . */
    private static Logger log = LoggerFactory.getLogger(ListOfNumbers.class);

    /** The ArrayList of type Integer which will contain all the integers. which are read from the input file. */
    private static ArrayList<Integer> numberList = new ArrayList<>();

    /** The Path of the input file which is to be read. */
    private static Path inputPath = Paths.get("/home/impadmin/eclipse-workspace/antim/src/main/java/com/impetus/training/test3/program3");

    /** The Path of the output file in which integer values are to be written. */
    private static Path outputPath = Paths.get("/home/impadmin/eclipse-workspace/antim/src/main/java/com/impetus/training/test3/program3");

    /** Read list. This method reads the File whose name is specified by the user and searches for Integer values in it. All the found values are
     * stored in an ArrayList for future use.
     *
     * @param inputfileName
     *            this is the name of the file given by the user at the runtime.
     * @return true, if file is read successfully and it contains the integer values otherwise returns false. */
    static boolean readList(String inputfileName) {
        Boolean fileReadCheck = false;
        String fileName = inputPath.toString() + inputfileName; // Complete file location of the file given by the user.
        File inputFile = new File(fileName); // creating a File object and passing the location to it.
        try (Scanner fileScanner = new Scanner(inputFile).useDelimiter("[^\\d]+")) {

            /*
             * In the if condition we are checking whether the file specified by the user contains any data or not.If it is empty suitable exception
             * is thrown.
             */
            if (inputFile.length() == 0) {
                throw new EmptyFileException();
            }
            while (fileScanner.hasNextInt()) {
                numberList.add(fileScanner.nextInt());

            }
            if (numberList.isEmpty()) {
                fileReadCheck = false;
                throw new NoIntegerValueException();
            }
            fileReadCheck = true;
        } catch (FileNotFoundException e) {
            log.error("Unable to open file {} \n path is wrong or file dosen't exists", fileName);
        } catch (EmptyFileException e) {
            log.error("File you specified is empty");
        } catch (NoIntegerValueException e) {
            log.error("File you specified contains no Integer Values");
        }
        return fileReadCheck;
    }

    /** Write list: This method writes the integer values which are present in the ArrayList into the output file specified by the user.
     *
     * @param outputFileName
     *            the name of the file in which the output have to be written.
     * @return true, if successfully writes data into the file otherwise false if exception occurs */
    static boolean writeList(String outputFileName) {
        boolean fileWriteCheck = false;
        File outputFile = null;
        String fileName = outputPath.toString() + outputFileName;
        Path path = Paths.get(fileName);

        if (!Files.exists(path)) {
            log.error("File not Found");
            return fileWriteCheck;
        }

        outputFile = new File(fileName);

        try (FileWriter writer = new FileWriter(outputFile)) {

            Iterator<Integer> itr = numberList.iterator();

            if (itr.hasNext()) {
                fileWriteCheck = true;
                while (itr.hasNext()) {
                    writer.write("\n" + itr.next().toString());
                }
            }
        } catch (IOException e) {
            log.error("IO Error occured with the file");
        }

        return fileWriteCheck;
    }

    /** The main method : It contains the logic of getting user input and passing the same to respective methods.
     *
     * @param args
     *            the arguments */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        log.info("Enter the name of Input File");
        String inputFileName = sc.next();
        log.info("Enter the name of Output File");
        String outputFileName = sc.next();

        if (readList("/" + inputFileName) && writeList("/" + outputFileName)) {
            Iterator<Integer> iterator = numberList.iterator();
            log.info("Values added to the list are :");
            while (iterator.hasNext()) {
                log.info("{}", iterator.next());
                sc.close();
            }
        }
    }

}
