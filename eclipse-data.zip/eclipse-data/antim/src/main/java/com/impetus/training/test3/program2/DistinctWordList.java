package com.impetus.training.test3.program2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.StringTokenizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** DistinctWordList: This class performs read operation on an input File and prints all the distinct words found from it. */
public class DistinctWordList {

    /** Logger log :The slf4j logger to produce output on console. */
    private static Logger log = LoggerFactory.getLogger(DistinctWordList.class);

    /** Scanner */
    private static Scanner input = new Scanner(System.in);

    /** The word list : Defined to store the unique elements read from a file */
    private static ArrayList<String> wordList = new ArrayList<>();

    /** The printDistinctWords :This methods performs read operation an user given file using BufferedReader. And then gives out distinct words from
     * the file.
     * 
     * @param filePath
     *            The full path of the file from which distinct words have to be extracted.
     * @return true, if the file contains data and read operation is successfully performed. */
    static boolean printDistinctWords(String filePath) {
        Boolean fileCheck = false;
        String token;
        String line = null;
        String matchPattern = " .,:;0123456789";// this pattern will skip all the mentioned delimiters which are unwanted in words from alphabets

        try (FileReader fileReader = new FileReader(filePath); BufferedReader bufferedReader = new BufferedReader(fileReader)) {
            // FileReader reads text files in the default encoding.

            /*
             * the while loop extracts data from file line by line and then using the delimiters extracts words compares them with the words already
             * present in the list and thus maintains a list of distinct words.
             */
            while ((line = bufferedReader.readLine()) != null) {
                fileCheck = true;
                StringTokenizer st1 = new StringTokenizer(line, matchPattern);
                while (st1.hasMoreTokens()) {
                    token = st1.nextToken().toLowerCase();
                    if (!wordList.contains(token)) {
                        wordList.add(token);
                    }
                }

            }
            if (wordList.isEmpty()) {
                log.error("File contains No words");
                return false;
            }
        } catch (FileNotFoundException ex) {
            log.error("Unable to open file {} \n Path Wrong or File Dosen't Exists", filePath);
        } catch (IOException e) {
            log.error("Error reading file {}", filePath);
            // Or we could just do this:
        }

        return fileCheck;
    }

    /** The main method which takes the user input of the File location and then calls suitable method by passing the location as a parameter.
     * 
     * @param args
     *            the arguments */
    public static void main(String[] args) {
        log.info("Enter the full path of the file");
        String path = input.nextLine();
        if (printDistinctWords(path)) {
            String word;
            Iterator<String> listIterator = wordList.iterator();
            log.info("The words found in the list are :");
            while (listIterator.hasNext()) {
                word = listIterator.next();
                log.info("{}", word);
            }

        }
    }
}
