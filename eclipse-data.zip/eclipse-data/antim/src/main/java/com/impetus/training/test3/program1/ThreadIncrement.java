package com.impetus.training.test3.program1;

import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Class ThreadIncrement : This class implments two threads one that increments it 1 lakh times and second which prints its value. */
public class ThreadIncrement {

    /** The Logger slf4j used to perform logging */
    private static Logger log = LoggerFactory.getLogger(ThreadIncrement.class);
    private static Scanner input = new Scanner(System.in);
    /** The number. */
    private static int number = 0;
    private static final int INCREMENT = 1000000;

    /** The main method. Contains main code of the class which performs the required functions.
     * 
     * @param args
     *            the arguments
     * @throws InterruptedException
     *             the interrupted exception */
    public static void main(String[] args) throws InterruptedException {

        // I have used cncept of Annonymous Innner class to create two thread objects and override the run method.

        Thread t1 = new Thread() {
            @Override
            public void run() {
                log.info("Enter number to increment :");
                number = input.nextInt();
                log.info("Incrementing the value of number through Thread 1:");
                for (int i = 0; i < INCREMENT; i++) {
                    number++;
                }
            }
        };

        Thread t2 = new Thread() {
            @Override
            public synchronized void run() {

                log.info("Printing Value through Thread 2");
                log.info("Value of number {}", number);

            }

        };
        
        t1.start();
        synchronized (t1) {
            t1.wait();
            t2.start();
        }
        synchronized (t2) {
            t2.notifyAll();
        }

    }
}
