package com.impetus.training.test3.program3;

/**
 * The Class NoIntegerValueException: User defined exception class.
 */
public class NoIntegerValueException extends Exception {

    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new custom exception.
     */
    public NoIntegerValueException() {
    
    super();
        
    }
    
    /**
     * Instantiates a new no integer value exception with parameter received.
     *
     * @param message : The message which is thrown with the exception.
     */
    public NoIntegerValueException(String message) {
        
        super(message);
            
        }
    
}
