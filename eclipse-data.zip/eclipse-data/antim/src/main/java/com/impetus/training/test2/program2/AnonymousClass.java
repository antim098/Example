package com.impetus.training.test2.program2;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;




/** Interface Calculate.
*Contains an abstract method sum which will be implemented in Anonymous Inner Class.
 */
interface Calculate {
 
 /**
  * Method Sum.
  *
  * @return Integer value after sum
  */
 int sum();
}

/** The Class Double which doubles the value using interface reference and method
 * got implemented in Anonymous Inner class. */
class Double {
  
  /**
   * Method doubleNumber.
   * @return Integer value after doubling the value.
     @param c which is interface reference */
  public int doubleNumber(Calculate c) {
    return c.sum() * 2;
  }

}

/** The Class AnonymousClass. */
public class AnonymousClass {

  /** The input. */
  private static Scanner input = new Scanner(System.in);

  /** The log. */
  private static Logger log = LoggerFactory.getLogger(AnonymousClass.class);

  /** The main method.
   *
   * @param args
   *          the arguments */
  public static void main(String[] args) {
    Double doubleClassObject = new Double();
    int result = doubleClassObject.doubleNumber(new Calculate() {
    private int num1;
    private int num2;
      public int sum() {
        
        try {
          log.info("Enter numbers to add:");
          num1 = input.nextInt();
          num2 = input.nextInt();
        } catch (InputMismatchException e) {
          log.info("Please enter only integer numbers");
          System.exit(0); 
        }
        return num1+num2;
      }
      
      });
    log.info("Double of the sum of numbers = {}", result);
  }

}
