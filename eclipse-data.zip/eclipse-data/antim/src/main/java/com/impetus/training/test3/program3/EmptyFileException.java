package com.impetus.training.test3.program3;

/**
 * The Class EmptyFileException : User defined exception class which catches exception when empty file is tried to be read.
 */
public class EmptyFileException extends Exception{

    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;


    /**
     * Instantiates a new empty file exception.
     */
    public EmptyFileException() {
   super();
    }
    
    
   /**
    * Instantiates a new empty file exception with message thrown along with the exception.
    *
    * @param message the message
    */
   public EmptyFileException(String message) {
       super(message);
   }
    
    
}
