package com.impetus.training.test2.program3;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** The Class Reflections which contains logic to access all the entities of Test Class. */
public class Reflections {

  /** Gets the logger.
   *
   * @param className
   *          the class name
   * @return the logger */
  public static Logger getLogger(Class<?> className) {
    return LoggerFactory.getLogger(className);
  }

  /** The main method.
   *
   * @param args
   *          the arguments */
  public static void main(String[] args) {

    Logger log = getLogger(Reflections.class);

    // Creating object whose property is to be checked
    Employee obj = new Employee();

    try {
      // Creating class object from the object using
      // getclass method
      Class<? extends Employee> cls = obj.getClass();
      log.info("The name of class is {} ", cls);
      // Getting the constructor of the class through the
      // object of the class
      Constructor<? extends Employee> constructor = cls.getDeclaredConstructor();
      log.info("The name of constructor is {}", constructor.getName());

      log.info("The public methods of class are : ");

      // Getting methods of the class through the object
      // of the class by using getMethods.Here nonly non private methods are called.
      Method[] methods = cls.getMethods();

      // Printing method names
      for (Method method : methods)
        log.info(method.getName());

      // creates object of desired method by providing the
      // method name and parameter class as arguments to
      // the getDeclaredMethod. Here we are accessing the private method
      Method setNameMethod = cls.getDeclaredMethod("setName", String.class);

      setNameMethod.setAccessible(true);
      // invokes the method at runtime
      setNameMethod.invoke(obj, "Antim");

      // creates object of the desired field by providing
      // the name of field as argument to the
      // getDeclaredField method
      Field field = cls.getDeclaredField("employeeId");
      field.setAccessible(true);
      Field field1 = cls.getDeclaredField("company");
      field1.setAccessible(true);

      log.info("{}", field.get(obj));
      log.info("{}", field1.get(obj));

      // takes object and the new value to be assigned
      // to the field as arguments
      // Calling a null method through DeclaredField
      Method printDetails = cls.getDeclaredMethod("printDetails");

      // invokes the method at runtime
      printDetails.invoke(obj);
    } catch (NoSuchMethodException e) {
      log.info("Please check the name of methods first. No method found");
    } catch (SecurityException e) {
      log.info("Due to Secuity,access permissions denied.");
    } catch (IllegalAccessException e) {
      log.info("you do not have access right to modify or change data");
    } catch (IllegalArgumentException e) {
      log.info("Incorrect argument Entered");
    } catch (InvocationTargetException e) {
      log.info("Illegal target invoked");
    } catch (NoSuchFieldException e) {
      log.info("No such field as specified found");
    }

  }

}
