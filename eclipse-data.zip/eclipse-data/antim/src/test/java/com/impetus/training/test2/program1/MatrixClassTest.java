package com.impetus.training.test2.program1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * The Class MatrixClassTest implements test cases for Matrix Class.
 */
public class MatrixClassTest {
  /**
   * Tests the valid square method
   *returns true if correct dimensions are entered otherwise false.
   */
  @Test
  public void testValidSquare() {
    final int row = 1;
    final int column = 1;
   char [][] strArray =new char[row][column];
   assertEquals(false,MatrixClass.validSquare(strArray,row,column));
  }

  /**
   * Tests findcharacter method.
   * Checks whether the given characeter is present in the search string provided.
   */
  @Test
  public void testFindCharacter() {
   
    assertEquals(true, MatrixClass.findCharacter('a', "bcade")); // returns true when character match is found
    assertEquals(false,MatrixClass.findCharacter('x', "abcde")); // return false if character is not present in search string
  } 

  /**
   * Tests print successful result.
   * This method prints the results once a 2x2 square is found.
   */
  @Test
  public void testPrintSuccessfulResult() {
   MatrixClass.printSuccessfulResult(1, 1);
  }

  /**
   * Tests find in matrix method which checks whether the given string of characters.
   * forms a magic square in the stored matrix or not.
   */
  @Test
  public void testFindInMatrix() {
    char [][] strArray = {{'a','b','c'},{'e','f','g'}};
    final int row = 2;
    final int column = 3;
   // String search1 = "ab";
    String search2 = "abef";
   // assertEquals(false, MatrixClass.findInMatrix(strArray, search1,row,column)); //return true when a magic square is found in char array
    assertEquals(true, MatrixClass.findInMatrix(strArray, search2, row, column)); //return false when not found
  }
  
  /**
   * Test to check store array input method. Stores values in array and returns true.
   * if alphabets are used else returns false
   */
  @Test
  public void testcheckStoreArrayInput() {
    char [][] strArray =new char[2][2];
    assertEquals(true, MatrixClass.checkStoreArrayInput(strArray,2, 2)); //return true when a magic square is found in char array 
  }
 
}
