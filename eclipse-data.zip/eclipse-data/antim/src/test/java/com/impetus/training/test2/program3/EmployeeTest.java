package com.impetus.training.test2.program3;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * The Class EmployeeTest tests methods of Employee class.
 */
public class EmployeeTest {

  /** The emp obj. */
  private Employee empObj = new Employee();
  
  /**
   * Test get employee id.
   */
  @Test
  public void testGetEmployeeId() {
    assertEquals("IIIPL-3930",empObj.getEmployeeId());
  }

  /**
   * Test set employee id.
   */
  @Test
  public void testSetEmployeeId() {
    empObj.setEmployeeId("1234");
  }

  /**
   * Test get company.
   */
  @Test
  public void testGetCompany() {
  assertEquals("Impetus", empObj.getCompany());  
  }

  /**
   * Test set company.
   */
  @Test
  public void testSetCompany() {
    empObj.setCompany("Intel");
  }

  /**
   * Test get name.
   */
  @Test
  public void testGetName() {
   assertEquals(null, empObj.getName());
  }


  /**
   * Test print details.
   */
  @Test
  public void testPrintDetails() {
    empObj.printDetails();
  }

  /**
   * Test print name.
   */
  @Test
  public void testPrintName() {
    empObj.printName("Hello");
  }

}
