package com.impetus.training.test3.program2;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * The Class DistinctWordListTest : Test class for the DistinctWordList class. Contains all the test methods.
 */
public class DistinctWordListTest {

    /**
     * Test print distinct words.
     */
    @Test
    public void testPrintDistinctWords() {
        String filePath = "/home/impadmin/eclipse-workspace/antim/src/main/java/com/impetus/training/test3/program2/testFile.txt";
       //assertEquals(false, DistinctWordList.printDistinctWords(filePath)); //test for wrong input
       assertEquals(true, DistinctWordList.printDistinctWords(filePath));
    }

    /**
     * Test main.
     */
    @Test
    public void testMain() {
        // fail("Not yet implemented");
    }

}
