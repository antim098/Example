package com.impetus.training.test3.program3;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/** ListOfNumbersTest : Tests the working of all the methods of the ListOfNumbers Class. */
public class ListOfNumbersTest {

    /** Tests the readList method by providing the filename and checking the boolean output.*/
    @Test
    public void testReadList() {
        String inputFileName = "/InputFile.txt";  //we have used the correct name of the file which exists and so it should return true.
        assertEquals(true, ListOfNumbers.readList(inputFileName));
    }

    /**  Tests the writeList method by providing the filename and checking the boolean output. */
    @Test
    public void testWriteList() {
        String outputFileName = "/Output.txt";// we have used wrong name
        assertEquals(false, ListOfNumbers.writeList(outputFileName)); // this gives false as file does not exists
    }

    /** Test main. */
    @Test
    public void testMain() {

    }

}
