package com.antim.portalapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.antim.portalapp.dao.ApplicationsDao;
import com.antim.portalapp.dao.BankPolicyDao;
import com.antim.portalapp.model.BankPolicy;

@Service
public class BankPolicyService {

    @Autowired
    private BankPolicyDao bankPolicyDao;

    public List<BankPolicy> getPolicy(String bankName) {
        return bankPolicyDao.getPolicy(bankName);
    }

}
