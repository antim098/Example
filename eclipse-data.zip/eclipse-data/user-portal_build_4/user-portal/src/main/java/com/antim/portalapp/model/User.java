package com.antim.portalapp.model;

import javax.persistence.*;

@Entity
@Table(name = "client")
public class User {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column
    private String password;
    @Column
    private long turnover;
    @Column
    private int foundedin;
    @Column
    private int employeeStrength;
    @Column
    private String domain;
    @Column
    private String name;
    @Column
    private String email;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getTurnover() {
        return turnover;
    }

    public void setTurnover(long turnover) {
        this.turnover = turnover;
    }

    public int getfoundedin() {
        return foundedin;
    }

    public void setfoundedin(int foundedin) {
        this.foundedin = foundedin;
    }

    public int getEmpStrength() {
        return employeeStrength;
    }

    public void setEmpStrength(int empStrength) {
        this.employeeStrength = employeeStrength;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public User(int id, String password, String name, String email, long turnover, int foundedin, int empStrength, String domain) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.email = email;
        this.turnover = turnover;
        this.foundedin = foundedin;
        this.employeeStrength = employeeStrength;
        this.domain = domain;
    }

    public User() {
    }

}