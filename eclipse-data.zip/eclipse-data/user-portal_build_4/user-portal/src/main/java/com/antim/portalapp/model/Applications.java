package com.antim.portalapp.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "applications")
public class Applications {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int app_no;
    @Column
    private String bank;
    @Column
    private int amount;
    @Column
    private int time;
    @Column
    private int client_id;
    @Column
    private String status;
    @Column
    private int reviewed_by;
    @Column
    private Date date;

    Applications() {
    }

    public Applications(int app_no, String bank, int amount, int time, int client_id, String status, int reviewed_by, Date date) {
        this.app_no = app_no;
        this.bank = bank;
        this.amount = amount;
        this.time = time;
        this.client_id = client_id;
        this.status = status;
        this.reviewed_by = reviewed_by;
        this.date = date;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getClient_id() {
        return client_id;
    }

    public void setClient_id(int client_id) {
        this.client_id = client_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getReviewed_by() {
        return reviewed_by;
    }

    public void setReviewed_by(int reviewed_by) {
        this.reviewed_by = reviewed_by;
    }

    public int getApp_No() {
        return app_no;
    }

    public void setApp_No(int app_no) {
        this.app_no = app_no;
    }

    public String getbank() {
        return bank;
    }

    public void setbank(String bank) {
        this.bank = bank;
    }

}
