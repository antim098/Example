package com.antim.portalapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.antim.portalapp.model.Applications;
import com.antim.portalapp.model.BankPolicy;
import com.antim.portalapp.service.ApplicationsService;
import com.antim.portalapp.service.ApplicationsServicesImpl;
import com.antim.portalapp.service.BankPolicyService;
import com.antim.portalapp.service.UserServiceImpl;

@Component
@Controller
@RestController
public class PolicyController {

    @Autowired
    private BankPolicyService bankpolicyService;
    @Autowired
    private ApplicationsServicesImpl appService;
    @Autowired
    private UserServiceImpl userService;

    String bank;
    int turnoverPercent;
    int noOfApprovals;
    int noOfTransctions;

    // temp variables to test functions.
    int id = 1;
    long turnover = 600000000;
    long amount = 90000000;

    @GetMapping(path = "/apply/{id}")
    boolean setPolicyValues() {
        List<BankPolicy> bankVariables = bankpolicyService.getPolicy(bank);
        // turnoverPercent = bankVariables[0];
        // no_of_transctions = bankVariables[1];
        // no_of_approvals = (int) bankVariables[2];

        // turnover,no_of_approvals,no_of_transactions
        turnoverPercent = bankVariables.get(0).getTurnover();
        noOfTransctions = bankVariables.get(0).getNo_of_transctions();
        noOfApprovals = bankVariables.get(0).getNo_of_approvals();

        if (callAutomatedPolicies()) {
            // saveApplication();
            return true;
        } else
            return false;
    }

    boolean callAutomatedPolicies() {
        boolean result1 = userService.Policy1(id, turnoverPercent, turnover, amount);

        boolean result2 = appService.Policy2(id, noOfTransctions, noOfApprovals);

        boolean result3 = true;

        if (result1 == result2 == true) {
            return true;
        } else if (result1 == result3 == true || result2 == result3 == true) {
            return true;
        } else
            return false;
    }

}
