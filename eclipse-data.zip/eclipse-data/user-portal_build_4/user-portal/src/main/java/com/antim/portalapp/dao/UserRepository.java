package com.antim.portalapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.antim.portalapp.model.*;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    void delete(User user);

    List<User> findAll();

    User findOne(int id);

    User save(User user);

    
    @Query("SELECT turnover FROM User U WHERE U.id = :id")
    long getTurnover(@Param("id") int id);

}
