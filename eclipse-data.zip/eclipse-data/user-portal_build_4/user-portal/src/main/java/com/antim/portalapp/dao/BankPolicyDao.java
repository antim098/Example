package com.antim.portalapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.antim.portalapp.model.BankPolicy;
import com.antim.portalapp.model.User;
import java.lang.String;
import java.util.List;

@Repository
public interface BankPolicyDao extends JpaRepository<BankPolicy,Integer>{

   // List<BankPolicy> findByBankname(String bankname);
    
   
    
 //  BankPolicy f;
    
    @Query("SELECT turnover,noOfTransactions,noOfApprovals from BankPolicy b where b.bankname = ?1")
    List<BankPolicy> getPolicy(String bank);
}
