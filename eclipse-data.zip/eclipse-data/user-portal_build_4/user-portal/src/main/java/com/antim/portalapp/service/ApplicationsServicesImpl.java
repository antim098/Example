package com.antim.portalapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplicationsServicesImpl {

    @Autowired
    private ApplicationsService appService;

    public boolean Policy2(int noOfApprovals, int noOfTransctions, int id) {
        if (appService.getClientHistory(id, noOfTransctions) >= noOfApprovals)
            return true;
        else
            return false;
    }

}
