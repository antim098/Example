package com.antim.portalapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.antim.portalapp.dao.ApplicationsDao;

@Service
public class ApplicationsService {

    @Autowired
    private ApplicationsDao applicationsDao;

    public int getClientHistory(int id, int noOfTransactions) {

        return applicationsDao.getClientHistory(id, noOfTransactions);

    }

}
