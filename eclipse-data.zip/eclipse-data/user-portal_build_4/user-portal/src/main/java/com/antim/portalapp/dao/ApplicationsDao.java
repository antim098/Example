package com.antim.portalapp.dao;

import com.antim.portalapp.model.*;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationsDao extends JpaRepository<Applications, Integer> {

    void delete(Applications application);

    List<Applications> findAll();

    Applications findOne(int id);

    Applications save(Applications app);

    // @Query("SELECT COUNT(STATUS) FROM applications a WHERE a.STATUS = = 'APPROVED' ORDER BY a.DATE DESC LIMIT ?2\", nativeQuery = true")

    @Query("select count(Status) from Applications e where e.id = ?1 and e.status='approved'")
    int getClientHistory(int id, int no_of_transctions);

}
