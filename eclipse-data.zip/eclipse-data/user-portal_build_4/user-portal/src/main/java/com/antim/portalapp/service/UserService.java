package com.antim.portalapp.service;

import java.util.List;

import com.antim.portalapp.model.*;

public interface UserService {

    User create(User user);

    User delete(int id);

    List<User> findAll();

    User findById(int id);

    User update(User user);

}
