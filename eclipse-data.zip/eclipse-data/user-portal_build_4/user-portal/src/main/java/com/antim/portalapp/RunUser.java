package com.antim.portalapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


//@EntityScan
//@EnableJpaRepositories(basePackages="com.antim.portalapp.dao")
@SpringBootApplication
//@ComponentScan(basePackages = {"com.antim.portalapp.controller","com.antim.portalapp.dao","com.antim.portalapp.service","com.antim.portalapp.model"})
public class RunUser {

    public static void main(String[] args) {
        SpringApplication.run(RunUser.class, args);
    }
}

