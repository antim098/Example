package com.antim.portalapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bankpolicy")
public class BankPolicy {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String bankname;
    @Column
    private int turnover;
    @Column
    private int noOfTransactions;
    @Column
    private int noOfApprovals;

    public String getbankname() {
        return bankname;
    }

    public void setbankname(String bankname) {
        this.bankname = bankname;
    }

    public int getTurnover() {
        return turnover;
    }

    public void setTurnover(int turnover) {
        this.turnover = turnover;
    }

    
    public BankPolicy(String bankname, int turnover, int noOfTransctions, int noOfApprovals) {
        this.bankname = bankname;
        this.turnover = turnover;
        this.noOfTransactions = noOfTransctions;
        this.noOfApprovals = noOfApprovals;
    }

    public int getNo_of_transctions() {
        return noOfTransactions;
    }

    public void setNo_of_transctions(int noOfTransctions) {
        this.noOfTransactions = noOfTransctions;
    }

    public int getNo_of_approvals() {
        return noOfApprovals;
    }

    public void setnoOfApprovals(int noOfApprovals) {
        this.noOfApprovals = noOfApprovals;
    }

}
