package com.antim.portalapp.service;

public class PolicyService {
    
    void Policy1(int amount,int turnover)
    {
     
    }

}
