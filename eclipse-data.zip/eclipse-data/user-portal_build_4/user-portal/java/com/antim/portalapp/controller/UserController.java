package com.antim.portalapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.antim.portalapp.model.*;
import com.antim.portalapp.service.*;

import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

@Controller
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
// @RequestMapping({"/api"})
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public User create(@RequestBody User user) {
        return userService.create(user);
    }
    //
    // @GetMapping(path = { "/{id}" })
    // public boolean findOne(@PathVariable("id") int id) {
    // if (userService.findById(id) != null) {
    // return
    // } else
    // return false;
    // }

    @GetMapping(path = "/login/{id}")
    public void findUser(@PathVariable("id") int id) throws SQLException, ClassNotFoundException {
      //  return userService.findById(id);
    	 Connection conn = null;
    	   Statement stmt = null;
    	      //STEP 2: Register JDBC driver
    	      Class.forName("com.mysql.jdbc.Driver");

    	      //STEP 3: Open a connection
    	      System.out.println("Connecting to database...");
    	      conn = DriverManager.getConnection("testdb","root","root");
    	      //STEP 4: Execute a query
    	      System.out.println("Creating statement...");
    	      stmt = conn.createStatement();
    	      String sql;
    	      sql = "SELECT name from user where id='id'";
    	      ResultSet rs = stmt.executeQuery(sql);
    	      System.out.println(rs.getString(0));
    
    }

    @PutMapping
    public User update(@RequestBody User user) {
        return userService.update(user);
    }

    // @DeleteMapping(path = { "/{id}" })
    // public User delete(@PathVariable("id") int id) {
    // return userService.delete(id);
    // }

    @GetMapping
    public List findAll() {
        return userService.findAll();
    }
}
