package com.antim.portalapp.dao;


public class CreditApplicationsDao {
	
	
	
	

   
}
