package matrix;

import java.util.InputMismatchException;
import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** The Class MatrixClasss which implements logic for finding 2x2 Matrix. */
public class MatrixClass {

  // Integer Constants
  private static int letterCount = 0;
  private static int startColumn = 0;
  private static int endColumn = 2;
  private static final int CHARSTART = 65;
  private static final int CHAREND = 122;
  private static final int COUNT = 4;

  // String Constants

  private static String askForDimensions = "Enter number of rows and columns";
  private static String inputMismatch = "Please enter integer values only";
  private static String negativeValue = "Please enter positive values only";
  private static String askSearchChar = "Enter the characters to be searched";
  private static String notFound = "No Magic Square Found";

  /** Logger object.Here we are using slf4j. */
  private static Logger log = LoggerFactory.getLogger(MatrixClass.class);

  /** Method to Get the scanner.
   *
   * @return the scanner object. */
  static Scanner getScanner() {
    return new Scanner(System.in);

  }

  /** validSquare Method Check whether valid input values are given for the creation of array. If
   * Invalid input is given it throws Input Mismatch Exception which is handled.
   *
   * @param strArray
   *          The 2D String array which contains the user given Matrix
   * @param rows
   *          the rows
   * @param columns
   *          the columns
   * @return boolean value according to the input */
  static boolean validSquare(char[][] strArray, int rows, int columns) {
    boolean methodStatus = true;
    if (rows >= 2) {
      if (columns >= 2) {
        methodStatus=checkStoreArrayInput(strArray, rows, columns);
      } else {
        log.info("No of columns less than 2");
        methodStatus = false;
        return methodStatus;
      }
    }   else {
        log.info("No of rows less than 2");
        methodStatus = false;
        return methodStatus;
    }
    return methodStatus;
  }

  /** this method searches for the character currently pointed in the String array. against the
   * search string given by the user
   * 
   * @param charToSearch
   *          the char to search in the search String
   * @param searchString
   *          the search string
   * @return true, if successful */
  static boolean findCharacter(char charToSearch, String searchString) {
    boolean result = false;
    int index = 0;
    while (index < searchString.length()) {
      if (charToSearch == (searchString.charAt(index))) {
        result = true;
        break;
      }
      index++;
    }

    return result;

  }

  /**
   * Check store array input.
   *
   * @param strArray the empty str array
   * @param rows the number of rows
   * @param columns the number of columns
   * @return true, if successful else false
   */
    static boolean checkStoreArrayInput(char[][] strArray, int rows, int columns) {
    Scanner input = getScanner();
    boolean methodStatus = true;
    for (int rowIndex = 0; rowIndex < rows; rowIndex++) {
      log.info("Enter elements for row {}", rowIndex);
      for (int columnIndex = 0; columnIndex < columns; columnIndex++) {
        char c = input.next().charAt(0);
        if (c >= CHARSTART && c <= CHAREND) {
          strArray[rowIndex][columnIndex] = c;
        } else {
          log.info("Only small and capital alphabets are allowed, nothing else");
          methodStatus =false;
          return methodStatus;
        }
      }
    }
    return methodStatus;
  }

  /** This method Prints the messages through logger if Square matix is found.
   * 
   * @param rowIndex
   *          the row number of the matrix
   * @param columnIndex
   *          the column number of the matrix */
    static void printSuccessfulResult(int rowIndex, int columnIndex) {
    log.info("Found Magic Square");
    log.info("Position of starting Node is :");
    log.info("Row-Column {}-{}", rowIndex - 1, columnIndex - 1);
  }

  /** Find in matrix. This method contains the logic for finding the 2x2 Magic Square. This methods
   * implements looping mechanism to loop through the columns and rows and to find out the position
   * of the magic square formed by the input string given by the user.
   *
   * @param strArray
   *          Contains String array matrix
   * @param search
   *          search string which contains string to be searched in the matrix
   * @param rows
   *          the number of rows
   * @param columns
   *          the number of columns
   * @return boolean return false if no square found else prints the square */
  static boolean findInMatrix(char[][] strArray, String search, int rows, int columns) {
    while (endColumn < columns + 1) {
      letterCount = 0;
      for (int rowIndex = 0; rowIndex < rows; rowIndex++) {
        int columnIndex = startColumn;
        while (columnIndex < endColumn) {
          if (findCharacter(strArray[rowIndex][columnIndex], search)) {
            letterCount++;
            if (letterCount == COUNT) {
              printSuccessfulResult(rowIndex, columnIndex);
              return true;
            }
            columnIndex++;
          } else {
            break;
          }
        }
      }
      startColumn++;
      endColumn++;
    }
    return false;
  }

  /** The main method. Main method of the Class MatrixClass
   * 
   * @param args
   *          the arguments */
  public static void main(String[] args) {
    Scanner input = getScanner();
    int rows = 0;
    int columns = 0;
    char[][] strArray = null;
    log.info(askForDimensions);
    try {
      rows = input.nextInt();
      columns = input.nextInt();
      strArray = new char[rows][columns];
    } catch (InputMismatchException e) {
      log.info(inputMismatch);
      System.exit(0);
    } catch (NegativeArraySizeException e) {
      log.info(negativeValue);
      System.exit(0);
    }
    if (validSquare(strArray, rows, columns)) {
      // Printing the Entered char Matrix
      for (int rowIndex = 0; rowIndex < rows; rowIndex++) {
        for (int colIndex = 0; colIndex < columns; colIndex++) {
          log.info("{} ", strArray[rowIndex][colIndex]);
        }
      }
      log.info(askSearchChar);
      String search = input.next();
      if (!findInMatrix(strArray, search, rows, columns)) {
        log.info(notFound);
      }
    }
  }
}
