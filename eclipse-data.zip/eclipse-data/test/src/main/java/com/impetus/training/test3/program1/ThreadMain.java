package com.impetus.training.test3.program1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
class ThreadIncrement implements Runnable {

  
  static Logger log = LoggerFactory.getLogger(ThreadMain.class);
  static int number;
  
  public void run() {
    
  }
  
  Thread t1 = new Thread() {
    
    public void run() {
      number+=1000000;
      
    }
  };
  
  Thread t2 = new Thread() {
    
    public void run() {
    log.info("Value of number {}",number);           
    }
    
};
  
  
}

public class ThreadMain {

 public static void main(String[] args) throws InterruptedException {
   
 ThreadIncrement t = new ThreadIncrement();  
   
 t.t1.start();
 t.t1.join();
t.t2.start();
 
 
}
  
  
  
}



