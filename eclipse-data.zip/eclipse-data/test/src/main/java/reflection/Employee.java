package reflection;

import org.slf4j.Logger;

/** The Class Reflections which shows how the various fields and methods
 * are accessed through Reflection. */
public class Employee {

  /** The log. */
  private Logger log = Reflections.getLogger(Employee.class);

  /** The employee id. */
  // creating a private field Employee Id
  private String employeeId;

  /** The name. */
  private String name;

  
  /**
   * Sets the name of the employee
   *
   * @param name the new name
   */
  private void setName(String name) {
    this.name = name;
  }

  /** The company. */
  private String company = "Impetus";

 
  /**
   * this  gives or returns the employee id.
   *
   * @return the employee id
   */
  public String getEmployeeId() {
    return employeeId;
  }

  /** Sets the employee id.
   *
   * @param employeeId
   *          the user given employee id */
  public void setEmployeeId(String employeeId) {
    this.employeeId = employeeId;
  }

  /**
   * this  gives or returns the Company field value.
   *
   * @return the company name
   */ 
  public String getCompany() {
    return company;
  }

  /** Sets the company field of the Employee class.
   *
   * @param company
   *          the user given company name */
  public void setCompany(String company) {
    this.company = company;
  }

  /** Returns the employee name.
   *
   * @return the name */
  public String getName() {
    return name;
  }
  
  /** Constructor of Employee class. */
  // creating a public constructor
  Employee() {
    employeeId = "IIIPL-3930";
  }


  /** Method that prints the user details stored in Test class. */
  // Creating a public method with no arguments
  public void printDetails() {
    log.info(name);
    log.info("The Id is {}",employeeId);
    log.info("The names is {}",name);
  }

  /** printName Method.
   *
   * @param n  the name of employee
   *          */
  // Creating a public method with argument
  public void printName(String n) {
    log.info("The name is {}",n);
  }

}
