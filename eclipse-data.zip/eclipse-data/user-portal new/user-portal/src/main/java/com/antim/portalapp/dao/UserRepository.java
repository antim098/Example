package com.antim.portalapp.dao;
import org.springframework.data.repository.Repository;

import com.antim.portalapp.model.*;

import java.util.List;

public interface UserRepository extends Repository<User, Integer> {

    void delete(User user);

    List<User> findAll();

    User findOne(int id);

    User save(User user);
}
