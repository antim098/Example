package com.antim.portalapp.model;

public class Analyst {

}
