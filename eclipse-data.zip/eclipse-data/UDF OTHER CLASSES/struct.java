package Hive.UDF;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentTypeException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ConstantObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.Text;

public class struct extends GenericUDF {

    private transient Object[] ret;
    private ObjectInspectorConverters.Converter[] converters;

    @Override
    public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {

        int numFields = arguments.length;
        if (numFields % 2 == 1) {
            throw new UDFArgumentLengthException("NAMED_STRUCT expects an even number of arguments.");
        }
        ret = new Object[3];

        converters = new ObjectInspectorConverters.Converter[arguments.length];
        for (int i = 0; i < arguments.length; i++) {
            converters[i] = ObjectInspectorConverters.getConverter(arguments[i], PrimitiveObjectInspectorFactory.writableStringObjectInspector);
        }
        
        ArrayList<String> fname = new ArrayList<String>();
        ArrayList<ObjectInspector> retOIs = new ArrayList<ObjectInspector>();
        for (int f = 0; f < numFields; f++) {

            //ConstantObjectInspector constantOI = (ConstantObjectInspector) arguments[f];
            fname.add(arguments[f].toString());
            retOIs.add(arguments[f]);
        }
        StructObjectInspector soi = ObjectInspectorFactory.getStandardStructObjectInspector(fname, retOIs);
        return soi;
    }

    @Override
    public Object evaluate(DeferredObject[] arguments) throws HiveException {
//        for (int i = 0; i < arguments.length / 2; i++) {
//            ret[i] = arguments[2 * i + 1].get();
//        }
//        return ret;
        if (arguments[0].get() == null) {
            return null;
        }

        ArrayList<Text> result = new ArrayList<Text>();
        

      //  Text s = (Text) converters[0].convert(arguments[0].get());
      //  Text regex = (Text) converters[1].convert(arguments[1].get());

        String[] dataParts = converters[0].convert(arguments[0].get()).toString().split("~");
        Map<Integer, String[]> identifiers = new HashMap<Integer, String[]>();
        identifiers.put(0, new String[] { "STAPRM", "STADIS" });
        identifiers.put(1, new String[] { "ETAPRM", "ETADIS" });

        // columnValues = new org.apache.hadoop.io.Text[identifiers.size()];
        for (int j = 0; j < identifiers.size(); j++) {
            String[] find = identifiers.get(j);
            // columnValues[j].set("0.0");

            for (int i = 0; i < dataParts.length; i++) {
                System.out.print("Values to find" + Arrays.asList(find));
                System.out.print("Datapart to check" + dataParts[i]);
                if (Arrays.stream(find).parallel().anyMatch(dataParts[i]::contains)) {
                    System.out.println("Inside if");
                    result.add(new Text(dataParts[i].split("_")[3]));
                    // System.out.println(dataParts[i].split("_")[3]);
                    break;
                } else {
                    if(i==dataParts.length-1)
                    System.out.println("Inside else");
                    result.add(new Text("0.0"));
                }
            }
            
        }

        return result;
        
        
        
        
        
    }

    @Override
    public String getDisplayString(String[] children) {
        return getStandardDisplayString("named_struct", children, ",");
    }

}
