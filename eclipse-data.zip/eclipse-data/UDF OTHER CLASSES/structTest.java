package Hive.UDF;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentTypeException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde.serdeConstants;
import org.apache.hadoop.hive.serde2.objectinspector.ConstantObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector.Category;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.io.Text;

public class structTest extends GenericUDF {

    private transient Object[] ret;
    private ObjectInspectorConverters.Converter[] converters;

    @Override
    public StructObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {

        System.out.println("Inside initialize, arguments are" + arguments.length);
        if (arguments.length != 1) {
            throw new UDFArgumentLengthException("The function SPLIT(s, regexp) takes exactly 2 arguments.");
        }

        for (int i = 0; i < arguments.length; i++) {
            converters[i] = ObjectInspectorConverters.getConverter(arguments[i], PrimitiveObjectInspectorFactory.writableStringObjectInspector);
        }

        ArrayList<ObjectInspector> retOIs = new ArrayList<ObjectInspector>(3);
        ArrayList<String> columnNames = new ArrayList<String>(3);
        columnNames.add("value1");
        columnNames.add("value2");
        columnNames.add("value3");

        for (int f = 0; f < 3; f++) {

            ConstantObjectInspector constantOI = (ConstantObjectInspector) arguments[f];
            retOIs.add(constantOI);

            // retOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);

        }

        return ObjectInspectorFactory.getStandardStructObjectInspector(columnNames, retOIs);
        // StructObjectInspector soi = ObjectInspectorFactory.getStandardStructObjectInspector(columnNames, retOIs);
        // return soi;

    }

    @Override
    public Object evaluate(DeferredObject[] arguments) throws HiveException {

        System.out.println("Inside evaluate");
        // for (int i = 0; i < arguments.length / 2; i++) {
        // ret[i] = arguments[2 * i + 1].get();
        // }
        // return ret;
        if (arguments[0].get() == null) {
            return null;
        }

        // Text s = (Text) converters[0].convert(arguments[0].get());
        // Text regex = (Text) converters[1].convert(arguments[1].get());
        ArrayList<Text> result = new ArrayList<Text>();
        String[] dataParts = converters[0].convert(arguments[0].get()).toString().split("~");
        Map<Integer, String[]> identifiers = new HashMap<Integer, String[]>();
        identifiers.put(0, new String[] { "STAPRM", "STADIS" });
        identifiers.put(1, new String[] { "ETAPRM", "ETADIS" });

        // columnValues = new org.apache.hadoop.io.Text[identifiers.size()];
        for (int j = 0; j < identifiers.size(); j++) {
            String[] find = identifiers.get(j);
            // columnValues[j].set("0.0");

            for (int i = 0; i < dataParts.length; i++) {
                System.out.print("Values to find" + Arrays.asList(find));
                System.out.print("Datapart to check" + dataParts[i]);
                if (Arrays.stream(find).parallel().anyMatch(dataParts[i]::contains)) {
                    System.out.println("Inside if");
                    result.add(new Text(dataParts[i].split("_")[3]));
                    // System.out.println(dataParts[i].split("_")[3]);
                    break;
                } else {
                    if (i == dataParts.length - 1)
                        System.out.println("Inside else");
                    result.add(new Text("0.0"));
                }
            }

        }

        System.out.println("evaluated");

        return result;

    }

    @Override
    public String getDisplayString(String[] children) {
        return getStandardDisplayString("named_struct", children, ",");
    }
}
