package Hive.UDF;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;

public class javaudf {

    private PrimitiveObjectInspector stringOI = null;

    /** The datarow. */
    private static Object[] datarow;
    private static int columnCount = 0;

    /** The identifiers. */
    static Map<Integer, String[]> identifiers = new HashMap<>();

    public static void process(String tid, String cid, String data) throws HiveException {

        ArrayList<Object[]> results = (ArrayList<Object[]>) processInputRecord(data, tid, cid);

        Iterator<Object[]> it = results.iterator();
        while (it.hasNext()) {
            Object[] r = it.next();
            for (int i = 0; i < r.length; i++) {
                System.out.println(r[i]);
            }
        }
    }

    /** Process input record.
     *
     * @param inputData
     *            the string in which identifiers are to be searched and values to be extracted.
     * @return the list of object[] containing all the values the columns for a particular row. */
    public static List<Object[]> processInputRecord(String inputData, String tid, String cid) {
        ArrayList<Object[]> result = new ArrayList<>();
        String[] dataParts = inputData.split("~");
        String[] checkNull = { "NULL", "NULL" };
        datarow[0] = tid;
        datarow[1] = cid;
        for (int j = 2; j < columnCount; j++) {
            datarow[j] = 0.0; // initializing value of the column
            if (!Arrays.equals(identifiers.get(j), checkNull)) {
                String[] find = identifiers.get(j);

                for (int i = 0; i < dataParts.length; i++)
                    if (getValues(find, dataParts[i], i, j)) {
                        break;
                    }
            }
        }

        result.add(datarow);
        return result;
    }

    /** Gets the values.
     *
     * @param find
     *            the identifier array to be searched in the Data Part
     * @param dataPart
     *            the String Data Part to be searched
     * @param i
     *            the dataPart index
     * @param j
     *            the Identifier index
     * @return the values */
    public static boolean getValues(String[] find, String dataPart, int i, int j) {

        if (Arrays.stream(find).parallel().anyMatch(dataPart::contains)) {
            String type = dataPart.split("_")[0]; // Either Premium,Discount,Rouding or PriceCap.
            try {
                String reqValue = dataPart.split("_")[3];

                if (("Premium").equalsIgnoreCase(type)) {
                    datarow[j] = Double.parseDouble(reqValue);
                } else if (("Discount").equalsIgnoreCase(type)) {
                    datarow[j] = Double.parseDouble("-" + reqValue);
                } else {
                    datarow[j] = evalDifference(dataPart.split("_")[2], dataPart.split("_")[1]);
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("The Specified index " + e.getLocalizedMessage() + " is not present in the input data :" + dataPart);
            }
            return true;
        }
        return false;
    }

    /** EvalDifference.
     *
     * @param b
     *            the element at the 2nd index of the Data
     * @param a
     *            the a the element at the 1st index of Data
     * @return the double the difference between a and b */
    public static Double evalDifference(String b, String a) {
        String format = "##.##";
        if ("NA".equals(a) && "NA".equals(b)) {
            return 0.0;
        } else {
            if ("NA".equals(b)) {
                return Double.parseDouble(new DecimalFormat(format).format(Double.parseDouble("-" + a)));
            } else if ("NA".equals(a)) {
                return Double.parseDouble(new DecimalFormat(format).format(Double.parseDouble(b)));
            } else {
                return Double.parseDouble(new DecimalFormat(format).format(Double.parseDouble(b) - Double.parseDouble(a)));
            }

        }

    }

    public static void main(String[] agrs) throws HiveException {
        identifiers.put(2, new String[] { "STAPRM", "STADIS" });
        identifiers.put(3, new String[] { "ETAPRM", "ETADIS" });
        identifiers.put(4, new String[] { "DFDRM", "DFDDIS" });
        identifiers.put(5, new String[] { "SCAPRM", "SCADIS" });
        identifiers.put(6, new String[] { "FDTPRM", "FDTDIS" });
        identifiers.put(7, new String[] { "FDT1PRM", "FDT1DIS" });
        identifiers.put(8, new String[] { "TDTPRM", "TDTDIS" });
        identifiers.put(9, new String[] { "TDT1PRM", "TDT1DIS" });
        identifiers.put(10, new String[] { "LFAPRM", "LFADIS" });
        identifiers.put(11, new String[] { "LFA1PRM", "LFA1DIS" });
        identifiers.put(12, new String[] { "BCAPRM", "BCADIS" });
        identifiers.put(13, new String[] { "PSAPRM", "PSADIS" });
        identifiers.put(14, new String[] { "PriceCap" });
        identifiers.put(15, new String[] { "PNRPRM", "PNRDIS" });
        identifiers.put(16, new String[] { "BEPNRPRM", "BEPNRDIS" });
        identifiers.put(17, new String[] { "BECPRM", "BECDIS" });
        identifiers.put(18, new String[] { "NULL", "NULL" });
        identifiers.put(19, new String[] { "Rounding" });
        identifiers.put(20, new String[] { "NULL", "NULL" });
        identifiers.put(21, new String[] { "NULL", "NULL" });
        identifiers.put(22, new String[] { "NULL", "NULL" });
        identifiers.put(23, new String[] { "NULL", "NULL" });
        identifiers.put(24, new String[] { "NULL", "NULL" });
        columnCount = identifiers.size() + 2;
        datarow = new Object[columnCount];

        process("FFD8247B40904C718FAB2DE42AA897FB", "1456948457102010232221116762011",
                "Premium_32.00_37.44_17.0_5.44_32.00_STAPRM~Premium_37.44_48.00_33.0_10.56_32.00_ETAPRM~Premium_48.00_52.80_15.0_4.80_32.00_SCAPRM~Discount_52.80_51.80_3.0_-1.00_32.00_FDTDIS~Rounding_51.80_52.00_NA_NA_NA_NA");

    }

}
