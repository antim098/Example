package Hive.UDF;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.hive.ql.exec.UDF;

public class App extends GenericUDF {

    private Object[] result;

    @Override
    public String getDisplayString(String[] arg0) {
        return "";
    }

    @Override
    public ObjectInspector initialize(ObjectInspector[] arg0) throws UDFArgumentException {

        ArrayList<String> structFieldNames = new ArrayList<>();
        ArrayList<ObjectInspector> structFieldObjectInspectors = new ArrayList<>();

        for (int i = 1; i <= 23; i++) {
            structFieldNames.add("value" + i);
            structFieldObjectInspectors.add(PrimitiveObjectInspectorFactory.writableStringObjectInspector);

        }
        return ObjectInspectorFactory.getStandardStructObjectInspector(structFieldNames, structFieldObjectInspectors);
    }

    @Override
    public Object evaluate(DeferredObject[] args) {
        Object argObj = null;
        try {
            if (args == null || args.length < 1) {
                throw new HiveException();
            }
            if (args[0].get() == null) {
                throw new HiveException();
            } else {
            }
        } catch (HiveException e) {
            System.out.println("No Arguments are given to the Function or any argument is null");
        }

        String[] dataParts = argObj.toString().split("~");
        Map<Integer, String[]> identifiers = new HashMap<>();
        identifiers.put(0, new String[] { "STAPRM", "STADIS" });
        identifiers.put(1, new String[] { "ETAPRM", "ETADIS" });
        identifiers.put(2, new String[] { "DFDRM", "DFDDIS" });
        identifiers.put(3, new String[] { "SCAPRM", "SCADIS" });
        identifiers.put(4, new String[] { "FDTPRM", "FDTIS" });
        identifiers.put(5, new String[] { "FDT1PRM", "TDT1DIS" });
        identifiers.put(6, new String[] { "TDTPRM", "TDTDIS" });
        identifiers.put(7, new String[] { "TDT1PRM", "FDT1DIS" });
        identifiers.put(8, new String[] { "LFAPRM", "LFADIS" });
        identifiers.put(9, new String[] { "LFA1PRM", "LFA1DIS" });
        identifiers.put(10, new String[] { "BCAPRM", "BCADIS" });
        identifiers.put(11, new String[] { "PSAPRM", "PSADIS" });
        identifiers.put(12, new String[] { "PriceCap_77.80_79.00_NA_NA_NA_NA", "NULL" });
        identifiers.put(13, new String[] { "PNRPRM", "PNRDIS" });
        identifiers.put(14, new String[] { "BEPNRPRM", "BEPNRDIS" });
        identifiers.put(15, new String[] { "BECPRM", "BECDIS" });
        identifiers.put(16, new String[] { "NULL", "NULL" });
        identifiers.put(17, new String[] { "Rounding_43.86_44.00_NA_NA_NA_NA", "NULL" });
        identifiers.put(18, new String[] { "NULL", "NULL" });
        identifiers.put(19, new String[] { "NULL", "NULL" });
        identifiers.put(20, new String[] { "NULL", "NULL" });
        identifiers.put(21, new String[] { "NULL", "NULL" });
        identifiers.put(22, new String[] { "NULL", "NULL" });
        result = new Object[identifiers.size()];
        for (int j = 0; j < identifiers.size(); j++) {
            String[] find = identifiers.get(j);
            result[j] = new Text("0.0");

            for (int i = 0; i < dataParts.length; i++) {

                if (Arrays.stream(find).parallel().anyMatch(dataParts[i]::contains)) {
                    if (dataParts[i].split("_")[0].equalsIgnoreCase("Premium")) {
                        result[j] = new Text(dataParts[i].split("_")[3]);
                    }
                    if (dataParts[i].split("_")[0].equalsIgnoreCase("Discount")) {
                        result[j] = new Text("-" + (dataParts[i].split("_")[3]));
                    } else if (dataParts[i].split("_")[0].equalsIgnoreCase("Rounding")) {
                        result[j] = new Text(String.valueOf(new DecimalFormat("##.##")
                                .format(Double.parseDouble(dataParts[i].split("_")[2]) - Double.parseDouble(dataParts[i].split("_")[1]))));
                    }
                    break;
                }
            }

        }

        return result;
    }

}
