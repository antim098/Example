package Hive.UDF;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;

/** The Class FinalUdtf. */
public class FinalUdtf extends GenericUDTF {

    /** The string Input OI. */
    private PrimitiveObjectInspector stringOI = null;

    /** The datarow. */
    private Object[] datarow;

    /** The identifiers. */
    Map<Integer, String[]> identifiers = new HashMap<>();

    /*
     * (non-Javadoc)
     * @see org.apache.hadoop.hive.ql.udf.generic.GenericUDTF#initialize(org.apache. hadoop.hive.serde2.objectinspector.ObjectInspector[])
     */
    @Override
    public StructObjectInspector initialize(ObjectInspector[] args) {
        try {
            if (args.length != 1) {
                throw new UDFArgumentException();
            }
        } catch (UDFArgumentException e) {
            System.out.println("Zero arguments supplied to the function");
        }
        // Identifiers to be searched in the Input String
        identifiers.put(0, new String[] { "STAPRM", "STADIS" });
        identifiers.put(1, new String[] { "ETAPRM", "ETADIS" });
        identifiers.put(2, new String[] { "DFDRM", "DFDDIS" });
        identifiers.put(3, new String[] { "SCAPRM", "SCADIS" });
        identifiers.put(4, new String[] { "FDTPRM", "FDTIS" });
        identifiers.put(5, new String[] { "FDT1PRM", "TDT1DIS" });
        identifiers.put(6, new String[] { "TDTPRM", "TDTDIS" });
        identifiers.put(7, new String[] { "TDT1PRM", "FDT1DIS" });
        identifiers.put(8, new String[] { "LFAPRM", "LFADIS" });
        identifiers.put(9, new String[] { "LFA1PRM", "LFA1DIS" });
        identifiers.put(10, new String[] { "BCAPRM", "BCADIS" });
        identifiers.put(11, new String[] { "PSAPRM", "PSADIS" });
        identifiers.put(12, new String[] { "PriceCap" });
        identifiers.put(13, new String[] { "PNRPRM", "PNRDIS" });
        identifiers.put(14, new String[] { "BEPNRPRM", "BEPNRDIS" });
        identifiers.put(15, new String[] { "BECPRM", "BECDIS" });
        identifiers.put(16, new String[] { "NULL", "NULL" });
        identifiers.put(17, new String[] { "Rounding" });
        identifiers.put(18, new String[] { "NULL", "NULL" });
        identifiers.put(19, new String[] { "NULL", "NULL" });
        identifiers.put(20, new String[] { "NULL", "NULL" });
        identifiers.put(21, new String[] { "NULL", "NULL" });
        identifiers.put(22, new String[] { "NULL", "NULL" });
        datarow = new Object[identifiers.size()];
        ArrayList<String> structFieldNames = new ArrayList<>();
        ArrayList<ObjectInspector> structFieldValues = new ArrayList<>();

        stringOI = (PrimitiveObjectInspector) args[0];
        for (int i = 1; i <= identifiers.size(); i++) {
            structFieldNames.add("value" + i);
            structFieldValues.add(PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
        }
        return ObjectInspectorFactory.getStandardStructObjectInspector(structFieldNames, structFieldValues);
    }

    /*
     * (non-Javadoc)
     * @see org.apache.hadoop.hive.ql.udf.generic.GenericUDTF#process(java.lang.Object[])
     */
    @Override
    public void process(Object[] args) throws HiveException {

        final String data = stringOI.getPrimitiveJavaObject(args[0]).toString();
        ArrayList<Object[]> results = (ArrayList<Object[]>) processInputRecord(data);

        Iterator<Object[]> it = results.iterator();
        while (it.hasNext()) {
            Object[] r = it.next();
            forward(r);
        }
    }

    /** Process input record.
     *
     * @param inputData
     *            the string in which identifiers are to be searched and values to be extracted.
     * @return the list of object[] containing all the values the columns for a particular row. */
    public List<Object[]> processInputRecord(String inputData) {
        ArrayList<Object[]> result = new ArrayList<>();

        String[] dataParts = inputData.split("~");
        for (int j = 0; j < identifiers.size(); j++) {
            String[] find = identifiers.get(j); 
            datarow[j] = 0.0; // initializing value of the column

            for (int i = 0; i < dataParts.length; i++) {
                
                if (Arrays.stream(find).parallel().anyMatch(dataParts[i]::contains)) {
                    try {
                        String type = dataParts[i].split("_")[0]; // Either Premium,Discount,Rouding or PriceCap.
                        String reqValue = dataParts[i].split("_")[3];
                        if (("Premium").equalsIgnoreCase(type)) {
                            datarow[j] = Double.parseDouble(reqValue);
                        } else if (("Discount").equalsIgnoreCase(type)) {
                            datarow[j] = Double.parseDouble("-" + reqValue);
                        } else {
                            datarow[j] = Double.parseDouble(new DecimalFormat("##.##")
                                    .format(Double.parseDouble(dataParts[i].split("_")[2]) - Double.parseDouble(dataParts[i].split("_")[1])));
                        }
                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("The Specified index " + e.getLocalizedMessage() + " is not present in the input data :" + dataParts[i]);
                    }

                    break;
                }
            }
        }

        result.add(datarow);
        return result;
    }
    
    
    

    /*
     * (non-Javadoc)
     * @see org.apache.hadoop.hive.ql.udf.generic.GenericUDTF#close()
     */
    @Override
    public void close() throws HiveException {
        // Empty Function
    }
}
