package Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

class Grandparent {
	private void Print() {
		System.out.println("Grandparent's print");
	}
}

public class example {

	public static void main(String args[]) {

		LocalDate l = LocalDate.now();
	//	Date d = new Date();
		// System.out.println(d.toString());
		// System.out.println(d.hashCode());
		//System.out.println(d);
		String a = new String("yes");
		String b = new String("yes");
		int c=5;
		int d=5;
		
		int t[]={1,2};
		int u[]=t.clone();
		
		if(t.equals(u))
		{System.out.println("true in Equals in Int");}
		else
			System.out.println("false in Equals in Int");
		
		if(a.equals(b))
		{System.out.println("true in Equals");}
		else
			System.out.println("false in Equals");
		
		
		if (c==d) {System.out.println("true");}
		else
		{//System.out.println(c.hashCode() + " " + d.hashCode());
			
		}
		Integer x = new Integer(5);
		Integer y = new Integer(5);
		if (x==y) {}
		else
		System.out.println(x.hashCode() + " " + y.hashCode());
		// a=b;
		if (a == b)
			System.out.println("true");
		else
			System.out.println(false);

		System.out.println(a.hashCode() + " " + b.hashCode());
		//System.out.println(new Date());
		//System.out.println(LocalDate.now());
	}

}
