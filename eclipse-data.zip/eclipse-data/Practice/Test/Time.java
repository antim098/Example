package Test;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

class Timer implements ActionListener
{

    @Override
    public void actionPerformed(ActionEvent e)
    {

        System.out.println("At the tone the time is "+new Date());
        Toolkit.getDefaultToolkit().beep();

        // TODO Auto-generated method stub

    }

}

public class Time
{

    public static void main(String[] args) throws InterruptedException
    {

        ActionListener listener = new Timer();
        javax.swing.Timer t = new javax.swing.Timer(1000, listener);
        t.start();
        Thread.sleep(11001);
        t.stop();
    }

}
