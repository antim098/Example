package Test;

import java.util.Arrays;

public class Array {

	public static void main(String args[]) {
		String[] names = new String[3];
		names[0] = "one";
		names[1] = "two";
		names[2] = "three";

		for (int i = 0; i < names.length; i++) {
			System.out.println();
			for (int j = 0; j < names[i].length(); j++) {
				System.out.print("*");
			}
		}

		String a = Arrays.toString(names);
		System.out.println(a);
		//for (String b : names) {
	//		System.out.println(b);
		//}
	

	        int ar[] = {4, 6, 1, 8, 3, 9, 7, 4, 2};
	 
	        // Copy the whole array
	        int[] copy = Arrays.copyOf(ar,10);
	        System.out.println(copy.length);
	        System.out.println("Copied array => \n" + 
	                           Arrays.toString(copy));
	 
	        // Copy a specified range into a new array.
	        int[] rcopy = Arrays.copyOfRange(ar, 1, 5);
	        System.out.println("Copied subarray => \n" + 
	                           Arrays.toString(rcopy));
	
	        int ag[] = {4, 6, 1, 8, 3, 9, 7, 4, 2};
	 int [] arr=new int[10];
			 System.arraycopy(ag,0,arr, 0, 6);
			 System.out.println("my array => \n" + Arrays.toString(arr));
	        
	        // To fill a range with a particular value
	        Arrays.fill(ag, 0, 3, 0);
	        System.out.println("Array filled with 0 "+
	          "from 0 to 3 => \n" + Arrays.toString(ag));
	 
	        // To fill complete array with a particular
	        // value
	        Arrays.fill(ag, 10);
	        System.out.println("Array completely filled"+
	                  " with 10=>\n"+Arrays.toString(ag));
	
	
	        int[] ab=ar.clone();
	        if(ar.equals(ab))
	        {System.out.println("true");}
	        else
	        	System.out.println("false");
	}

}
