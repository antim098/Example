package Test;

public class Generics<T,E>
{
        private T t;
        public E e;

        public void add(T t,E e) {
           this.t = t;
           this.e=e;
        }

        public T get() {
         return t;
        }

        public static void main(String[] args) {
           Generics<Integer,String> integerBox = new Generics<Integer,String>();
          // Generics<String> stringBox = new Generics<String>();
         
           integerBox.add(new Integer(10),new String("Hello World"));
      //     stringBox.add(new String("Hello World"));

           System.out.printf("Integer Value :%d\n", integerBox.get());
         //  System.out.printf("String Value :%s\n", stringBox.get());
        }
     }
    
    

