package Test;



public class ThreadExample extends Thread
{
    
    public static void main(String[] args)
    {
    }
    
}
