package Test;


interface in1
{
    // public, static and final
    final int a = 10;
 
    // public and abstract 
    void display();
}
 
public class InterfaceExample implements in1{
	
	//static int a;

	
	   // Implementing the capabilities of
    // interface.
    public void display()
    {
        System.out.println("Geek");
    }
 
    // Driver Code
    public static void main (String[] args)
    {
        InterfaceExample t = new InterfaceExample();
        t.display();
        System.out.println(a);
    }

	
	
}
