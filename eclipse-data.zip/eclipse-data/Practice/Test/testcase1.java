package Test;

import static org.junit.Assert.*;

import org.junit.Test;

public class testcase1 {

	@Test
	public void testForAddFunction() {
		MyClass tester = new MyClass();
		int exp_result = 5;
		assertEquals("addition not happening", exp_result, tester.add(3, 2));
	}

}
