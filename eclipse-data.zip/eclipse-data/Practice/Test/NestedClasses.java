package Test;

import Test.OuterClass.InnerClass;

class OuterClass {
	// static member
	static int outer_x = 10;

	// instance(non-static) member
	int outer_y = 20;

	// private member
	private static int outer_private = 30;

	// inner class
	
	void display()
	{
	    System.out.println("outer class");
	}
	protected class InnerClass {
		void display() {
			// can access static member of outer class
			System.out.println("outer_x = " + outer_x);

			// can also access non-static member of outer class
			// System.out.println("outer_y = " + outer_y);

			// can also access private member of outer class
			 System.out.println("outer_private = " + outer_private);

		}
	}
}

// Driver class
public class NestedClasses {
	public static void main(String[] args) {
		// accessing an inner class

  OuterClass outer=new OuterClass();
  OuterClass.InnerClass inner = outer.new InnerClass();
  inner.display();
  outer.display();
	
	}
}