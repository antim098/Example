package Test;

interface Age
{
    int x = 21;
    void getAge();
}



class AnonymousDemo
{
    public static void main(String[] args) 
    {
        // Myclass is implementation class of Age interface
        //Age obj= ()-> System.out.println(Age.x); 
        // calling getage() method implemented at Myclass
    Age obj = new Age()
    {
        
        @Override
        public void getAge()
        {
           System.out.println(x);
        }
    };  
    obj.getAge();
    }
}
 
// Myclass implement the methods of Age Interface
