package sorting;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

class VerySimpleFormatter extends Formatter {

  private static final String PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

  @Override
  public String format(final LogRecord record) {
    return String.format(
              "%1$s %2$-7s %3$s\n",
              new SimpleDateFormat(PATTERN).format(
                      new Date(record.getMillis())),
              record.getLevel().getName(), formatMessage(record));
  }
}





/**
 * The Class LogClass.
 */
public class LogClass {
  /**
     * static method does Logger work.  
     * @return object of class Logger
   */
  public static Logger handler() {
    Logger log = Logger.getLogger("MyLog");
    ConsoleHandler handler = new ConsoleHandler();
    handler.setLevel(Level.ALL);
    VerySimpleFormatter sf = new VerySimpleFormatter();
    handler.setFormatter(sf);
    log.addHandler(handler);
   
    log.setLevel(Level.ALL);
    return log;
  }
}
    

   
