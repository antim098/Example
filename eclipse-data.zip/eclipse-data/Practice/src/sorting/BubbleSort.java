package sorting;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * The Class BubbleSort.
 */
public class BubbleSort {
  static String getElementCount = "Enter No. of Elements";
  static String getElements = "Enter Elements of Array";
  static String getUserChoice = "Enter Choice of Sorting:" + " 1.Ascending" + " 2.Descending";

  /** The log. */
  static Logger log = LogClass.handler();
  
 
  static void swapNumbers(int indexj, int[] array) {
    int temp = array[indexj];
    array[indexj] = array[indexj + 1];
    array[indexj + 1] = temp;
  }
  
  
 
  void bubbleSort(int []arr,int userChoice) {
    int length = arr.length;
    int flag = 0; 
    if (userChoice == 1) {
      for (int indexi = 0; indexi < length; indexi++) {
        flag = 0;
        for (int indexj = 0; indexj < length - indexi - 1; indexj++) {
          if (arr[indexj] > arr[indexj + 1]) {
            ++flag;
            swapNumbers(indexj, arr);
          }
        }
        if (flag == 0 && indexi == 0) {
          log.fine("Array already Sorted");
          break;
        } else if (flag == 0 && indexi != 0) {
          log.fine("Array sorted after " + indexi + " iteration");
          break;
        }
      }
    } else {
      for (int indexi = 0; indexi < length; indexi++) {
        flag = 0;
        for (int indexj = 0;indexj < length - indexi - 1;indexj++) {
          if (arr[indexj] < arr[indexj + 1]) {
            ++flag;
            swapNumbers(indexj, arr);
          }
        }
        if (flag == 0 && indexi == 0) {
          log.fine("Array already Sorted");
          break;
        } else if (flag == 0 && indexi != 0) {
          log.fine("Array sorted after " + indexi + " iteration");
          break; 
        }
      }
    }
  }
 
  
  /**
   * Prints the array.
   *
   * @param arr takes integer array
   */
  void printArray(int []arr) {
    int n = arr.length;
    log.fine("Sorted Array is: ");
    for (int i = 0;i < n; ++i) {
      log.log(Level.FINE, "{0} ", arr[i]);
    }
  }
  
  /*** Main Method.  
* @param args Array Elements
*/
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    log.fine(getElementCount);
    int number = input.nextInt();
    int [] array = new int[number];
    log.fine(getElements);
    for (int index = 0;index < number;index++) {
      array[index] = input.nextInt();
    }
    log.fine(getUserChoice);
    int userChoice = input.nextInt();
    BubbleSort bubbleSortObject = new BubbleSort();
    if (userChoice != 1 && userChoice != 2) {
      log.fine("Wrong choice inserted");    
      System.exit(0);
    }
    bubbleSortObject.bubbleSort(array, userChoice);
    bubbleSortObject.printArray(array);
    input.close();
  }
}
