
class Employee
{
  String a;

  Employee(String a){
    this.a = a;
  }
}

public class Swap{

  public static void swap(Employee x, Employee y)
    {
        String temp = x.a;
        x.a = y.a;
        y.a = temp;

        // Employee temp=x;
        // x=y;
        // y=temp;

        // System.out.println("a is"+x.a);
        // System.out.println("b is"+y.a);
    }
  
  
  public static void swapS(String a,String b)
  {
      
      String temp=a;
      a=b;
      b=temp;
  }

    public static void main(String args[])
    {
        Employee a = new Employee("Alice");
        Employee b = new Employee("Bob");
       
        String c="antim";
        String d="Verma";
        Swap.swapS(c,d);
        Swap.swap(a, b);

    System.out.println("A is" + a.a + " B is" + b.a);
    System.out.println("C is" +c+ "D is" + d);
    }
}
