import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

class Test2 extends Antim{
   
    
}


public class practice
{
    {
    Test2 t = new Test2();

    Antim x = new Antim(t);

    x.start();

    System.out.print("Start");

    try {

     x.join();

    } catch (InterruptedException e) {

     e.printStackTrace();

    }

    System.out.print("Stop");

   }

   public void run() {

    System.out.print("Run");

   }
  }



