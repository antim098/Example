import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Scanner;

import java.util.logging.FileHandler;

import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.swing.AbstractAction;

class Test
{

    // creating a private field
    private String employee_id;

    String name;

    String n = "hey";

    // creating a public constructor
    public Test()
    {
        s = "GeeksforGeeks";
    }

    private Test(String a)
    {
        s = "GeeksforGeeks";
    }

    // Creating a public method with no arguments
    public void method1()
    {
        n = "yes";
        System.out.println("The string is " + s);
        System.out.println("The string is " + name);
    }

    // Creating a public method with int as argument
    public void method2(int n)
    {
        System.out.println("The number is " + n);
    }

    // creating a private method
    private void method3()
    {
        System.out.println("Private method invoked");
    }

}

public class Reflections
{

    public static void main(String args[]) throws Exception
    {

        

        Logger logger = Logger.getLogger(Test.class.getName());
        logger.setLevel(Level.WARNING);
        FileHandler fh;
        fh = new FileHandler("/home/impadmin/a.log");
        logger.addHandler(fh);
        SimpleFormatter formatter = new SimpleFormatter();
        fh.setFormatter(formatter);
        logger.log(Level.SEVERE, "Hello its a warning");

        logger.log(Level.SEVERE, "Antim bro you did it...you can do it");

        // Creating object whose property is to be checked
        Test obj = new Test();

        // Creating class object from the object using
        // getclass method
        Class cls = obj.getClass();
        Class c = Class.forName("Test");
        System.out.println("The name of class is " + cls + "And " + c);

        // Getting the constructor of the class through the
        // object of the class
        Constructor constructor = cls.getConstructor();
        System.out.println("The name of constructor is " + constructor.getName());

        Test t = (Test) cls.newInstance();

        // Method m=cls.getMethod("method2",Integer.class);
        Method m1 = cls.getMethod("method2", new Class[] {int.class});
        
        m1.invoke(obj, 10);
        // System.out.println("getString1 returned: " + str1);

        System.out.println("The public methods of class are : ");

        // Getting methods of the class through the object
        // of the class by using getMethods
        Method[] methods = cls.getMethods();

        // Printing method names
        for (Method method : methods)
            System.out.println(method.getName());

        // creates object of desired method by providing the
        // method name and parameter class as arguments to
        // the getDeclaredMethod
        Method methodcall1 = cls.getDeclaredMethod("method2", int.class);

        // invokes the method at runtime
        methodcall1.invoke(obj, 19);

        // creates object of the desired field by providing
        // the name of field as argument to the
        // getDeclaredField method
        Field field = cls.getDeclaredField("s");

        Field field1 = cls.getDeclaredField("name");
        field1.setAccessible(false);
        field1.set(obj, "Antim");

        // allows the object to access the field irrespective
        // of the access specifier used with the field
        field.setAccessible(true);

        // takes object and the new value to be assigned
        // to the field as arguments
        field.set(obj, "JAVA");

        // Creates object of desired method by providing the
        // method name as argument to the getDeclaredMethod
        Method methodcall2 = cls.getDeclaredMethod("method1");

        // invokes the method at runtime
        methodcall2.invoke(obj);

        // Creates object of the desired method by providing
        // the name of method as argument to the
        // getDeclaredMethod method
        Method methodcall3 = cls.getDeclaredMethod("method3");

        // allows the object to access the method irrespective
        // of the access specifier used with the method
        methodcall3.setAccessible(true);

        // invokes the method at runtime
        methodcall3.invoke(obj);

        Constructor[] construcors = cls.getDeclaredConstructors();
        for (Constructor con : construcors)
            System.out.println(con.getName());

    }
}
