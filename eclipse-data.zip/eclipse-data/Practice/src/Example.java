

 class Grandparent
   {
	private void Print()
	 {
	  System.out.println("Grandparent's print");	
	 }
   }

  class Parent extends Grandparent
{
	
	protected int a=5;
	protected void Print()
	 {
		
	  System.out.println("Parent's print");	
	 }
}

class Child extends Parent
{ 
	 int a=5;
	static int b=6;
	public void Print()
	 {
     super.Print();
	  System.out.println("Child's print");	
	 }
	
	protected int add(int a,int b)
	{
		System.out.println("child class version");
		return a+b;
	}
	
	
}

class Newchild extends Child
{
	
	
    public void Print()
      {
    	super.Print();
    	System.out.println("New child's print");
    	//System.out.println(b);
    
      }
    
    @Override
   public int add(int a,int b)
	{
		return a+b;
	}
    
}


public class Example {

     public static void main(String args[])
               {
    	       Child c=new Newchild();
    	       System.out.println(c.add(2,3));
    	       System.out.println(c.getClass());
    	       System.out.println(c.b);
               }
}
