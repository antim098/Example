package inheritence;

import java.util.logging.Logger;

public class Vehicle {
  static Logger log = LogClass.handler("Vehicle");
  private int  vehicleModel;
  private String registrationNumber;
  private int vehicleSpeed;
  private int  fuelCapacity;
  private int  fuelConsumption; 
  
  /**
   * Constructor For Vehicle.  
   */
  public Vehicle(int vehicleModel, String registrationNumber, int vehicleSpeed, 
      int fuelCapacity, int fuelConsumption) {
    this.vehicleModel = vehicleModel; 
    this.registrationNumber = registrationNumber;
    this.vehicleSpeed = vehicleSpeed;
    this.fuelCapacity = fuelCapacity;
    this.fuelConsumption = fuelConsumption;
  } 
  
  public int getVehicleModel() {
    return vehicleModel;
  }
  
  public void setVehicleModel(int vehicleModel) {
    this.vehicleModel = vehicleModel;
  } 
   
  public String getRegistrationNumber() {
    return registrationNumber;
  }
  
  public void setRegistrationNumber(String registrationNumber) {
    this.registrationNumber = registrationNumber;
  }
  
  public double getVehicleSpeed() {
    return vehicleSpeed;
  }
  
  public void setVehicleSpeed(int vehicleSpeed) {
    this.vehicleSpeed = vehicleSpeed;
  }
  
  public int getFuelCapacity() {
    return fuelCapacity;
  }
  
  public void setFuelCapacity(int fuelCapacity) {
    this.fuelCapacity = fuelCapacity;
  }
  
  public int getFuelConsumption() {
    return fuelConsumption;
  }
  
  public void setFuelConsumption(int fuelConsumption)  {
    this.fuelConsumption = fuelConsumption;
  }
  
  /**
   * Calculate fuel needed by vehicle.  
   */
  public float fuelNeeded(int distance) {
   
    return (float) distance / fuelConsumption;
    
  }
  
  public float distanceCovered(float time) {
    return time * vehicleSpeed;
    
  }
  
  /**
   * Display all properties of vehicle.  
   */ 
  public void display() {
    log.fine("Vehicle Model: " + vehicleModel); 
    log.fine("Registration Number:" + registrationNumber);
    log.fine("Speed: " + vehicleSpeed + " km/hr"); 
    log.fine("Fuel Capacity: " + fuelCapacity + " litres");
    log.fine("Fuel Consumption: " + fuelConsumption + " km/litre");
  }
  
  
  
  
  
}
