package inheritence;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Transport {
    
  static Logger transportLog = LogClass.handler("Transport");
  /**
   * Main Method.  
   * @param args Array Elements
   */

  public static void main(String[] args) { 
    
    Vehicle truck = new Truck(2018,"MP13-2756-09",10,16,40,60);
    transportLog.fine("Fuel Needed By Truck: " + truck.fuelNeeded(600));
    transportLog.fine("Distance Covered By Truck: " + truck.distanceCovered(30));
    transportLog.fine("Truck Details are: ");
    truck.display();
    
    Vehicle bus = new Bus(2016,"M-37-290",40,55,30,100);
    
    transportLog.fine("Fuel Needed By Bus: " + bus.fuelNeeded(400));
    transportLog.fine("Distance Covered By Bus:" + truck.distanceCovered(60));
    transportLog.fine("Bus Details are: ");
    bus.display();
  }
    
    
}
