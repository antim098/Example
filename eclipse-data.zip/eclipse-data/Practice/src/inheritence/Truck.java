package inheritence;

import java.util.logging.Logger;

// TODO: Auto-generated Javadoc
/**
 * The Class Truck.
 */
public class Truck extends Vehicle {
  
  /** The log. */
    static Logger log = LogClass.handler("Truck");
  
  /** The cargo weight limit. */
  private int cargoWeightLimit;

  /**
   * Instantiates a new truck.
   *
   * @param vehicleModel the vehicle model
   * @param registrationNumber the registration number
   * @param vehicleSpeed the vehicle speed
   * @param fuelCapacity the fuel capacity
   * @param fuelConsumption the fuel consumption
   * @param cargoWeightLimit the cargo weight limit
   */
  public Truck(int vehicleModel, String registrationNumber, int vehicleSpeed, 
      int fuelCapacity, int fuelConsumption,
      int cargoWeightLimit) {
    super(vehicleModel, registrationNumber, vehicleSpeed, fuelCapacity, fuelConsumption);
    this.cargoWeightLimit = cargoWeightLimit;
  }

  /**
   * Gets the cargo weight limit.
   *
   * @return the cargo weight limit
   */
  public int getCargoWeightLimit() {
    return cargoWeightLimit;
  }

  /**
   * Sets the cargo weight limit.
   *
   * @param cargoWeightLimit the new cargo weight limit
   */
  public void setCargoWeightLimit(int cargoWeightLimit) {
    this.cargoWeightLimit = cargoWeightLimit;
  }
  
  /* (non-Javadoc)
   * @see inheritence.Vehicle#display()
   */
  @Override   
  public void display() {
    super.display();
    log.fine("Cargo Weight Limit:" + cargoWeightLimit);
  }
    
    
}
