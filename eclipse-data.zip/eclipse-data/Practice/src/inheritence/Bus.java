package inheritence;

import java.util.logging.Logger;


/**
 * The Class Bus which has all the functionalities of bus.
 */
public class Bus extends Vehicle {
  
  /** The Logger object to use log */
  static Logger busLog = LogClass.handler("Bus");
  
  /** The no passengers. */
  private  int noPassengers;

  /**
   * Instantiates a new bus.
   *
   * @param vehicleModel the vehicle model
   * @param registrationNumber the registration number
   * @param vehicleSpeed the vehicle speed
   * @param fuelCapacity the fuel capacity
   * @param fuelConsumption the fuel consumption
   * @param noPassengers the no passengers
   */
  public Bus(int vehicleModel, String registrationNumber, int vehicleSpeed, 
      int fuelCapacity, int fuelConsumption, int noPassengers) {
    super(vehicleModel, registrationNumber, vehicleSpeed, fuelCapacity, fuelConsumption);
    this.noPassengers = noPassengers;
  }

  /**
   * Gets the no passengers.
   *
   * @return the no passengers
   */
  public int getNoPassengers() {
    return noPassengers;
  }

  /**
   * Sets the no passengers.
   *
   * @param noPassengers the new no passengers
   */
  public void setNoPassengers(int noPassengers) {
    this.noPassengers = noPassengers;
  }
  
  /* 
   * @see overrides and uses the display method of parent class.
   */
  @Override
  public void display() {
    super.display();
    busLog.fine("No. of Passengers:" + noPassengers);
  }
  
  
}
