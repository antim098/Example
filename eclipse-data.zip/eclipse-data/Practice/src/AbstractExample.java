
interface in1 {
	// public, static and final
	final int a = 10;

	// public and abstract
	void display();
}

abstract class Base implements in1 {

    
	public void display() {

		System.out.println(a);
		System.out.println("overridden inerface display method");
	}

	void fun() {
		System.out.println("Base fun() called");
	}
}

class Derived extends Base {

	// void fun() { System.out.println("Derived fun() called");}
}

public class AbstractExample {
	public static void main(String args[]) {
		Base b = new Derived();
		b.fun();
		b.display();
	}

}
