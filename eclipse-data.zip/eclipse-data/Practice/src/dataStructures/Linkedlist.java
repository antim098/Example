package dataStructures;

public class Linkedlist {

	

}
