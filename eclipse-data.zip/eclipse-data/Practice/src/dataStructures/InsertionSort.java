package dataStructures;

import java.util.Arrays;
import java.util.Date;
class box

{

    int width;

    int height;

    int length;
}

public class InsertionSort {

	public static int [] Isort(int ind, int[] a) {
		int index = ind;
		if (index == 0) {
			++index;
			Isort(index, a);
		} else if(index<a.length){

			for (int i = 0; i <index; i++) {
				if (a[i] > a[index]) {
					int temp = a[i];
					a[i] = a[index];
					a[index] = temp;
				}
			}
			++index;
			Isort(index,a);

		}
    return a;
	}

	public static void main(String args[]) {
	    
		 Date date = new Date(2018, 12, 25, 10, 10);

	        System.out.println(date);
	        String str = 1+2+"imp"+3+"etus"+4+5;

	        System.out.println(str);
	        
	        byte x = 127;

            byte y = 1;

System.out.println(x + y);


int z = 50;

double g = 1;

System.out.println(g + z);

long b = (int)4.0 ;
byte c=4;

System.out.println(b);
System.out.println(c);

		

	//	int arr[] = { 10,14,12, 11, 13, 5, 6 };
	//	int[] ar = Isort(0,arr);
	//	System.out.println(Arrays.toString(ar));

	}

}
