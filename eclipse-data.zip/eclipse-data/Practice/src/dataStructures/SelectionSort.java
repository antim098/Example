package dataStructures;

import java.util.Arrays;

public class SelectionSort {

	public static int[] min(int ind, int[] a) {
		if (ind < (a.length)) {
			// int curIndex =curInd;
			int index = ind;
			int min = a[index];
			int minIndex = 0;
			for (int i = index; i < a.length; i++) {

				if (a[i] <= min) {
					min = a[i];
					minIndex = i;
				}
			}

			int temp = a[index];
			a[index] = min;
			a[minIndex] = temp;
			// System.out.println(Arrays.toString(a));
			// ++curIndex;
			++index;
			min(index, a);
		}
		return a;

	}

	public static void main(String args[]) {

		int arr[] = { 25, 35, 45, 12, 65, 10, 55 };
		int[] ar = min(0, arr);
		System.out.println(Arrays.toString(ar));

	}

}
