package dataStructures;

import java.util.Arrays;

import Test.Array;

public class mergeSort {
	
	
	public static void main(String args[]) {

		int []L= {7,3,5,6};
		int []R= {2,8,9,12};
		
		int i=0,j=0,k=0;
		int n1=L.length;
		int n2=R.length;
		int arr[]=new int[n1+n2];
		
		 while (i < n1 && j < n2)
	        {
	            if (L[i] <= R[j])
	            {
	                arr[k] = L[i];
	                i++;
	            }
	            else
	            {
	                arr[k] = R[j];
	                j++;
	            }
	            k++;
	        }
	 
	        while (i < n1)
	        {
	            arr[k] = L[i];
	            i++;
	            k++;
	        }
	 
	        while (j < n2)
	        {
	            arr[k] = R[j];
	            j++;
	            k++;
	        }	
		
	        System.out.print(Arrays.toString(arr));
	        
	        
		
	}

}
