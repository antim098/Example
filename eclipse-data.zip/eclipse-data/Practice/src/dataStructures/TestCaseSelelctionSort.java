package dataStructures;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

public class TestCaseSelelctionSort {

	@Test
	public void selectionSortTest() {
		
		SelectionSort s=new SelectionSort();
		int qus[]= {30,22,60,70,21,32};
		int result[]={21,22,30,32,60,70};
		assertArrayEquals("Success",result, s.min(0, qus));
	}
	
}
