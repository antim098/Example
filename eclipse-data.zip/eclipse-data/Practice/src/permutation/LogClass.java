package permutation;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

class VerySimpleFormatter extends Formatter {

  private static final String PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

  /*This Class extends Formatter and overrides default format method to provide
  custom console output through Log.*/
  
  @Override
  public String format(final LogRecord record) {
    return String.format(
              "%1$s %2$-7s %3$s\n",
              new SimpleDateFormat(PATTERN).format(
                      new Date(record.getMillis())),
              record.getLevel().getName(), formatMessage(record));
  }
}





/**
 * The Class LogClass which is used to get Logger object in all the classes 
 * where log is required.
 */
public class LogClass {
  /**
     * static method does Logger work.  
     * @return object of class Logger when called.
   */
  public static Logger handler(String name) {
    Logger log = Logger.getLogger(name);
    ConsoleHandler handler = new ConsoleHandler();
    handler.setLevel(Level.ALL);
    VerySimpleFormatter sf = new VerySimpleFormatter();
    handler.setFormatter(sf);
    log.addHandler(handler);
    log.setLevel(Level.ALL);
    return log;
  }
}
    

   
