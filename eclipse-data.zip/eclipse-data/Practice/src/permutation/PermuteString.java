package permutation;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.logging.Logger;


/**
 * The Class PermuteString.
 */
public class PermuteString {
  
  /** The log object for PermuteString class. */
  static Logger log = LogClass.handler("permute");
  
  /** The collection datastructure to store permutations*/
  static HashSet<String> permutations = new HashSet<String>(); 
  //creating hashset to store all string permutations and prevent duplicate entries.

   
  /**
   * Check string.
   *
   * @param str this method checks whether the given string contains all similar letters or not.
   * @return true, if successful
   */
  public static boolean checkString(String str) { 
    Boolean result = false;
    for (int index = 0;index < str.length() - 1;index++) {
      if (str.charAt(index) == (str.charAt(index + 1))) {  
        continue;
      } else {
        result = true;
        break;    
      }
    }
    return result;
  }
  
  /**
   * Permute.
   *
   * @param prefix contains fixed  
   * @param str contains string to be permuted
   */
  //This is the method which contains the main logic for permuting the string,it computes strings recursively.
  //Stores permutations one by one in Hashset
  public static void permute(String prefix, String str) {
    int length = str.length();
    if (length == 0) {
      permutations.add(prefix); 
    } else {
      for (int index = 0; index < length; index++) {
        permute(prefix + str.charAt(index), 
            str.substring(0, index) + str.substring(index + 1, length));
      }
    }
  }
  
  /**
   * Main Method.  
   * @param args Array Elements
   */  
  
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    log.fine("Enter String");
    String str = input.next();
    if (checkString(str)) { 
      permute("", str);   
      Iterator<String> itr1 = permutations.iterator();
      while (itr1.hasNext()) {
        log.fine(itr1.next());
      }
    } else {
      log.fine("No New Permutations for this String");
    }
    
    input.close();
  }
}
