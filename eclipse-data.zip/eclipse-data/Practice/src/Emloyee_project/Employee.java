package Emloyee_project;

import java.util.Scanner;

public class Employee {
	
	private int id;
    private String name;
	private double salary;
	
	
	
	public void Print()
	{
		System.out.println("hello method of employee class called");
	}

	Employee() {
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	Employee(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}


	public String getName() {
		return name;
	}


	public double getSalary() {
		return salary;
	}

}

class Employer extends Employee {
	
}
