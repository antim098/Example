package Emloyee_project;

import java.util.ArrayList;
import java.util.Scanner;

class Manager extends Employee {

	Scanner input = new Scanner(System.in);
	private int current_user;

	public Manager(int id, String name, double salary) {
		super(id, name, salary);
	}

	public Manager() {
		// TODO Auto-generated constructor stub
	}

	void allUsers(ArrayList<Employee> Users) {
		System.out.println("Employee Details");
		System.out.println("\t" + "ID" + "\t" + "Name" + "\t" + "Salary");
		for (int i = 0; i < Users.size(); i++) {

			System.out.println(
					"\t" + Users.get(i).getId() + "\t" + Users.get(i).getName() + "\t" + Users.get(i).getSalary());
		}
	}

	void showDetails(int id, ArrayList<Employee> Users) {
		for (int i = 0; i < Users.size(); i++) {
			if (id == (Users.get(i).getId())) {
				current_user = i;
				System.out.println("Employee Details");
				System.out.println("\t" + "ID" + "\t" + "Name" + "\t" + "Salary");
				System.out.println(
						"\t" + Users.get(i).getId() + "\t" + Users.get(i).getName() + "\t" + Users.get(i).getSalary());
			}

		}

	}

	void managerFunctions(int id, ArrayList<Employee> Users) {
		showDetails(id, Users);
		System.out.println("Select functions to perform");
		System.out.println("1.Change name");
		System.out.println("2.Delete account");
		System.out.println("3.Show all users");

		int choice = input.nextInt();
		if (choice == 1) {
			changeName(Users);
		} else if (choice == 2) {
			deleteAccount();
		} else if (choice == 3) {
			allUsers(Users);
		} else
			System.out.println("wrong choice");
	}

	void changeName(ArrayList<Employee> Users) {
		System.out.println("Enter New name");
		String name = input.next();
		Users.get(current_user).setName(name);

		System.out.println("Updated Employee Details");
		System.out.println("\t" + "ID" + "\t" + "Name" + "\t" + "Salary");
		System.out.println("\t" + Users.get(current_user).getId() + "\t" + Users.get(current_user).getName() + "\t"
				+ Users.get(current_user).getSalary());
	}

	void deleteAccount() {

	}

}