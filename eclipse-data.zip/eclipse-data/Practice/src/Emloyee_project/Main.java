package Emloyee_project;

import java.awt.print.Printable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Scanner;

public class Main
{

    static ArrayList<Employee> Users = new ArrayList<>();

    static Scanner input = new Scanner(System.in);

    static void addUser()
    {
        String name;
        int id;
        double salary;
        System.out.println("Enter name,id,salary");
        name = input.next();
        id = input.nextInt();
        salary = input.nextDouble();
        Users.add(new Employee(id, name, salary));
    }

    public static void main(String args[]) throws NoSuchFieldException, SecurityException, IllegalArgumentException,
        IllegalAccessException, NoSuchMethodException
    {

        Employee antim = new Manager(7, "Antim kant Verma", 40000);
        Class cl = antim.getClass();
        Class cl2 = cl.getSuperclass();
        System.out.println(cl);
        Field f = cl2.getDeclaredField("name");
        f.setAccessible(true);
        Object v = f.get(antim);
        System.out.println(v);

        Method m1 = Employee.class.getDeclaredMethod("Print", null);

        // m1.invoke("",null);

        Users.add(new Manager(1, "Antim", 22400));
        Users.add(new Manager(2, "Prateek", 34000));

        System.out.println("Want to add new user (Y/N)");
        String c = input.next();
        if (c.equals("Y"))
            addUser();

        System.out.println("Enter Category");
        String category = input.next();
        if (category.equalsIgnoreCase("Manager")) {

            System.out.println("Enter id");
            int id = input.nextInt();
            Manager m = new Manager();
            m.managerFunctions(id, Users);
        }
        // input.close();
        
        
        Employee e1 = new Employee();
        Manager m = new Manager();
        
        

    }

}
