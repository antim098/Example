

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class Collections {

	public static void main(String args[]) {
		TreeSet<Integer> a = new TreeSet<Integer>(); // creating treeSet
		a.add(12); // adding elements
		a.add(13);
		a.add(9);
		a.add(12);
		Iterator<Integer> itr = a.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

		int ar[] = { 1, 201, 30, 4 };
		// List<Integer> l=Arrays.stream(ar).boxed().collect(Collectors.toList());
		int l = ar.length;
		HashSet<String> al = new HashSet<>(); // creating hashSet
		al.add("Rachit"); // adding elements
		al.add("Amit");
		al.add("jack");
		al.add("Amit");

		Iterator<String> itr1 = al.iterator();
		while (itr1.hasNext()) {
			System.out.println(itr1.next());
		}

	}

}
