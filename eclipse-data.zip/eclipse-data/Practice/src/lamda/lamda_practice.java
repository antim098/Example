package lamda;

import java.util.ArrayList;

import javax.swing.SingleSelectionModel;

interface FuncInterface
{
    // An abstract function
    void abstractFun(int x);
 
    // A non-abstract (or default) function
    default void normalFun()
    {
       System.out.println("Hello");
    }
}

public class lamda_practice
{
  
    
    public static void main(String[] args)
    {
        FuncInterface f=(int x)-> System.out.println(2*8);
      //  FuncInterface fh=new lamda_practice();
        
       FuncInterface square=(int x)-> System.out.println(x*x); 
       FuncInterface cube=(int x )-> System.out.println(x*x*x);
        f.abstractFun(6);
       square.abstractFun(3);
       cube.abstractFun(2);
        
        long b = 50; 
        int c;
        //type casting int to byte
        c =(int) (b * 2); 
        System.out.println(b);
        
        
        ArrayList<Integer> arrL = new ArrayList<Integer>();
        arrL.add(1);
        arrL.add(2);
        arrL.add(3);
        arrL.add(4);
 
        // Using lambda expression to print all elements
        // of arrL
        for(int n:arrL)
            System.out.println("Hello user");
        arrL.forEach(x -> System.out.println(x));
 
        // Using lambda expression to print even elements
        // of arrL
        arrL.forEach(n -> { if (n%2 == 0) System.out.println(n); });
        
        try {
            int x = 0;
            int y = 10;
            int z = y/x;
            System.out.println(z);
        } catch (ArithmeticException e) {
            
            System.out.println("Cannot divide by zero");
        }
        
        
    }

 
    
    
}
