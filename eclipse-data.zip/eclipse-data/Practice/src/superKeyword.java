class Vehicle 
{ 
    int maxSpeed = 120; 
    
  
    static void display() 
    
    { 
        /* print maxSpeed of base class (vehicle) */
        System.out.println("Maximum Speed: 140"); 
    } 
    
} 

/* sub class Car extending vehicle */
class Car extends Vehicle 
{ 
    static int maxSpeed = 180; 
  
    void dis() 
    { 
        /* print maxSpeed of base class (vehicle) */
        super.display(); 
    } 
} 
  
/* Driver program to test */
class superKeyword 
{ 
    public static void main(String[] args) 
    { 
        Car small = new Car();
        small.dis(); 
    
    } 
    
} 