

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** The Class DistinctWordList. */
public class DistinctWordList {

    /** The log. */
    private static Logger log = LoggerFactory.getLogger(DistinctWordList.class);

    /** The main method.
     *
     * @param args
     *            the arguments */
    public static void main(String[] args) {
        
        Path filePath = Paths.get("/home/impadmin/antim");
        String token;
        // This will reference one line at a time
        String line = null;
        ArrayList<String> wordList = new ArrayList<>();
        try(FileReader fileReader = new FileReader(filePath.toString());
            BufferedReader bufferedReader = new BufferedReader(fileReader))  {
            // FileReader reads text files in the default encoding.

            // Always wrap FileReader in BufferedReader.
            

            while ((line = bufferedReader.readLine()) != null) {
                StringTokenizer st1 = new StringTokenizer(line, " ,.:;");
                while (st1.hasMoreTokens()) {
                    token = st1.nextToken().toLowerCase();
                    if (!wordList.contains(token)) {
                        wordList.add(token);
                    }

                }
            }

        } catch (FileNotFoundException ex) {
            log.info("Unable to open file {}", filePath);
        } catch (IOException ex) {
            log.info("Error reading file {}", filePath);
            // Or we could just do this:
        } 
            
        String word;
        Iterator<String> listIterator = wordList.iterator();
        while (listIterator.hasNext()) {
            word = listIterator.next();
            log.info("{}", word);
        }
    }
}
