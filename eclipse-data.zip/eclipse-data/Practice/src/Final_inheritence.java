
class C {
	public final int a = 5;
	final int b = 6;

	public static void Print() {
		System.out.println("Child's print");
	}

}

class NC extends C {
	// int a=2;
	int b = 1;
	// System.out.println(a);

	//public static void Print() {
		// super.Print();
		//System.out.println("New child's print");

		// System.out.print(sum);
		// System.out.println(b);


	public void add() {
		System.out.println(a);
		// int sum=super.a+super.b;
		// int sum1=a+b;
		// System.out.println(sum);
		// System.out.println(c)
		// System.out.println("new child class version");

	}

}

public class Final_inheritence {

	public static void main(String args[]) {
		C c = new C();

		int a = 20;
		int b = 0;

		c.Print();
		// System.out.println((a/b));

		// c.add();
		// System.out.println(a);

		// System.out.println();
		// System.out.println(c.Print());
		// System.out.println(c.getClass());
		// System.out.println(c.b);
	}

}