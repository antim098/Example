package countLength;

import org.apache.hadoop.hive.ql.exec.UDF;

import javolution.text.Text;

public class length extends UDF {

    public int evaluate(Text str) {

        if (str == null) {

            return 0;

        }
        return str.toString().length();
    }

}
