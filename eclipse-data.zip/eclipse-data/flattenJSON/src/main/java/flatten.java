import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class flatten {


    public static HashMap<String, ArrayList<LinkedTreeMap<String, String>>> getJSON() throws FileNotFoundException {
        String path = "/home/impadmin/Downloads/samplejson5_14.json";
        BufferedReader bufferedReader = new BufferedReader(new FileReader(path));

        Gson gson = new Gson();
        HashMap<String, ArrayList<LinkedTreeMap<String, String>>> json = gson.fromJson(bufferedReader, HashMap.class);
        return json;
    }


    public static void main(String[] args) {
        try {
            HashMap<String, ArrayList<LinkedTreeMap<String, String>>> data = getJSON();
            for (Map.Entry<String, ArrayList<LinkedTreeMap<String, String>>> entry : data.entrySet()) {
                String key = entry.getKey();
                System.out.println(key);
                ArrayList<LinkedTreeMap<String, String>> values = data.get(key);
                for (int i = 0; i < values.size(); i++) {
                    LinkedTreeMap<String, String> value = values.get(i);

                    for (Map.Entry<String, String> en : value.entrySet()) {
                        String key1 = en.getKey();
                        String value1 = String.valueOf(en.getValue());
                        System.out.println(key1 + " => " + value1);
                    }
                }
            }

        } catch (
                FileNotFoundException e) {
            e.printStackTrace();
        }


    }

}
