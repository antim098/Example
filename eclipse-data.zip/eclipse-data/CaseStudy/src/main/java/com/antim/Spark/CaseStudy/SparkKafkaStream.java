package com.antim.Spark.CaseStudy;

import org.apache.spark.network.protocol.Encoders;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.sql.functions.*;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.SQLImplicits.*;

public class SparkKafkaStream {

    public static void main(String[] args) {

        SparkSession spark = SparkSession.builder().appName("Kafka Integration").master("local[*]").getOrCreate();

        StructType jsonSchema = new StructType(new StructField[] { new StructField("dcid", DataTypes.IntegerType, true, Metadata.empty()),
                new StructField("userid", DataTypes.StringType, true, Metadata.empty()),
                new StructField("Time", DataTypes.StringType, true, Metadata.empty()) });
        Dataset<Row> streamingDF = spark.readStream().schema(jsonSchema).json("/home/impadmin/sample");

        streamingDF.printSchema();

        streamingDF.selectExpr("to_json(struct(*)) AS value").writeStream().format("kafka").option("topic", "antim")
                .option("kafka.bootstrap.servers", "localhost:9092").option("checkpointLocation", "/home/impadmin/logs").start();

        Dataset<Row> outStream = spark.readStream().format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe","antim").option("checkpointLocation", "localhost:9092").load();
        
        
        Dataset<Row> df1 = outStream.selectExpr("CAST(value AS STRING)", "CAST(timestamp AS TIMESTAMP)")
                .select(functions.from_json(new Column("value"),jsonSchema).as("data"),"timestamp").select("data.*", "timestamp");

        
        
        // streamingDF.select("dcid").writeStream().format("console").start()
        StreamingQuery query = streamingDF.writeStream().outputMode("update").option("truncate", "false").format("console").start();

        try {
            query.awaitTermination();
        } catch (StreamingQueryException e) {

            e.printStackTrace();
        }
    }
}
