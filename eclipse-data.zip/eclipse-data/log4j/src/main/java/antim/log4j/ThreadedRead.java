package antim.log4j;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class Progress extends Thread
{

    static int i = 1;

    @Override
    public void run()
    {
        System.out.print(".");

    }

}

public class ThreadedRead extends Thread
{

    private static Logger log = LoggerFactory.getLogger(ThreadedRead.class);

    File file = new File("/home/impadmin/fileToRead.txt");

    File outputFile = new File("/home/impadmin/fileWritten.txt");

    long size = file.length();

    int byteToRead = (int) size / 5;

    byte[] byteToWrite = new byte[byteToRead];

    static long start;

    static long lineToRead;

    static long end;

    String name;

    public static long getLineCount(File file) throws IOException
    {

        try (BufferedInputStream is = new BufferedInputStream(new FileInputStream(file), 1024)) {

            byte[] c = new byte[1024];
            boolean empty = true, lastEmpty = false;
            long count = 0;
            int read;
            while ((read = is.read(c)) != -1) {
                for (int i = 0; i < read; i++) {
                    if (c[i] == '\n') {
                        count++;
                        lastEmpty = true;
                    } else if (lastEmpty) {
                        lastEmpty = false;
                    }
                }
                empty = false;
            }

            if (!empty) {
                if (count == 0) {
                    count = 1;
                } else if (!lastEmpty) {
                    count++;
                }
            }

            return count;
        }
    }

    @Override
    public void run()
    {
        try (Scanner fileScanner = new Scanner(file); FileWriter writer = new FileWriter(outputFile)) {
            log.info("reading line");
            log.info("Thread name {} and lines read {}", Thread.currentThread().getName(), end);
            synchronized (new Thread()) {
                if (start != 0) {
                    start = end + 1;
                    end = end + lineToRead;
                }
            }
            ArrayList<String> lines = new ArrayList<>();

            while (start < end) {

                if (fileScanner.hasNextLine()) {
                    synchronized (new Thread()) {
                        writer.write(fileScanner.nextLine());
                        // writer.write(lines);
                        start++;
                    }

                }

            }
            end = end + lineToRead;

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        log.info("Thread Exiting from the system : name {} ", Thread.currentThread().getName());

    }

    public static void main(String[] args)
    {
        long lineCount = 0;
        File file = new File("/home/impadmin/fileToRead.txt");
        try {
            lineCount = getLineCount(file);
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        lineToRead = lineCount / 5;
        start = 0;
        end = start + lineToRead;

        ExecutorService pool = Executors.newFixedThreadPool(5);
        ThreadedRead th = new ThreadedRead();
        // th.start();
        pool.execute(th);
        pool.execute(th);
        pool.execute(th);
        pool.execute(th);
        pool.execute(th);
        log.info("printing values");
        /*
         * Iterator<String> itr = line.iterator(); while (itr.hasNext()) { log.info("{}", itr.next())
         */;
    }
}
