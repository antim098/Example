package antim.log4j;

public class progress extends Thread
{

    
    @Override
    public  void run() 
    {
        
    }
    
    
    
    
    public static void main(String[] args)
    {
        
    }
    
}
