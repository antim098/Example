package antim.log4j;


/**
 * Hello world!
 *
 */
public class App 
{
        
       
        public static void main(String[] args) {
        
           
            
        }
}
