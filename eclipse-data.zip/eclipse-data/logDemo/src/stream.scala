
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.{Seconds, StreamingContext, Time}
import org.apache.spark.rdd.RDD
import org.apache.log4j.Logger

object stream {
  
  val logger = Logger.getLogger(getClass.getName)
  logger.info("Hello...this is to test the logger.")
  
  def main(args: Array[String]) {
    val checkpointDirectory = "hdfs://localhost:9000/checkpoints"
    val ssc = StreamingContext.getOrCreate("hdfs://localhost:9000/checkpoints",
      () => createContext("localhost",9999,checkpointDirectory))
    ssc.start()
ssc.awaitTermination()
    logger.info("Completed program")
  }
  
  def createContext(ip: String, port: Int,checkpointDirectory: String)
: StreamingContext = {
    logger.info("If you do not see this printed, that means the StreamingContext has been loaded")
    logger.info("from the new checkpoint")
    logger.info("....................Creating new context..................................................")
    val sparkConf = new SparkConf().setAppName("RecoverableNetworkWordCount").setMaster("local")
    // Create the context with a 1 second batch size
    val ssc = new StreamingContext(sparkConf, Seconds(2))
    ssc.checkpoint(checkpointDirectory)
   // NotSerializable notSerializable = new NotSerializable();
    val lines = ssc.socketTextStream(ip, port)
    val words = lines.flatMap(_.split(" "))
    val wordCounts = words.map((_, 1)).reduceByKey(_ + _)
    val ckwordCount=wordCounts.checkpoint(Seconds(2))
    ckwordCount.saveAsTextFiles("test", "files")
    logger.info("finished reading...now writing")
    logger.info(ckwordCount)
    ssc 
  } 
}