package com.antim.Demo;

import java.time.Period;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.sound.midi.Soundbank;

public class problem1 {

    public static long getMinimumStops(int k, int p, Map<Integer, Integer> petrolFillInfo) {
        int airportDistance = k ;
        int petrol = p;
        int pumpCount=0;
        int oldPetrol =0;
        
        Iterator<Entry<Integer, Integer>> it = petrolFillInfo.entrySet().iterator();
        while(it.hasNext())
        {
            Map.Entry<Integer, Integer> entry = it.next();
            int kdiff = airportDistance-entry.getKey();
            if(kdiff<petrol)
            {
                
                airportDistance = entry.getKey();
                oldPetrol = entry.getValue();
                petrol = p-kdiff;
                
            }
            else if(kdiff>petrol){
                ++pumpCount;
                if((petrol-kdiff)<0) return -1;
                petrol = petrol+oldPetrol;
                oldPetrol =entry.getValue();
                airportDistance = entry.getKey();
                
            }
           
        }
        return pumpCount+1;
        
 }
    
    public static void main(String[] args) {
        
        Map<Integer, Integer> values = new HashMap<Integer, Integer>();
        values.put(25,10);
        values.put(20,4);
        values.put(15,8);
        values.put(12,5);
        values.put(10,7);
        System.out.println(getMinimumStops(30,7, values));
    }
    
}
