package abstractfactory;

import java.util.logging.Logger;

public class YChair implements Chair  {
    
    public YChair() {
        
        Logger log = Logger.getLogger(YChair.class.getName());
        log.info("This is an Y Company's chair");
    }
    
   
    public void sit() {
        
        Logger log = Logger.getLogger(YChair.class.getName());
        
        log.info("You are sitting  on the Y Chair");
    }

}
