package abstractfactory;

//Concrete factory class
public class CompanyXFurniture extends FurnitureFactory {

    public Chair createChair() { 
        
        return new XChair();
    }
    
    public Table createTable() {
        
        return new XTable();
    }
    
}
