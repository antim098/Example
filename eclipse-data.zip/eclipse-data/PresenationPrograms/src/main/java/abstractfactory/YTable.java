package abstractfactory;

import java.util.logging.Logger;

public class YTable implements Table{
    
    public YTable() {
        
        Logger log = Logger.getLogger(YTable.class.getName());
        log.info("This is an Y Company's table");
    }

  
    public void work() {
        
        Logger log = Logger.getLogger(YTable.class.getName());
        
        log.info("You are working on the Y Table");
    }
}
