package abstractfactory;

public interface Table {
    
    public void work();
}
