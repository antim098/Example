package abstractfactory;

import java.util.Scanner;
import java.util.logging.Logger;

public class Test {

    public static void main(String[] args) {
        
        Logger log = Logger.getLogger(Test.class.getName());
      
         //Abstract factory reference
         FurnitureFactory furniture ;
         
         //Abstract products reference
         Chair chair;
         Table table;
         
         //Choice
         String choice;
         
         //Taking input
         Scanner input = new Scanner(System.in);
         
         log.info("Enter your choice of furniture (X or Y )");
         choice = input.next();
         
         // Based on the choice return the concrete factory's object
         if(choice == "X") {
             
             furniture = new CompanyXFurniture();
         }else
             
             furniture = new CompanyYFurniture();
         
         
         chair = furniture.createChair();
         table = furniture.createTable();
         
         //Methods of the products
         chair.sit();
         table.work();

    }

}
