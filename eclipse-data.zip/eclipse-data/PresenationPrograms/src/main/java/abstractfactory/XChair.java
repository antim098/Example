package abstractfactory;

import java.util.logging.Logger;

public class XChair implements Chair {

    public  XChair() {
        
        Logger log = Logger.getLogger(XChair.class.getName());
        
        log.info("This is an X Company's chair");
        
    }
    

    
    public void sit() {
        
        Logger log = Logger.getLogger(XChair.class.getName());
        
        log.info("You are sitting  on the X Chair");
    }
}

