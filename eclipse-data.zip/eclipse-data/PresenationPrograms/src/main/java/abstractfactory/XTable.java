package abstractfactory;

import java.util.logging.Logger;

public class XTable implements Table {

    public XTable() {
        
        Logger log = Logger.getLogger(XTable.class.getName());
        log.info("This is an X Copmany's table");
    }
    
    public void work() {
        
        Logger log = Logger.getLogger(XTable.class.getName());
        
        log.info("You are working on the X Table");
    }
}
