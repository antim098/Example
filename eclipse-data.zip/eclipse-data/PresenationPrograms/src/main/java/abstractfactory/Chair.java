package abstractfactory;

public interface Chair {
    
     void sit();

}
