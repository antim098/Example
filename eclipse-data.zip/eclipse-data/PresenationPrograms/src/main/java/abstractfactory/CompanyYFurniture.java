package abstractfactory;

// Concrete factory class
public class CompanyYFurniture extends FurnitureFactory {
    
    public Chair createChair() { 
        
        return new YChair();
    }
    
    public Table createTable() {
        
        return new YTable();
    }

}

