package factory1;

public class InstitutionalPlan extends Plan
{

    @Override
    void getRate()
    {
        rate=5.50;             
        
    }

}
