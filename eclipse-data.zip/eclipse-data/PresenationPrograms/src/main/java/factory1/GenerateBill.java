package factory1;

import java.io.IOException;
import java.util.Scanner;

public class GenerateBill
{
    static Scanner input = new Scanner(System.in);

    public static void main(String args[])
    {

        System.out.print("Enter the name of plan for which the bill will be generated: ");
        String planName = input.next();
        System.out.print("Enter the number of units for bill will be calculated: ");
        int units = input.nextInt();

        Plan p = GetPlanFactory.getPlan(planName);
        // call getRate() method and calculateBill()method of DomesticPaln.

        System.out.print("Bill amount for " + planName + " of  " + units + " units is: ");
        p.getRate();
        p.calculateBill(units);
    }
}
