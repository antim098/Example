package Factory_Extended;

public class SecureFactory
{

    public Connection createConnection(String type)
    {
        if (type.equals("Oracle")) {
            return new SecureOracleConnection();
        } else

        {
            return new SecureSqlServerConnection();

        }

    }
}
