package Builder.computer;

import java.util.HashMap;

public class ComputerRegistry {
    
    private static HashMap<String,Computer> storeMap = new HashMap<String, Computer>();
    
    public Computer getObject(String key) throws CloneNotSupportedException {
        Computer computerObject = storeMap.get(key);
        return (computerObject.clone());
    }
    
    public static void loadObjects() {
        PC pc = new PC();
        storeMap.put("Personal Computer",pc);
        
        Laptop lp = new Laptop();
        storeMap.put("Laptop", lp);
    }
    
    public void addObjects(String key, Computer value) {
        storeMap.put(key, value);
    }
    

}
