package Builder.computer;

public class Laptop extends Computer {

    private int ram;
    private String processor;
    
    Laptop(){
        ram = 8;
        processor = "Laptop Possess : Intel i7 ";
    }
    
    
    @Override
    public String getProcessor() {
        return processor;
    }

    @Override
    public int getRam() {
        return ram;
    }
    
    public void setRam(int ram) {
        this.ram = ram;
    }
    
    public void setProcessor(String processor) {
        this.processor = processor;
    }
    
    @Override
    public void display() {
        System.out.println(processor+ " core processor");
        System.out.println(ram + "GB of RAM ");
    }
}
