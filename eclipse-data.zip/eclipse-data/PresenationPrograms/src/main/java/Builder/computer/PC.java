package Builder.computer;

public class PC extends Computer {

    private int ram;
    private String processor ;
    
    
    PC(){
        ram = 4;
        processor = "Personal Computer Possess : Intel i5 ";
    }
    
    
    @Override
    public String getProcessor() {
        return processor;
    }

    @Override
    public int getRam() {
        return ram;
    }
    
    public void setRam(int ram) {
        this.ram = ram;
    }
    
    public void setProcessor(String processor) {
        this.processor = processor;
    }
    
    @Override
    public void display() {
       System.out.println(processor+ " core processor");
        System.out.println(ram + "GB of RAM ");
    }
}
