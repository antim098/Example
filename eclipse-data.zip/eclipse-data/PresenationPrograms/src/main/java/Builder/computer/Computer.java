package Builder.computer;

public abstract class Computer implements Cloneable
{

    public abstract String getProcessor();

    public abstract int getRam();

    public abstract void setRam(int ram);

    public abstract void setProcessor(String processor);

    public abstract void display();

    @Override
    protected Computer clone() throws CloneNotSupportedException
    {

        return (Computer) super.clone();
    }

}
