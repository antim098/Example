package Builder.computer;

public class ConstructComputer {

    public static void main(String[] args) throws CloneNotSupportedException {
        ComputerRegistry cr = new ComputerRegistry();
        cr.loadObjects();

        Computer newPC = cr.getObject("Personal Computer");
        newPC.display();
        newPC.setRam(50);   // Modify the object 
        newPC.display();
        

        Computer newLP = cr.getObject("Laptop");
        newLP.display();

    }

}
