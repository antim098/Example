package Builder.buildernew;

public class ComputerBuilder {
	//required parameters
		private String HDD;
		private int RAM;
		
		//optional parameters
		private boolean isGraphicsCardEnabled;
		private boolean isBluetoothEnabled;
		private boolean isWifiEnabled;
		
		public ComputerBuilder(String HDD, int RAM) {
			this.HDD = HDD;
			this.RAM = RAM;
		}
		
		public ComputerBuilder setGraphicsCardEnabled(boolean isGraphicsCardEnabled) {
			this.isGraphicsCardEnabled = isGraphicsCardEnabled;
			return this;
		}
		public ComputerBuilder setBluetoothEnabled(boolean isBluetoothEnabled) {
			this.isBluetoothEnabled = isBluetoothEnabled;
			return this;
		}
		public ComputerBuilder setWifiEnabled(boolean isWifiEnabled) {
			this.isWifiEnabled = isWifiEnabled;
			return this;
		}
		
		public Computer build() {
			return new Computer(HDD,RAM,isGraphicsCardEnabled,isBluetoothEnabled,isWifiEnabled);
		}
		public String toString() {
			return "Computer [HDD=" + HDD + ", RAM=" + RAM + ", isGraphicsCardEnabled=" + isGraphicsCardEnabled
					+ ", isBluetoothEnabled=" + isBluetoothEnabled + ", isWifiEnabled=" + isWifiEnabled +"]";
		}
}
