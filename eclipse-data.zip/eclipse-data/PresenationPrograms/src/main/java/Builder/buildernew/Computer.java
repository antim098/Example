package Builder.buildernew;

public class Computer {
	
	//required parameters
	private String HDD;
	private int RAM;
	
	//optional parameters
	private boolean isGraphicsCardEnabled;
	private boolean isBluetoothEnabled;
	private boolean isWifiEnabled;
	
	public Computer(String HDD, int RAM,boolean isGraphicsCardEnabled, boolean isBluetoothEnabled,boolean isWifiEnabled) {
		this.HDD = HDD;
		this.RAM = RAM;
		this.isGraphicsCardEnabled=isGraphicsCardEnabled;
		this.isBluetoothEnabled = isBluetoothEnabled;
		this.isWifiEnabled = isWifiEnabled;
	}
	
	@Override
	public String toString() {
		return "Computer [HDD=" + HDD + ", RAM=" + RAM + ", isGraphicsCardEnabled=" + isGraphicsCardEnabled
				+ ", isBluetoothEnabled=" + isBluetoothEnabled + ", isWifiEnabled=" + isWifiEnabled +"]";
	}
}