package Builder.buildernew;



public class TestBuilderPattern {
	public static void main(String[] args) {
	/*	Computer comp = new Computer.ComputerBuilder(
				"500 GB", "2 GB").setBluetoothEnabled(true)
				.setGraphicsCardEnabled(true).build();
		System.out.println(comp);
	*/	
		ComputerBuilder cb = new ComputerBuilder("Hard Core Intel i7", 5).setBluetoothEnabled(true).setGraphicsCardEnabled(true);
		System.out.println(cb);
}
}