package Builder.staticbuilder;


public class TestBuilderPattern {
   
    public static void main(String[] args) {
        // Using builder to get the object in a single line of code and
        // without any inconsistent state or arguments management issues

        Computer computerWithBluetooth = new Computer.ComputerBuilder("500 GB", "2 GB").setBluetoothEnabled(true).setGraphicsCardEnabled(true).build();
        System.out.println(computerWithBluetooth);
        
        Computer computerWithoutBluetooth = new Computer.ComputerBuilder("50 GB", "1 GB").setBluetoothEnabled(false).setGraphicsCardEnabled(true).build();
        System.out.println(computerWithoutBluetooth);
    }

}
