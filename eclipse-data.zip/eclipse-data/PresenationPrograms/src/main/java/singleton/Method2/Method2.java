package singleton.Method2;

public class Method2
{

    public static void main(String[] args)
    {
        
        Thread t1 = new Thread(new Runnable()
        {
            
            public void run()
            {
                Singleton obj = Singleton.getInstance();
                System.out.println(obj);                
            }
        });
        
        Thread t2 = new Thread(new Runnable()
        {
            
            public void run()
            {
                Singleton newObj = Singleton.getInstance();
                System.out.println(newObj);              
            }
        });
      t1.start();
      t2.start();
        
    }
    
}

class Singleton
{
    private static Singleton obj;
 
    private Singleton() {}
 
    // Only one thread can execute this at a time
    public static synchronized Singleton getInstance()
    {
        if (obj==null)
            obj = new Singleton();
        return obj;
    }
}

