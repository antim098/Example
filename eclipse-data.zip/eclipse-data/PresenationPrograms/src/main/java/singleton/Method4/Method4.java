package singleton.Method4;


public class Method4
{

    public static void main(String[] args)
    {

        Thread t1 = new Thread(new Runnable()
        {

            public void run()
            {
                Singleton obj = Singleton.getInstance();
                System.out.println(obj);
            }
        });

        Thread t2 = new Thread(new Runnable()
        {

            public void run()
            {
                Singleton newObj = Singleton.getInstance();
                System.out.println(newObj);
            }
        });
        t1.start();
        t2.start();

    }

}

class Singleton
{
    private volatile static Singleton obj;
    
    private Singleton() {}
 
    public static Singleton getInstance()
    {
        if (obj == null)
        {
            // To make thread safe
            synchronized (Singleton.class)
            {
                // check again as multiple threads
                // can reach above step
                if (obj==null)
                    obj = new Singleton();
            }
        }
        return obj;
    }
}

