package singleton.Method3;

public class Method3
{

    public static void main(String[] args)
    {

        Thread t1 = new Thread(new Runnable()
        {

            public void run()
            {
                Singleton obj = Singleton.getInstance();
                System.out.println(obj);
            }
        });

        Thread t2 = new Thread(new Runnable()
        {

            public void run()
            {
                Singleton newObj = Singleton.getInstance();
                System.out.println(newObj);
            }
        });
        t1.start();
        t2.start();

    }

}

class Singleton
{
    private static Singleton obj = new Singleton();

    private Singleton()
    {
    }

    public static Singleton getInstance()
    {
        return obj;
    }
}
