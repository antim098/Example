package antim.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import org.apache.log4j.Logger;
/**
 * Hello world!
 *
 */
public class App 
{
  
    final static Logger logger = LoggerFactory.getLogger(App.class);
    
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        logger.debug("Antim Kant Verma");
       
     
    }
}
