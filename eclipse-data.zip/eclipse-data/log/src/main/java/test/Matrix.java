package test;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import java.util.Scanner;

public class Matrix {

    static Logger log = LoggerFactory.getLogger(Matrix.class);

    static void findInMatrix(String[][] strArr, String search) {
        int num = 0;
        int count = 0;
        int rows =0;
        int start=0;
        int end=2;
        while(end<4)
        for (int i = 0; i < 3; i++) {
            for (int j= start; j < end; j++) {
                for (int k = 0; k < search.length(); k++) {
                    if ((strArr[i][j]).equals( String.valueOf((search.charAt(k))))) {
                        log.info("inside if");
                        num++;
                        if(num==4) {
                            log.info("Found Magic Square");
                            log.info((i-1) + "-" + (j-1)); 
                            System.exit(0);
                            }
                        break;
                    } else {
                        count++;
                    }
                }
                if (count == 5) {
                  break;
                }
            }
        }
        
        start=+1;
        end=+1;
    }

 

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String[][] strArr = new String[3][4];
        log.info("Enter elements");
        String search = "cdkr";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                strArr[i][j] = input.next();
            }
        }

        findInMatrix(strArr, search);
 log.info("hello");
    }

}
