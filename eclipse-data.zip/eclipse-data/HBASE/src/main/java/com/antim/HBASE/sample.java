package com.antim.HBASE;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;

public class sample {

    static Configuration c;

    static void connect() {
        c = HBaseConfiguration.create(); // Instantiate configuration class
        c.addResource(new Path("/home/impadmin/eclipse-workspace/HBASE/src/main/resources/hbase-site.xml"));
    }

    public static void main(String[] args) throws IOException {
        connect();
        Connection connection = ConnectionFactory.createConnection(c);
        Admin admin = connection.getAdmin();

        TableName table1 = TableName.valueOf("guru99");
        Table table = null;
        if (admin.tableExists(table1)) {
            System.out.println("Table Existss");
            table = connection.getTable(table1);
        }
        // HTable table = new HTable(c, "guru99");
        Get g = new Get(Bytes.toBytes("1"));
        Result r = table.get(g);
        byte[] value = r.getValue(Bytes.toBytes("data"), Bytes.toBytes("name"));
        byte[] value1 = r.getValue(Bytes.toBytes("data"), Bytes.toBytes("city"));
        String name = Bytes.toString(value);
        String city = Bytes.toString(value1);
        System.out.println(name);
        System.out.println(city);
    }

}
