package com.antim.HBASE;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;


public class App {

   // public static Logger log = org.slf4j.LoggerFactory.getLogger(App.class);

    public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException {
        Configuration c = HBaseConfiguration.create(); // Instantiate configuration class
        c.addResource(new Path("/home/impadmin/eclipse-workspace/HBASE/src/main/resources/hbase-site.xml"));
        Connection connection = ConnectionFactory.createConnection(c);
        Admin admin = connection.getAdmin();
        // get already created table
        TableName table1 = TableName.valueOf("guru99");
        Table table = null;
        table = connection.getTable(table1);
        table.close();

        // Reading data from existing table
        Get g = new Get(Bytes.toBytes("1"));
        Result r = table.get(g);
        System.out.println("After result");
        byte[] value = r.getValue(Bytes.toBytes("data"), Bytes.toBytes("name"));
        byte[] value1 = r.getValue(Bytes.toBytes("data"), Bytes.toBytes("city"));
        String name = Bytes.toString(value);
        String city = Bytes.toString(value1);
        System.out.println("name is " + name);
        System.out.println("city is " + city);

        // Adding new row in the table
        Put p = new Put(Bytes.toBytes("2"));
        p.addColumn(Bytes.toBytes("data"), Bytes.toBytes("name"), Bytes.toBytes("Ravi"));
        table.put(p);
        System.out.println("Added values ");

        // creating new table
        HTableDescriptor ht = new HTableDescriptor(TableName.valueOf("antim"));
        ht.addFamily(new HColumnDescriptor("data"));
        if (!admin.tableExists(ht.getTableName())) {
            admin.createTable(ht);
            table.close();
        } else {
            System.out.println("table " + ht.getTableName() + " already exists");
        }

        // Adding a new column family
        HColumnDescriptor hd = new HColumnDescriptor(Bytes.toBytes("info"));
        admin.addColumn(table1, hd);

        // Deleting data
        Delete delete = new Delete(Bytes.toBytes("2"));
        delete.deleteColumn(Bytes.toBytes("data"), Bytes.toBytes("name"));
        delete.deleteFamily(Bytes.toBytes("data"));
        table.delete(delete);

    }
}
