package Dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import Entity.Student;


@Repository
public class StudentDao {

    private static Map<Integer, Student> students;

    static {
        students = new HashMap<Integer, Student>() {
            {

                put(1,new Student(1,"A","CS"));
                put(2,new Student(2,"B","IT"));
                put(1, new Student(2, "C", "EC"));
            
            }
        };

    }
   
    
    public Collection<Student> getAllSudents(){
        return this.students.values();
      
    }
    
    
    public Student getStudentDetail(int id){
        return this.students.get(id);
    }
    
}
