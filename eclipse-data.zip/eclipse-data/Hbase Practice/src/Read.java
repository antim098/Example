import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

public class Read {
    public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException {
        Configuration c = HBaseConfiguration.create(); // Instantiate configuration class
        HTable table = new HTable(c, "guru99");
        // HTableDescriptor tdescriptor = new HTableDescriptor(TableName.valueOf("name"));
        Get g = new Get(Bytes.toBytes("1"));
        Result r = table.get(g);
        byte[] value = r.getValue(Bytes.toBytes("data"), Bytes.toBytes("name"));
        byte[] value1 = r.getValue(Bytes.toBytes("data"), Bytes.toBytes("city"));
        String name = Bytes.toString(value);
        String city = Bytes.toString(value1);
        System.out.println(name);
        System.out.println(city);
    }
}
