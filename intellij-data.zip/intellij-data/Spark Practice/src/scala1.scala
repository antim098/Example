class scala1 {

}
