package CaseStudy

object SparkSql2 {


  def main(args: Array[String]) = {


    val spark = org.apache.spark.sql.SparkSession.builder
      .master("local")
      .appName("Spark CSV Reader")
      .getOrCreate

    import org.apache.spark.sql.functions._

    //Reading CSV files into respective Dataframes
    val problems = spark.read.format("csv").option("header", "true").load("/home/impadmin/Downloads/spark-inputdata/Spark-SQL-911.csv")
    val state_info = spark.read.format("csv").option("header", "true").load("/home/impadmin/Downloads/spark-inputdata/Spark-SQL-zipcode.csv")

    //Splitting column value of title and creating new column named type
    val type_problems = problems.withColumn("type", split(col("title"), "\\:").getItem(0))

    //Registering temporary tables for the dataframes
    type_problems.createOrReplaceTempView("type_problems")
    state_info.createOrReplaceTempView("state_info")

    //Statewise type of problems and their count
    val statewiseProblems = spark.sql("SELECT CONCAT(i.state, ':', p.type) as state_type,count(*) as count from type_problems p join state_info i on p.zip=i.zip group by state_type order by count desc")

    statewiseProblems.show()
    val citywiseProblems = spark.sql("SELECT CONCAT(i.city, ':', p.type) as city_type,count(*) as count from type_problems p join state_info i on p.zip=i.zip group by city_type order by count desc")
    citywiseProblems.show()
  }


}

