package CaseStudy

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.{col, split}

object SparkSql1 {


  def main(args: Array[String]) = {


    val spark = org.apache.spark.sql.SparkSession.builder
      .master("local")
      .appName("Spark CSV Reader")
      .getOrCreate

    val DF = spark.read.format("csv").option("header", "true").load("/home/impadmin/Downloads/spark-inputdata/Spark-SQL-inpatientCharges.csv")

    DF.createOrReplaceTempView("inpatientcharges")

    spark.sql("select * from inpatientcharges").show(150)

    val stateAvgCharges = spark.sql("select ProviderState,round(avg(AverageCoveredCharges),2) as AverageStateCoveredCharges from inpatientcharges group by ProviderState")

    stateAvgCharges.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv("/home/impadmin/result/stateAvgCharges")

    val stateAvgTotalPayments = spark.sql("select ProviderState,round(avg(AverageTotalPayments),2) as AverageStateTotalPayments from inpatientcharges group by ProviderState")

    stateAvgTotalPayments.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv("/home/impadmin/result/stateAvgTotalPayments")

    val avgMedicare = spark.sql("select ProviderState,round(avg(AverageMedicarePayments),2) as AverageMedicarePayments from inpatientcharges group by ProviderState")

    avgMedicare.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv("/home/impadmin/result/avgMedicarePayments")


    val StatewithDisease = DF.withColumn("disease", split(col("DRGDefinition"), "\\-").getItem(1))
    StatewithDisease.createOrReplaceTempView("StatewithDisease")

    val DischargePerState = spark.sql("SELECT CONCAT(ProviderState, ':',disease) as state_disease,sum(TotalDischarges) as Total_State_Discharges from StatewithDisease group by state_disease order by " +
      "Total_State_Discharges desc")

    DischargePerState.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv("/home/impadmin/result/dischargePerState")

  }

}
