package main.scala

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._


object SparkKafkaStream {


  def main(args: Array[String]) = {

    val spark = SparkSession.builder().appName("Kafka Integration").master("local[*]").getOrCreate()


    import org.apache.spark.sql.functions._
    import spark.implicits._
    val jsonSchema = StructType(
      Array(
        StructField("dcid", IntegerType, true),
        StructField("userid", StringType, true),
        StructField("Time", StringType, true)
      ))
    // val schema = Encoders.product[CdrData].schema

    val streamingDataFrame = spark.readStream.schema(jsonSchema).json("/home/impadmin/sample")

    // val streamingDataFrame = spark.read.json("input.json")s
    streamingDataFrame.printSchema()

    val columnName = "Time"

    // val updatedDF = streamingDataFrame.withColumn(columnName, unix_timestamp(col(columnName), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").cast(TimestampType))

    val updatedDF = streamingDataFrame.withColumn(columnName, to_timestamp($"Time"))
    updatedDF.printSchema()
    //  streamingDataFrame.createOrReplaceTempView("people")
    //  spark.sql("select * from people").show()

    //  streamingDataFrame.writeStream.format("console").option("truncate", "false").start().awaitTermination()

    streamingDataFrame.selectExpr("to_json(struct(*)) AS value").writeStream.format("kafka").option("topic", "antim")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("checkpointLocation", "/home/impadmin/logs") //.trigger(Trigger.ProcessingTime(60, TimeUnit.SECONDS))
      .start()

    val outStream = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "antim").option("checkpointLocation", "/home/impadmin/logs").load()

    outStream.printSchema()
    //outStream.select("value").show()
    //outStream.select("value").show()
    /* val df1 = outStream.selectExpr("CAST(value AS STRING)", "CAST(timestamp AS TIMESTAMP)").as[(String, Timestamp)]
       .select(from_json($"value", jsonSchema).as("data"), $"timestamp").select("data.*", "timestamp")*/
    val df1 = outStream.selectExpr("CAST(value AS STRING)").as[(String)].select(from_json($"value", jsonSchema).as("data")).select("data.*")

    df1.printSchema()
    //   .selectExpr("CAST(Time AS TIMESTAMP)").as[(Timestamp)]
    // df1.select("userid").distinct().count()
    // df1.createOrReplaceTempView("dataframe")

    // spark.sqlContext.sql("select count(distinct(userid)) from dataframe as uniqueUsers").show()
    /*val t = df1.select(to_timestamp($"Time")).writeStream.format("console").start().awaitTermination()*/


    val uniqueUsers = df1.select($"userid", to_timestamp($"Time").as("Time")).withWatermark("Time", "10 seconds")
      .groupBy(window($"Time", "60 seconds").alias("Duration"))
      .agg(approx_count_distinct("userid").alias("Distinct Users"))
      .select("Duration", "Distinct Users").writeStream.format("console")
      .format("json").option("path", "/home/impadmin/result/uniqueUsers").option("checkpointLocation", "/home/impadmin/ckp1") /*outputMode("update").option("truncate", "false") .start()*/


    val deploymentCenters = df1.select($"dcid", $"userid", to_timestamp($"Time").as("Time"))
      .withWatermark("Time", "10 seconds")
      .groupBy((window($"Time", "60 seconds").alias("Duration")), $"dcid")
      .count().select("dcid", "Duration")
      .filter($"count" >= 2).writeStream.format("json").format("console")
      .option("path", "/home/impadmin/result/deploymentCenters").option("checkpointLocation", "/home/impadmin/ckp2") /*.option("truncate", "false")*/ .outputMode("update").start().awaitTermination()

  }
}

