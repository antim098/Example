package main.scala.SparkStream

import java.time.format.DateTimeFormatter
import java.time.{Instant, ZoneId}

import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.streaming._
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, KafkaUtils, LocationStrategies}

object CreateKafkaStream {


  def main(args: Array[String]): Unit = {


    val sparkConf = new SparkConf().setAppName("test").setMaster("local[*]")

    val ssc = new StreamingContext(sparkConf, Seconds(60))

    val sql = new HiveContext(ssc.sparkContext)

    ssc.sparkContext.setLogLevel("ERROR")
    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> "localhost:9092",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "A",
      "enable.auto.commit" -> (false: java.lang.Boolean))


    val topics = Array("antim")

    val stream = KafkaUtils.createDirectStream[String, String](
      ssc,
      LocationStrategies.PreferConsistent, ConsumerStrategies.Subscribe[String, String](topics, kafkaParams))

    stream.foreachRDD((rdd, time) => {
      val StringRdd = rdd.map(x => x.value())
      //  val batchTime = s"${returnFormattedTime(time.milliseconds)}"
      if (!StringRdd.isEmpty()) {
        val result = sql.read.json(StringRdd)
        var df = result.toDF()
        df.show(false)
        print("Time of Batch is " + s"${returnFormattedTime(time.milliseconds)}")
        df.coalesce(1).select("userid").distinct().as("Distinct").selectExpr("count(Distinct.userid)").write.mode(SaveMode.Append).csv("/home/impadmin/result/SparkStreaming Results/uniqueUsers/" + s"${returnFormattedTime(time.milliseconds)}")
        df.coalesce(1).select("dcid").groupBy("dcid").count().select("dcid").filter("count>=250").write.mode(SaveMode.Append).csv("/home/impadmin/result/SparkStreaming Results/deploymentCenters/" + s"${returnFormattedTime(time.milliseconds)}")
        print("Written to file")
      }
      else {
        StringRdd.saveAsTextFile("/home/impadmin/result/SparkStreaming Results/uniqueUsers/" + s"${returnFormattedTime(time.milliseconds)}")
        StringRdd.saveAsTextFile("/home/impadmin/result/SparkStreaming Results/deploymentCenters/" + s"${returnFormattedTime(time.milliseconds)}")
        print("written empty file")
      }
    }
    )
    ssc.start()
    ssc.awaitTermination()
  }

  def returnFormattedTime(ts: Long): String = {
    val date = Instant.ofEpochMilli(ts)
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault())
    val formattedDate = formatter.format(date)
    formattedDate
  }

}
