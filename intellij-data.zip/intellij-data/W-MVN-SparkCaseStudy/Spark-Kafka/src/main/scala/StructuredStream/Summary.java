package main.scala.StructuredStream;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Summary {


    public static void main(String[] args) throws IOException {
        String directoryPath = "/home/impadmin/result/Structured Streaming results/";
        String[] directories = new File(directoryPath).list();
        List dirNames = Arrays.asList(directories);
        Iterator itr = dirNames.iterator();
        Path path = Paths.get("/home/impadmin/result/Structured Streaming results/Summary.txt");
        FileWriter writer = new FileWriter(path.toFile());
        writer.flush();
        //writer.append("Timestamp" + "\t\t" + "DCID");
        StringBuilder fileContent = new StringBuilder();
        while (itr.hasNext()) {
            String timeStamp = itr.next().toString();
            Path inputDir = Paths.get(directoryPath + timeStamp);

            File dir = new File(String.valueOf(inputDir));
            if (Files.isDirectory(inputDir)) {
                List<String> fileNames;

                String[] names = dir.list((dir1, name) -> name.endsWith(".csv"));
                fileNames = Arrays.asList(names);
                System.out.println(fileNames.size());
                for (String fileName : fileNames) {
                    System.out.println("//////" + fileName);
                    try (FileReader fileReader = new FileReader(inputDir + "/" + fileName); BufferedReader bufferedReader = new BufferedReader(fileReader)) {
                        String line = null;
                        while ((line = bufferedReader.readLine()) != null) {
                            fileContent.append(" " + line);
                        }
                    } catch (FileNotFoundException ex) {
                        // log.error("Unable to open file {} \n Path Wrong or File Dosen't Exists", filePath);
                    } catch (IOException e) {
                        //  log.error("Error reading file {}", filePath);
                        // Or we could just do this:

                    }

                }
                String output = timeStamp + "\n" + fileContent.toString();
                writer.append("\n" + output);
                System.out.println(output);

            }
            fileContent.setLength(0);
        }
        writer.close();
    }
}
