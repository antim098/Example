package main.scala.StructuredStream

import java.sql.Timestamp

import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object Devices {
  def main(args: Array[String]) = {

    val spark = SparkSession.builder().appName("Kafka Integration").master("local[*]").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val jsonSchema = StructType(
      Array(
        StructField("phoneNo", StringType, true),
        StructField("bytesIn", LongType, true),
        StructField("bytesOut", LongType, true),
        StructField("eventTime", StringType, true)
      ))


    val streamingDataFrame = spark.readStream.schema(jsonSchema).json("/home/impadmin/devices")

    streamingDataFrame.selectExpr("to_json(struct(*)) AS value").writeStream.format("kafka").option("topic", "devices")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("checkpointLocation", "/home/impadmin/deviceckp")
      .start()


    val outStream = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "devices").option("checkpointLocation", "/home/impadmin/deviceckp1").load();


    import org.apache.spark.sql.functions._
    import spark.implicits._

    val df1 = outStream.selectExpr("CAST(value AS STRING)", "CAST(timestamp AS TIMESTAMP)").as[(String, Timestamp)]
      .select(from_json($"value", jsonSchema).as("data"), $"timestamp").select("data.*", "timestamp")

    df1.printSchema()

    val reqDF = df1.select($"phoneNo", $"bytesIn", $"bytesOut", ($"timestamp").as("eventTime")).withColumn("Total bytes", col("bytesIn") + col("bytesOut")).withWatermark("eventTime", "60 minutes")
      .groupBy(window($"eventTime", "1 minute"), $"Total bytes", $"phoneNo").count()
      .select("window", "Total bytes", "phoneNo")

    val query = reqDF.writeStream.trigger(Trigger.ProcessingTime("1 minute")).foreachBatch {
      (batchDF: DataFrame, batchId: Long) =>
        val resDF = batchDF.orderBy(col("Total bytes").desc).select("window", "Total bytes", "phoneNo").limit(10)
        //  resDF.show(false)
        resDF.coalesce(1).write.format("json").save("/home/impadmin/result/Structured/" + batchId.toString())
    }.start()

    query.awaitTermination()





    //outputMode(OutputMode.Complete).format("console").option("truncate", "false").option("path", "/home/impadmin/result").option("checkpointLocation", "/home/impadmin/deviceckp1").trigger(Trigger.ProcessingTime("1 minute")).start().awaitTermination()

    /*reqDF.writeStream
      .outputMode("complete")
      .foreach()
      .start().awaitTermination()
*/
    /*    reqDF.selectExpr("to_json(struct(*)) AS value")
          .writeStream.format("kafka")
          .outputMode(OutputMode.Complete)
          .option("kafka.bootstrap.servers", "localhost:9092")
          .option("topic", "result").option("checkpointLocation", "/home/impadmin/deviceckp1").trigger(Trigger.ProcessingTime("1 minute")).start().awaitTermination()*/
  }
}
