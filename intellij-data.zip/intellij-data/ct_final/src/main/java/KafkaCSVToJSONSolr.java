import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

import com.google.gson.JsonArray;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.google.common.base.Strings;
import com.google.gson.JsonObject;

public class KafkaCSVToJSONSolr {


	private static String schema = "TRANSACTIONTYPE,ISCORRELATED,MOBILENUMBER,SERVERIP,SERVERPORT,CLIENTIP,PROTOCOL,APPLICATION,DOMAIN,SRCMAC,DSTMAC,TRANSACTIONSTARTTIME,TRANSACTIONENDTIME,LOCATIONINFO,BTS,APN,VID,REQUESTTYPE,FILTERID,IFID,DURATION,CALLSTARTTIME,CALLENDTIME,USERAGENT,CERTIFICATEISSUER,CERTIFICATEISSUEDTO,OIME,OIMS,LATITUDE,LONGITUDE,EVENTTYPE,FROM,TO,EMAIL,EMAILHEADER,SUBJECT,ATTACHMENTTYPE,CODECLIST,REFFERALURL,URL,CONTENTTYPE,NAME,ADDRESS,CITY,COUNTRY,STATE,SKILLS,GENDER,MARITALSTATUS,CHATROOMID,USERNAME,PASSWORD,DOCUMENTID,DOCUMENTINGESTTIME";

	private static final String DELIMITER=",";

	String base_file_path = "C:\\Users\\rajesh.c.paul\\Documents\\Projects\\ClearTrail\\sample input\\dir\\aaa\\";
	String file_path = "C:\\Users\\rajesh.c.paul\\Documents\\Projects\\ClearTrail\\sample input\\dir\\aaa\\";

	public static void main(String[] args) throws IOException {
		/*
		 * ************* Command line params for this script: **************
		 * 1st - Input data file format - CSV/JSON
		 * 2nd - Bootstrap server and port details
		 * 3rd - Directory path containing all input data files
		 * 4th - Kafka topic name
		 * *****************************************************************
		 */

		String file_format = args[0];
		//String bootstrap_servers = args[1];
		String base_file_path = args[1];
		String file_path = args[2];
		//String topic_name = args[3];

		KafkaProducer<String, String> producer = null;

//		Properties properties = new Properties();
//		properties.setProperty("bootstrap.servers", bootstrap_servers);
//		properties.setProperty("auto.offset.reset", "latest");
//		properties.setProperty("timeout.ms", "30000000");
//		properties.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
//		properties.setProperty("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		if (args.length == 3) {
			// Input data files are in CSV format
			if (file_format == "CSV") {
				file_path = file_path.trim();
				File[] files = new File(file_path).listFiles();
				System.out.println("***** No. of input data files (including directories) *****: " + files.length);

				BufferedReader br = null;

				if (files.length <= 0) {
					System.out.println("***** The input data files do not exist !!! ***** ");
					System.out.println("***** Script execution is complete ***** ");
					System.exit(0);
				}

				for (File file : files) {
					if (!file.isFile() || file.isDirectory()) {
						continue;
					} else {
						System.out.println("****** The input file name: " + file.getName());
						file_path = base_file_path.trim();
						file_path = file_path + '/' + file.getName();
						br = null;

						try {
							//producer = new KafkaProducer<>(properties);
							br = Files.newBufferedReader(Paths.get(file_path));
							String line = null;
							System.out.println("****** start time: " + System.currentTimeMillis());

							String[] schemaCols = schema.split(",");
							JsonArray array = new JsonArray();
							while ((line = br.readLine()) != null) {
								line = line.trim();

								// count number of DELIMITERs in input CSV record
								int delimiterCount = getDelimiterCount(line, DELIMITER.toCharArray());

								// convert CSV record into JSON
								JsonObject json = new JsonObject();
								String trim_value = null;
								String[] split_val = line.split(",");

								/**
								 * schema fields must be equal to fields in input record
								 * and (schema fields - 1) must be equal to number of delimiters in input record
								 * else reject the record
								 */
								if ((schemaCols.length != split_val.length) && (schemaCols.length - 1) != delimiterCount) {
									System.out.println("Total number of columns in the record does not match with number of schema columns!!!");
									// DocId is 2nd last column as per above defined schema
									System.out.println("Doc Id of skipped record: " +split_val[split_val.length-2]);
									continue;
								}

								System.out.println("Start json conversion ");
								// prepare JSON from CSV record
								for(int i=0; i<split_val.length; i++) {
									trim_value = split_val[i].trim();

									if (!(Strings.isNullOrEmpty(trim_value))) {
										json.addProperty(schemaCols[i], trim_value);
									}
								}
								array.add(json);
                              System.out.println("Converted JSON record: " +json.toString());
								//producer.send(new ProducerRecord<String, String>(topic_name, json.toString()));
							}
							System.out.println("****** end time: " + System.currentTimeMillis());
							System.out.println("---------------------------------------");
							System.out.println(array.toString());
						} catch (IOException e) {
							System.out.println(
									"****** Exception occurred in KafkaCSVToJSONSolr file while writing data to topic *******");
							e.printStackTrace();
						} finally {
							br.close();
							//producer.flush();
							//producer.close();
						}
					}
				}
			}
			// Input data files are in JSON format
			else {
				file_path = file_path.trim();
				File[] files = new File(file_path).listFiles();
				System.out.println("***** No. of input data files (including directories) *****: " + files.length);

				BufferedReader br = null;

				if (files.length <= 0) {
					System.out.println("***** The input data files do not exist!!! ***** ");
					System.out.println("***** Script execution is complete ***** ");
					System.exit(0);
				}

				for (File file : files) {
					if (!file.isFile() || file.isDirectory()) {
						continue;
					} else {
						System.out.println("****** The input file name: " + file.getName());
						//file_path = base_file_path.trim();
						file_path = file_path + '/' + file.getName();
						br = null;

						try {
						//	producer = new KafkaProducer<>(properties);
							br = Files.newBufferedReader(Paths.get(file_path));
							String line = null;
							System.out.println("****** start time: " + System.currentTimeMillis());

							while ((line = br.readLine()) != null) {
								line = line.replace("[{", "{");
								line = line.replace("},", "}");
								line = line.replace("}]", "}");
								line = line.trim();
//                                              System.out.println("JSON: " +line);
								//producer.send(new ProducerRecord<String, String>(topic_name, line));
							}
							System.out.println("****** end time: " + System.currentTimeMillis());
							System.out.println("---------------------------------------");
						} catch (IOException e) {
							System.out.println(
									"****** Exception occurred in KafkaCSVToJSONSolr file while writing data to topic *******");
							e.printStackTrace();
						} finally {
							br.close();
							//producer.flush();
							//producer.close();
						}
					}
				}
			}
			System.out.println("****** All input data files processed successfully ******");
		} else {
			System.out.println(
					"***** The entered input params are either incorrect or files do not exist at given path *****");
			return;
		}
	}


	public static int getDelimiterCount(String row, char[] c) {
		int count = 0;

		for (int i=0; i<row.length(); i++) {
			if (row.charAt(i) == c[0]) {
				count++;
			}
		}
		return count;
	}
}