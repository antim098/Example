import com.datastax.driver.core.*;

import java.io.*;
import java.nio.ByteBuffer;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Random;

import static java.lang.System.clearProperty;
import static java.lang.System.out;

public class Read {
    public static void main(String[] args) throws IOException {
        System.setProperty("com.datastax.driver.NATIVE_TRANSPORT_MAX_FRAME_SIZE_IN_MB", "2046");
        int batchSize = 5000;
        DecimalFormat df2 = new DecimalFormat("#.####");
        String query = args[0];
        //String filePath = args[1];
        if (args.length > 1) {
            batchSize = Integer.parseInt(args[1]);
        }

        final CassandraConnector client = new CassandraConnector();
        //final String ipAddress = "127.0.0.1"; //args.length > 0 ? args[0] :
        final int port = 9042;
        //out.printl7n("Connecting to IP Address " + ipAddress + ":" + port + "...");
        client.connect(port);
        //Session session = client.getSession();


        int RESULTS_PER_PAGE = batchSize;
        out.println("Batch Size is : " + batchSize);

        Statement st = new SimpleStatement(query);
        st.setFetchSize(RESULTS_PER_PAGE);
        // Note that we don't rely on RESULTS_PER_PAGE, since Cassandra might
        // have not respected it, or we might be at the end of the result set

        //BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true));
        long record_count = 0;
        out.println("Query :" + query);
        Timestamp start_time = new Timestamp(System.currentTimeMillis());
        ResultSet rs = null;
        out.println("Start Time :" + start_time);
        try {
            rs = client.getSession().execute(st);
            for (Row row : rs) {
                // Process the row ...
                record_count++;
            }
//            rs = session.execute(st);
//            while (!rs.isFullyFetched()) {
//                rs.fetchMoreResults();
        } catch (Exception e) {
            out.println("Exception occured");
            e.printStackTrace();
            System.exit(0);
        }

        //        for (Row row : rs) {
//            if (rs.getAvailableWithoutFetching() == 1000 && !rs.isFullyFetched())
//                rs.fetchMoreResults(); // this is asynchronous
//            // Process the row ...
//            record_count++;
//        }
        Timestamp end_time = new Timestamp(System.currentTimeMillis());
        //ByteBuffer data = rs.one().getBytes("data");
//        long size  = (data.array().length)/1048576;
//        out.println("Size of data column :"+ size + "  MB");
//        client.close();
        out.println("End Time :" + end_time);
//        record_count = rs.all().size();

        double time_taken = (end_time.getTime() - start_time.getTime());
        out.println("Time Taken:" + df2.format(time_taken / 1000));
        out.println("Records Read :" + record_count);
        System.exit(0);
    }

}
