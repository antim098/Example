import java.io.IOException;
import java.sql.Timestamp;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.CursorMarkParams;

public class SolrJSearcher {
    public static void main(String[] args) throws IOException, SolrServerException {
        SolrClient client = new HttpSolrClient.Builder("http://172.50.34.206:8983/solr/Seq_Collection").build();

//        SolrQuery query = new SolrQuery();
//        query.setQuery("sony digital camera");
//        query.addFilterQuery("cat:electronics","store:amazon.com");
//        query.setFields("id","price","merchant","cat","store");
//        query.setStart(0);
//        query.set("defType", "edismax");

//        SolrQuery query1 = new SolrQuery();
//        query1.set("q", "DOMAIN:inbox.google.com");
//        query1.set("rows", "10000");
//        QueryResponse response = client.query(query1);
//        long record_count = 0;
//        SolrDocumentList results = response.getResults();
//        for (SolrDocument doc : results) {
//            record_count++;
//        }
//
//        System.out.println("Records fetched =" + record_count);

        int limit = 50000;
        long record_count = 0;
        SolrQuery solrQuery = new SolrQuery();
        solrQuery.setRows(5000);
        solrQuery.set("_route_", "9765433781!");
        solrQuery.setQuery("MOBILENUMBER:9765433781");
        solrQuery.addSort("SEQ", SolrQuery.ORDER.asc);  // Pay attention to this line
        String cursorMark = CursorMarkParams.CURSOR_MARK_START;
        System.out.println("Query is" + solrQuery.toQueryString());
        boolean done = false;
        Timestamp start_time = new Timestamp(System.currentTimeMillis());
        System.out.println("Query Start Time" + start_time);
        while (!done) {
            solrQuery.set(CursorMarkParams.CURSOR_MARK_PARAM, cursorMark);
            QueryResponse rsp = client.query(solrQuery);
            String nextCursorMark = rsp.getNextCursorMark();
            for (SolrDocument d : rsp.getResults()) {
                record_count++;
            }
            if (cursorMark.equals(nextCursorMark)) {
                done = true;
            }
            cursorMark = nextCursorMark;
            System.out.println("Records fetched till now =" + record_count);
            if (record_count == limit) {
                break;
            }
        }
        Timestamp end_time = new Timestamp(System.currentTimeMillis());
        System.out.println("Query End Time" + start_time);
        System.out.println("Records fetched =" + record_count);

    }
}