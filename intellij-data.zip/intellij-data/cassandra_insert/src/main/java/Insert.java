import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Session;
import javafx.scene.chart.ScatterChart;

import javax.swing.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.lang.System.clearProperty;
import static java.lang.System.out;

public class Insert {
    public static void main(String[] args) throws IOException {
        long file_count = 0;
        String filePath = args[0];
        int iterations = Integer.parseInt(args[1]);
        String tableName = args[2];
        List<String> result = new ArrayList<>();
        DecimalFormat df2 = new DecimalFormat("#.####");
        String query = "insert into test."+tableName+"(id,data) values(?,?)";
        try (Stream<Path> walk = Files.walk(Paths.get(filePath))) {

            result = walk.filter(Files::isRegularFile)
                    .map(x -> x.toString()).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }

        byte[] fileData = new byte[filePath.length()];
        DataInputStream dis = new DataInputStream(new FileInputStream(filePath));
        dis.readFully(fileData);  // read from file into byte[] array
        dis.close();
        out.println(Arrays.toString(fileData));


//        FileInputStream fis = new FileInputStream(filePath);
//        byte[] b = new byte[fis.available() + 1];
//        int length = b.length;
//        fis.read(b);
//        out.println();

        //We now need to convert the byte array into a bytebuffer:
        ByteBuffer buffer = ByteBuffer.wrap(fileData);
        out.println();
        String sb = bytesToHex(fileData);
        out.println(sb);

//        final CassandraConnector client = new CassandraConnector();
//        final String ipAddress = "127.0.0.1"; //args.length > 0 ? args[0] :
//        final int port = 9042;
//        client.connect(port);
//        double total_time = 0;
//
//        for (int i = 1; i <= iterations; i++) {
//
//            Runtime runtime = Runtime.getRuntime();
//            // Calculate the used memory
//
//            //long memory = runtime.totalMemory() - runtime.freeMemory();
//            Random r = new Random();
//            int id = r.nextInt(999999);
//            Timestamp start_time = new Timestamp(System.currentTimeMillis());
//            try {
//                if (buffer != null && buffer.limit() == buffer.capacity()) {
//
//                client.getSession().execute(
//                        "INSERT INTO test.size_stats (id, data) VALUES (?, ?)",
//                        id, buffer);
//                    //out.println("End Time :" + end_time);
//                    Timestamp end_time = new Timestamp(System.currentTimeMillis());
////            out.println("Record added in Cassandra");
////            out.println("Id is :" + id);
//                    total_time = total_time + (end_time.getTime() - start_time.getTime());
////            out.println("Time Taken:" + df2.format(time_taken / 1000));
//                    file_count++;
//                    out.println("File No:- "+file_count + " inserted with id "+ id);
//                } else {
//                    out.println("Byte buffer object has become null");
//                    break;
//                }
//            } catch (Exception e) {
//                out.println("Exception occured");
//                e.printStackTrace();
//                System.exit(0);
//            }
//        }
//        out.println("No of times file inserted = " + file_count);
//        out.println("Time Taken taken: " + df2.format(total_time / (1000 * 60)) + " mins");
//        client.close();
//        dis.close();
//        System.exit(0);
//    }
//
//    @Override
//    protected void finalize() throws Throwable {
//        try {
//
//            System.out.println("inside finalize()");
//        } catch (Throwable e) {
//
//            throw e;
//        } finally {
//
//            System.out.println("Calling finalize method"
//                    + " of the Object class");
//            System.out.println("Time :"+ new Timestamp(System.currentTimeMillis()));
//
//            // Calling finalize() of Object class
//            super.finalize();
//        }
   }

    public static String bytesToHex(byte[] in) {
        final StringBuilder builder = new StringBuilder();
        for(byte b : in) {
            builder.append(String.format("%02x", b));
        }
        return builder.toString();
    }

}
