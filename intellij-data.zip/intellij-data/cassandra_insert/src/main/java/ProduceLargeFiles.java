import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ProduceLargeFiles {

    public static void main(String[] args) throws IOException, JSONException {
        long file_count = 0;
            String folderPath = args[0];
            String topic_name = args[1];
            int iterations = Integer.parseInt(args[2]);
//            List<String> result = new ArrayList<>();
//            DecimalFormat df2 = new DecimalFormat("#.####");
//            try (Stream<Path> walk = Files.walk(Paths.get(folderPath))) {
//
//                result = walk.filter(Files::isRegularFile)
//                        .map(x -> x.toString()).collect(Collectors.toList());
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            System.out.println("Loaded "+ result.size()+" files from directory");

            Properties properties = new Properties();
            properties.setProperty("bootstrap.servers", "localhost:9092");
            properties.setProperty("auto.offset.reset", "latest");
            properties.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            properties.setProperty("value.serializer", "org.apache.kafka.common.serialization.ByteBufferSerializer");
            KafkaProducer<String, ByteBuffer> producer = new KafkaProducer<>(properties);
            System.out.println("Kafka producer created "+producer);

            File pdfFile = new File(folderPath);
            byte[] pdfData = new byte[(int) pdfFile.length()];
            DataInputStream dis = new DataInputStream(new FileInputStream(pdfFile));
            dis.readFully(pdfData);  // read from file into byte[] array
            //System.out.println("Size in bytes: " + pdfData.length);
            dis.close();
            ByteBuffer buffer = ByteBuffer.wrap(pdfData);
            System.out.println("Started pushing files on producer");
            //for (String path : result) {
            for (int i = 1; i <= iterations; i++){
//                File pdfFile = new File(path);
//                byte[] pdfData = new byte[(int) pdfFile.length()];
//                DataInputStream dis = new DataInputStream(new FileInputStream(pdfFile));
//                dis.readFully(pdfData);  // read from file into byte[] array
//                //System.out.println("Size in bytes: " + pdfData.length);
//                dis.close();
//                ByteBuffer buffer = ByteBuffer.wrap(pdfData);
                //out.println("size"+ buffer.array().length);
                Random r = new Random();
                int id = r.nextInt(99999);
//                JSONObject json = new JSONObject();
//                json.put("id",id);
//                json.put("data", buffer);
//                String stringData = json.toString();
                producer.send(new ProducerRecord<String, ByteBuffer>(topic_name,buffer));
                file_count++;
            }
            producer.flush();
            producer.close();
            System.out.println("Produced "+ file_count+ " on the topic "+topic_name);

    }


}
