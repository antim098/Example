package jmx;

import javax.management.*;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CassandraJMXStats {

	private static final char DOT = '.';
	private static final String SQUARE_BRACKETS = "[]";
	private static final String DASH = "-";
	private static final String NAME = "name";
	static String JMX_URL_PREFIX = "service:jmx:rmi:///jndi/rmi://";
	static String JMX_URL_POSTFIX = "/jmxrmi";
	static String CASSANDRADB = "org.apache.cassandra.db";
	static String CASSANDRANET = "org.apache.cassandra.net";
	static String CASSANDRA_SERVICE_URL = ":type=";
	static String JUMBUNE_CONTEXT_URL = "org.jumbune.context:type=ExposedJumbuneMetrics";

	public static void main(String args[])
			throws AttributeNotFoundException, InstanceNotFoundException, IntrospectionException, MBeanException,
			ReflectionException, IOException, MalformedObjectNameException, NullPointerException {

		Map<String, Object> jmxStats = getAllJMXStats(":type=StorageService", "172.50.34.206", "7199", CASSANDRADB );

		for (Map.Entry<String, Object> jmxStat : jmxStats.entrySet()) {

			System.out.println("Attribute Name " + jmxStat.getKey() + " >>>>>> " + jmxStat.getValue());

		}
		
		Map<String, Object> jmxStatsNet = getAllJMXStats(":type=FailureDetector", "172.50.34.206", "7199", CASSANDRANET);
		
		for (Map.Entry<String, Object> jmxStat : jmxStatsNet.entrySet()) {

			System.out.println("Attribute Name " + jmxStat.getKey() + " >>>>>> " + jmxStat.getValue());

		}
	}

	public static Map<String, Object> getAllJMXStats(String jmxDaemon, String host, String port,String cassandraUrl)
			throws IOException, AttributeNotFoundException, InstanceNotFoundException, MBeanException,
			ReflectionException, IntrospectionException {

		JMXConnector connector = null;
		MBeanServerConnection connection = null;
		JMXServiceURL url = new JMXServiceURL(JMX_URL_PREFIX + host + ":" + port + JMX_URL_POSTFIX);
		String serviceUrl = null;

		serviceUrl = cassandraUrl + jmxDaemon;

		//for passing credentials for password
		Map<String, String[]> env = new HashMap<>();
		String[] credentials = {"cassandra", "cassandra"};
		env.put(JMXConnector.CREDENTIALS, credentials);

		connector = JMXConnectorFactory.connect(url, env);

		//connector = JMXConnectorInstance.getJMXConnectorInstance(url);
		connection = connector.getMBeanServerConnection();
		Set<ObjectName> names = connection.queryNames(null, null);
		String objectName;
		MBeanInfo minfo;
		System.out.println(names.size());

		MBeanAttributeInfo[] mbi;
		
		Map<String, Object> attribMap = null;
		for (ObjectName objName : names) {
			attribMap = new HashMap<String, Object>();
			objectName = objName.toString();
			if (!objectName.contains("ContainerResource_container_")) {
				if (JUMBUNE_CONTEXT_URL.equals(objectName) || (objectName.indexOf(serviceUrl) > -1)) {
					System.out.println(objectName);

					minfo = connection.getMBeanInfo(objName);
					mbi = minfo.getAttributes();
					for (MBeanAttributeInfo info : mbi) {
						// some beans do not support threshold props,
						// consequently
						// throw an UnsupportedOperationException
						if (info.isReadable()) {
							
							attribMap.put(objName.getKeyProperty(NAME) + DOT + info.getName(),
									connection.getAttribute(objName, info.getName()));

						}
					}
					
					return attribMap;

				}
			}
		}

		return attribMap;
	}

	
}
