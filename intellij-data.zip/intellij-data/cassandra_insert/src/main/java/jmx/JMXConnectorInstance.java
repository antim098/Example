package jmx;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;


/**
 * This class basically for object creation of JMXConnector and get and put
 * object of {@link JMXConnector} in cache.
 * 
 * 
 */
public final class  JMXConnectorInstance {

	private static JMXConnector connector = null;

	/***
	 * private constructor
	 */
	private JMXConnectorInstance() {
	}


	public synchronized static JMXConnector getJMXConnectorInstance(JMXServiceURL url) throws IOException {
		
		Map env = new HashMap();
		//String[] credentials = {"cassandra", "cassandra"};
		//env.put( JMXConnector.CREDENTIALS, credentials);
		env.put("jmx.remote.x.client.connection.check.period", 0);
		connector = JMXConnectorFactory.connect(url, env);
		
		return connector;
	}
	
	public synchronized static void nullifyConnector(){
		connector = null;
	}

}