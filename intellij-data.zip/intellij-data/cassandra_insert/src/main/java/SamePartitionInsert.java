import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static java.lang.System.out;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Session;
import javafx.scene.chart.ScatterChart;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.lang.System.clearProperty;
import static java.lang.System.out;

public class SamePartitionInsert {
        public static void main (String[]args) throws IOException {
        long file_count = 0;
        String filePath = args[0];
        int iterations = Integer.parseInt(args[1]);
        String tableName = args[2];
        String partitionDate = args[3];
        List<String> result = new ArrayList<>();
        DecimalFormat df2 = new DecimalFormat("#.####");
        String query = "insert into test." + tableName + "(id,data,date) values(?,?,?)";
//        try (Stream<Path> walk = Files.walk(Paths.get(filePath))) {
//
//            result = walk.filter(Files::isRegularFile)
//                    .map(x -> x.toString()).collect(Collectors.toList());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }


        final CassandraConnector client = new CassandraConnector();
        final String ipAddress = "127.0.0.1"; //args.length > 0 ? args[0] :
        final int port = 9042;
        client.connect(port);
        double total_time = 0;

        for (int i = 1; i <= iterations; i++) {
            Random r = new Random();
            int id = r.nextInt(999999);
            //out.println("Start Time :" + start_time);
            //out.println("Ingesting File: ");
//            File pdfFile = new File(filePath);
//            byte[] pdfData = new byte[(int) pdfFile.length()];
//            DataInputStream dis = new DataInputStream(new FileInputStream(pdfFile));
//            dis.readFully(pdfData);  // read from file into byte[] array
//            //System.out.println("Size in bytes: " + pdfData.length);
//            dis.close();
//            ByteBuffer buffer = ByteBuffer.wrap(pdfData);

            FileInputStream fis = new FileInputStream(filePath);
            byte[] b = new byte[fis.available() + 1];
            int length = b.length;
            fis.read(b);

            //We now need to convert the byte array into a bytebuffer:
            ByteBuffer buffer = ByteBuffer.wrap(b);

            Timestamp start_time = new Timestamp(System.currentTimeMillis());
            try {
                if (buffer != null && buffer.limit() == buffer.capacity()) {
                    PreparedStatement ps = client.getSession().prepare(query);
                    BoundStatement boundStatement = new BoundStatement(ps);
                    client.getSession().execute(boundStatement.bind(id, buffer,partitionDate));
//                client.getSession().execute(
//                        "INSERT INTO test.size_stats (id, data) VALUES (?, ?)",
//                        id, buffer);
                    //out.println("End Time :" + end_time);
                    Timestamp end_time = new Timestamp(System.currentTimeMillis());
//            out.println("Record added in Cassandra");
//            out.println("Id is :" + id);
                    total_time = total_time + (end_time.getTime() - start_time.getTime());
//            out.println("Time Taken:" + df2.format(time_taken / 1000));
                    file_count++;
                    out.println(file_count + " files inserted");
                } else {
                    out.println("Byte buffer object has become null");
                    break;
                }
            } catch (Exception e) {
                out.println("...........Exception occured.......");
                e.printStackTrace();
                System.exit(0);
            }
        }
        //out.println("No of times file inserted = " + file_count);
        out.println("Time Taken taken: " + df2.format(total_time / (1000 * 60)) + " mins");
        client.close();
        //dis.close();
        System.exit(0);
    }


    }
