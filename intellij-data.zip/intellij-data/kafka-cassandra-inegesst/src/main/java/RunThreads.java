//import com.datastax.driver.core.*;
//
//import java.io.*;
//import java.sql.Array;
//import java.sql.Timestamp;
//
//import static java.lang.System.out;
//import static java.lang.System.out;
//
//public class RunThreads {
//
//    public static void main(String[] args) throws IOException {
//        int batchSize = 0;
//        //String query = args[0];
////        String filePath = args[0];
//        //batchSize = Integer.parseInt(args[1]);
//
////        final CassandraConnector client = new CassandraConnector();
////        //final String ipAddress = "127.0.0.1"; //args.length > 0 ? args[0] :
////        final int port = 9042;
////        //out.println("Connecting to IP Address " + ipAddress + ":" + port + "...");
////        client.connect(port);
////        Session session = client.getSession();
//
//
//        int RESULTS_PER_PAGE = 100;
//
//        if (batchSize != 0) {
//            RESULTS_PER_PAGE = batchSize;
//        }
//
//        //out.println("Batch Size is : " + batchSize);
//        //st.setFetchSize(RESULTS_PER_PAGE);
//        // Note that we don't rely on RESULTS_PER_PAGE, since Cassandra might
//        // have not respected it, or we might be at the end of the result set
//
//        //BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true));
//
//        long record_count = 0;
//
//        Timestamp start_time = new Timestamp(System.currentTimeMillis());
//        System.out.println("Start Time :"+ start_time);
//
//        Timestamp end_time = new Timestamp(System.currentTimeMillis());
////        client.close();
//
//        System.out.println("End Time :"+ end_time);
//        String time_taken = String.valueOf(end_time.getTime() - start_time.getTime());
//        out.println("Time Taken :"+ time_taken);
//        out.println("Records Read :"+ record_count);
//
//        String [] names = new String[]{"antim","kant","verma"};
//
//        for (int i=0; i<names.length; i++)
//        {
//            ThreadQuery object = new ThreadQuery(names[i]);
//            object.start();
//        }
//
////        BufferedReader br = new BufferedReader(new FileReader(filePath));
////        String line = br.readLine();
////        while (line != null)
////        {
////            ThreadQuery object = new ThreadQuery(line);
////            object.start();
////            line = br.readLine();
////        }
//
//    }
//
//}
