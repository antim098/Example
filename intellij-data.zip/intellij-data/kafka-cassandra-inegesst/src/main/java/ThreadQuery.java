//import com.datastax.driver.core.Row;
//import com.datastax.driver.core.Session;
//
//import java.sql.Timestamp;
//
//public class ThreadQuery extends Thread{
//
//    String query;
//    Session session;
//    long record_count = 0;
//
//    // this would be invoked while an object
//    // of that class is created.
//    ThreadQuery(String query)
//    {
//        this.query = query;
//        //this.session = session;
//    }
//
//    @Override
//    public void run() {
//        System.out.println ("Thread " +
//                Thread.currentThread().getId() +
//                " is running");
//        Timestamp start_time = new Timestamp(System.currentTimeMillis());
//        System.out.println("Start Time :"+ start_time+"----"+query);
//
////        for (Row row : session.execute(query)) {
////            record_count++;
////            //writer.append('\n');
////            //writer.append(row.toString());
////        }
//
//    }
//}
