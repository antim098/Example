import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class test {

    public static void main(String[] args) {
        String columns = "documentid , address , apn , application , asid , attachmenttype , bccmailid , bts , callduration , callednumber , callendtime , callid , callingstationid , callstarttime , certificateissuedto , certificateissuer , chatmailid , chatroomid , chatroomname , ci , city , clientip , codeclist , conferenceid , contenttype , country , datarx , datatx , dir , documentingesttime , domain , dstc , dstmac , duration , email , emailheader , eventcount , eventtype , fieldtype , fieldvalue , filename , filterid , frequency , from_col , frommailid , gender , ifid , ipdrx , ipdtx , isaccid , isaccountid , isbuddylist , iscalledname , iscallername , iscallernumber , ischatroomcaption , ischatroomcategory , ischatroommoderator , ischatroomsuspect , ischatsessionkey , isconfchatsuspect , iscorrelated , iscorrelationid , isdate , isdependencylist , isdescription , isdigichatdescription , isdigichatip , isdigichatserverip , isdirname , isdisplaystring , isei , isfilereferer , isfirstparttimestamp , isfrommailid , isftpfilelist , ishttpcookie , ishttppagetype , ishttpresourceurl , ishttpsessiontype , ishttpstatus , isicqdescription , isipidmapping , islanguageused , isloc , islop , ismailbccmailid , ismailcclist , ismailccmailid , ismailfromid , ismailtype , ismatchedqueryname , ismetaversion , ismimecachecontrol , ismimecontentencoding , ismimecontenttransencoding , ismimeexpires , ismimelastmodified , ismimepragma , ismimetransencoding , isnumberofpackets , ispd , ispde , ispdi , ispgpused , ispo , ispostnatclientip , ispostnatclientport , isprenatsessiontimestamp , isprotocolsused , isptmmailcase , isrealname , isreconstructiontimestamp , isreplytomailid , isresourceidentifier , issipuri , issmtpbccmailid , issmtpbccname , issmtpccmailid , issmtpccname , issmtpfrommailid , issmtptomailid , issslei , isssles , issslets , issuggestedprotocol , istcpsrcport , istobedisplayed , istotimestamp , istransporttype , istunneltype , isudpvoiceserverip , isudpvoiceserverport , isuserinfo1 , isuserip , isuserlogintime , isuserlogouttime , isuserport , isusersessionstatus , lac , latitude , liid , lkid , locationinfo , longitude , lot , lp , lt , maildate , mailfromname , mailtoname , maritalstatus , mcc , mnc , mobilenumber , name , nei , oime , oims , op , opname , partnumber , password , path , pdrs , protocol , queryname , rc , refferalurl , requesttype , resourcelastviewedbyuser , resourcetype , ri , rxpacketcount , serverip , serverport , size , skills , srcc , srcmac , st , state , subject , timetolive , to_col , tomailid , tp , transactionendtime , transactionid , transactionstarttime , transactiontype , trgt , trid , trtp , txpacketcount , url , useragent , username , vid , vlanid";
        String values = "3,,94-250-0066,17.248.145.222,443,10.10.225.78,proprietary,httpothers,n.nextreactddd.com,a1-a2-a3-a4-a5-a6,,,,,,,,,0,,0,,,,,,56.045877,,,1,,,internet,1,34640928a6a162a8f5547205380b1e092f92d88c46413599b6432d702201916d_108.177.119.113@android.clients.google.com,,,,,,,6f35d7ec06616c8a97c9fcd2d0cb7b1b,,,,,,,,GET,,,,,,,,,,,,,,,,,,1725032187-C3A7-421b-8A9A-5FA9E310FD7E,945615661,,C0123,,2,,,,,,,,,,,, abvdfc@ct.com,,,,,,,uhbubu11@ip.com,asdf,mylogin11@fb.com,hotmail,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,asdf,,,,,,,,,,,,, cdf@ct.com,,,,,,,,,,,,,,w98d8cd98f00b204e9800998ecf8427e-2020-05-21,2020-05-21:17:21";
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("name", "Mars");
//        data.put("age", "");
//        data.put("number","100");
//        data.put("city", "NY");
        ArrayList col= new ArrayList(Arrays.asList(columns.split(",")));
        ArrayList val= new ArrayList(Arrays.asList(values.split(",")));
        Map<ArrayList, ArrayList> resultMap = new HashMap<>();
        resultMap.put(col,val);

//        Stream.of(commaSeparated.split(","))
//                .map(String::trim)
//                .collect(toList());
//
//        Map<String, String> resultMap = Stream.of(columns.split(","),values.split(","))
//                        .collect(Collectors.toMap(line -> line[0], line -> line[1]));



        resultMap.values().remove("");

        JSONObject json = new JSONObject(resultMap);
        System.out.printf("JSON: %s", json.toString());

        // Gson gson = new Gson();
        // String json = gson.toJson(myObject);

// 	 Map<String,String> map = new HashMap<String,String>();

//         map.put("1", "One");
//         map.put("2", "Two");
//         map.put("3", null);
//         map.put("4", "Four");
//         map.put("5", null);

//          System.out.println(map);

//         map.values().removeIf(Objects::isNull);

//         System.out.println(map);

    }
}

