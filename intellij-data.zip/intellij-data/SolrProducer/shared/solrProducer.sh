#!/bin/sh
count=1
while [ "$count" -lt `expr $4 + 1` ]    # this is loop1
do
	./solrProducer "$1" "$2" "$3" "$count" &
	echo "starting instance $count"
	count=`expr $count + 1`
done
