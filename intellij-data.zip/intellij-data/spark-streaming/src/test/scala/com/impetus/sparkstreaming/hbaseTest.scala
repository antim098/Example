package com.impetus.sparkstreaming

import com.united.sparkstreaming._
import org.scalatest.{ BeforeAndAfter, FlatSpec, Matchers }
import scala.language.postfixOps
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.util.Bytes;
import java.io.InputStream
import java.io.FileInputStream
import java.util.Properties
import org.apache.hadoop.hbase.client.Scan;
import java.nio.file.Files; import java.nio.file.Paths;
import org.elasticsearch.spark._
import org.apache.spark.SparkConf
import com.google.gson.{JsonParser }

class hbaseTest extends FlatSpec with BeforeAndAfter {
  val is: InputStream = new FileInputStream("/home/impadmin/Documents/config.properties")
  val prop: Properties = new Properties();
  prop.load(is);

  val es_index_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.es.index.date.format"))
  val inputSpec = prop.getProperty("spark.receipts.jolt.input.spec")
  val test_RcptId = "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa"

  val sparkConf = new SparkConf().setAppName("test").setMaster("local")
  val sc = ReceiptLoad.getSC(sparkConf)

  val conf = HBaseConfiguration.create()
  var hbaseAdmin = new HBaseAdmin(conf)
  val table = new HTable(conf, prop.getProperty("spark.receipts.hbase.table.name"))

  "H base connection" should "succeed if connected" in {
    assert(ReceiptLoad.hbaseConf() != null)
  }

  "Check Table in HBase" should "succeed if table exists" in {
    var result = false
    val TableName = prop.getProperty("spark.receipts.hbase.table.name")
    if (hbaseAdmin.tableExists(TableName)) {
      println(TableName + "  Exists")
      result = true
    }
    assert(result)
  }

  "Table which dosen't exists" should "succeed if table does not exists" in {
    val tablname = "noname"
    val result = hbaseAdmin.tableExists(tablname)
    assertResult(false) {
      result
    }
  }

  "Check Column" should "return true if column exists" in {
    var result = false
    // Instantiating the Scan class
    val scan = new Scan();
    // Scanning the required columns
    scan.addColumn(Bytes.toBytes("cfamily"), Bytes.toBytes("receipts_payload"));
    // Getting the scan result
    val scanner = table.getScanner(scan);
    // Reading values from scan result
    if (scanner.next() != null) {
      val row = scanner.next()
      scanner.close();
      result = true
    }
    assert(result)
  }

  "Check File in HDFS for Hbase" should "succeed if file exists" in {
    var result = false
    val replay_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.replay.date.format"))
    val outputpath = prop.getProperty("spark.receipts.hbase.replay.path") + replay_date_format.format(new java.util.Date())
    val path = Paths.get(outputpath)
    if (Files.exists(path)) {
      result = true
      println("Path Exists in HDFS")
    }
    assert(result)
  }

  "Check Receipt Id" should "succeed if Receipt Id exists" in {
    var result = false
    val RcptId = "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa"
    val g = new Get(Bytes.toBytes("90"));
    val r = table.get(g);
    if (r.getExists()) {
      result = true
      println("Columns exist")
    }
    assert(result)
  }

  "Check incorrect Receipt Id" should "succeed if Receipt Id dosen't exists" in {
    var result = true
    val RcptId = "Rcpt-8e5c0d35-de37-42d9-8e93-a27f600aacfa"
    val g = new Get(Bytes.toBytes(RcptId));
    val r = table.get(g);
    if (r.getExists()) {
      result = true
      println("Columns exist")
    }
    assert(result)
  }

  "Check Column with Receipt Id" should "succeed if column family exists" in {
    var result = false
    val g = new Get(Bytes.toBytes(test_RcptId));
    val r = table.get(g)
    val bytevalue: Array[Byte] = r.getValue(Bytes.toBytes("cfamily"), Bytes.toBytes("receipts_payload"))
    val value = Bytes.toString(bytevalue);
    if (value != null) {
      result = true
      println("Columns exists")
    }
    assert(result)
  }

  "Check Column with Incorrect Receipt Id" should "succeed if column family dosen't exists" in {
    var result = true
    val g = new Get(Bytes.toBytes("1"));
    val r = table.get(g)
    val bytevalue: Array[Byte] = r.getValue(Bytes.toBytes("cfamily"), Bytes.toBytes("receipts_payload"))
    val value = Bytes.toString(bytevalue);
    if (value != null) {
      result = true
      println("Columns exists")
    }
    assert(result)
  }

  "Check Index id" should "succeed if exists in ES" in {
    var result = false
    val elastic_index_name = prop.getProperty("spark.receipts.elastic.index.name") + es_index_date_format.format(new java.util.Date())
    val elastic_doc_name = prop.getProperty("spark.receipts.elastic.doc.name")
    val r = sc.esRDD(elastic_index_name + "/" + elastic_doc_name)
    val doc = r.first()._2
    val output = doc.get("message").get.asInstanceOf[String]
    if (output != null) {
      print("Index id exists")
      result = true
    }
    assert(result)
  }

  "Check Incorrect Index id" should "succeed if dosen't exists in ES" in {
    var result = true
    val r = sc.esRDD("tutorialas/helloworld")
    val doc = r.first()._2
    val output = doc.get("message").get.asInstanceOf[String]
    if (output != null) {
      result = false
    }
    assert(result)
  }

  "Check file in HDFS for ElasticSearch" should "succeed if file exists" in {
    var result = false
    val replay_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.replay.date.format"))
    val outputpath = prop.getProperty("spark.receipts.elastic.replay.path") + replay_date_format.format(new java.util.Date())
    val path = Paths.get(outputpath)
    if (Files.exists(path)) {
      result = true
      println("Path Exists in HDFS")
    }
    assert(result)
  }

  "Check Jolt transformation" should "succeed if jolt transformation is correct" in {
    var result = false
    val inputJson = scala.io.Source.fromFile("/home/impadmin/Desktop/input.json").mkString
    val ex_op: String = scala.io.Source.fromFile("/home/impadmin/Desktop/output.txt").mkString
    val act_op: String = ReceiptLoad.tranformrdd(inputJson, inputSpec)
    val parser = new JsonParser()
    val o1 = parser.parse(ex_op)
    val o2 = parser.parse(act_op)
    if (o1.equals(o2)) result = true
    assert(result)
  }

}

