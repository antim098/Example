package com.united.sparkstreaming

import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapred.TableOutputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.mapred.JobConf
import org.apache.log4j.Level
import org.apache.log4j.LogManager
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

import com.fasterxml.jackson.databind.ObjectMapper
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormatter
import org.joda.time.format.DateTimeFormat
import org.apache.hadoop.fs.Path
import org.apache.hadoop.fs.FileSystem
import java.io.FileInputStream
import java.util.Properties
import java.io.InputStream

/**
 * The ReplayHbaseMessages class provides functionality to read computed streaming data from HDFS 
 * and store it into HBase in case there is any failure in doing the same through ReceiptLoad.
 */
object ReplayHbaseMessages extends Serializable {


  def convertToPut(record: String): (ImmutableBytesWritable, Put) = {
    val rowkey = extractAttributes(record, "RcptId")
    val put = new Put(Bytes.toBytes(rowkey))
    put.add(Bytes.toBytes("cfamily"), Bytes.toBytes("receipts_payload"), Bytes.toBytes(record))
    return (new ImmutableBytesWritable(Bytes.toBytes(rowkey)), put)
  }

  def extractAttributes(record: String, attribute: String): String = {
    val mapper = new ObjectMapper();
    val root = mapper.readTree(record);
    var extracted_attribute = root.path("RcptOutputEvent").path(
      "RcptData").path("RcptId").toString()
    extracted_attribute
  }

  def main(args: Array[String]) {
    val log = LogManager.getLogger(ReplayHbaseMessages.getClass.getName)
    if (args.length > 0) {
      val is: InputStream = new FileInputStream(args(0))
      val prop: Properties = new Properties()
      prop.load(is)
      val sparkConf = new SparkConf().setAppName("ReplayHbaseMessages") 
      /*Creating SparkConf variable which provides configuration for a Spark application.
       * Used to set various Spark parameters as key-value pairs.
       */
      sparkConf.set("spark.hadoop.validateOutputSpecs", "false")
      val conf = HBaseConfiguration.create() //Creates a Configuration with HBase resources
      conf.set("hbase.zookeeper.quorum", prop.getProperty("spark.receipts.hbase.zookeeper.quorum"))
      conf.set("hbase.zookeeper.property.clientPort", prop.getProperty("spark.receipts.hbase.zookeeper.property.clientPort"))
      conf.set("zookeeper.connection.timeout.ms", prop.getProperty("spark.receipts.zookeeper.connection.timeout.ms"))
      conf.set("mapreduce.outputformat.class", "org.apache.hadoop.hbase.mapreduce.TableOutputFormat")
      conf.set("mapreduce.job.output.key.class", "org.apache.hadoop.hbase.io.ImmutableBytesWritable")
      conf.set("mapreduce.job.output.value.class", "org.apache.hadoop.io.Writable")
      //conf.set("hbase.mapred.outputtable", "receipts")
      conf.set(TableOutputFormat.OUTPUT_TABLE, prop.getProperty("spark.receipts.hbase.table.name"))
      val jobConfig: JobConf = new JobConf(conf, this.getClass)
      jobConfig.set("mapreduce.output.fileoutputformat.outputdir", prop.getProperty("spark.receipts.mapreduce.output.fileoutputformat.outputdir"))
      jobConfig.setOutputFormat(classOf[TableOutputFormat])
      jobConfig.set(TableOutputFormat.OUTPUT_TABLE, prop.getProperty("spark.receipts.hbase.table.name"))

      val sc = SparkContext.getOrCreate(sparkConf); //SparkContext variable.The Main entry point for Spark functionality,represents the connection to a Spark cluster.
      val fs = FileSystem.get(sc.hadoopConfiguration) //Getting the fileSystem configuration to perform operations on the file system.
      var date: DateTime = null
      var dateOneHourBack: DateTime = null
      var dtfOut: DateTimeFormatter = null
      var partition: String = null
      if (prop.getProperty("spark.receipts.hbase.replay.run.manually").equalsIgnoreCase("yes")) {
        partition = prop.getProperty("spark.receipts.hbase.replay.process.date")
      } else {
        date = DateTime.now();
        dateOneHourBack = date.minusHours(1);
        dtfOut = DateTimeFormat.forPattern(prop.getProperty("spark.receipts.replay.date.format"));
        partition = dtfOut.print(dateOneHourBack)
      }
      val location = prop.getProperty("spark.receipts.hbase.replay.path") + partition //extracting the hbase replay path from the property variable.
      if (fs.exists(new Path(location))) { //checking the existence of the path on filesystem

        val hbaseRDD = sc.textFile(location, 1)

        try {
          hbaseRDD.map(println)
          val hbaseRdd = hbaseRDD.map(x => convertToPut(x.toString()))
          hbaseRDD.map(println)
          hbaseRdd.saveAsHadoopDataset(jobConfig)
        } catch {
          case e: Exception => {
            log.error("Unable to write replay messages to HBase", e)
            val outputpath = prop.getProperty("spark.receipts.hbase.fallback.path") + new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.replay.date.format")).format(new java.util.Date())
            hbaseRDD.map(x => x.toString()).saveAsTextFile(outputpath)
          }
        }

        if (fs.exists(new Path(location)))
          fs.delete(new Path(location), true)
      }
    } else {
      println("Properties file needs to be passed in the argument")
    }
  }
}