package com.united.sparkstreaming

import org.apache.log4j.Level
import org.apache.log4j.LogManager
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.elasticsearch.spark.sparkRDDFunctions
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormatter
import org.joda.time.format.DateTimeFormat
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import java.io.InputStream
import java.io.FileInputStream
import java.util.Properties

/**
 * The ReplayEsMessages class provides functionality to read saved computed streaming data from HDFS 
 * and store it into ES in case there is any failure in doing the same through ReceiptLoad.
 */
object ReplayEsMessages extends Serializable {

  def main(args: Array[String]) {
    val log = LogManager.getLogger(ReplayEsMessages.getClass.getName)
    if (args.length > 0) {
      val is: InputStream = new FileInputStream(args(0))
      val prop: Properties = new Properties()
      prop.load(is)
      val replay_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.replay.date.format"))
      val fallout_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.fallout.date.format"))
      val es_index_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.es.index.date.format"))
      
      val sparkConf = new SparkConf().setAppName("ReplayESMessages")  //Creating SparkConf variable which provides configuration for a Spark application.Used to set various Spark parameters as key-value pairs.
      sparkConf.set("es.nodes", prop.getProperty("spark.receipts.es.nodes"))
      sparkConf.set("es.port", prop.getProperty("spark.receipts.es.port"))
      sparkConf.set("es.net.http.auth.user", prop.getProperty("spark.receipts.es.net.http.auth.user"))
      sparkConf.set("es.net.http.auth.pass", prop.getProperty("spark.receipts.es.net.http.auth.pass"))
      sparkConf.set("es.net.ssl", prop.getProperty("spark.receipts.es.net.ssl"))
      sparkConf.set("es.net.ssl.protocol", prop.getProperty("spark.receipts.es.net.ssl.protocol"))
      sparkConf.set("es.net.ssl.cert.allow.self.signed", prop.getProperty("spark.receipts.es.net.ssl.cert.allow.self.signed"))
      sparkConf.set("es.net.ssl.keystore.type", prop.getProperty("spark.receipts.es.net.ssl.keystore.type"))
      sparkConf.set("es.net.ssl.truststore.location", prop.getProperty("spark.receipts.es.net.ssl.truststore.location"))
      sparkConf.set("es.net.ssl.truststore.pass", prop.getProperty("spark.receipts.es.net.ssl.truststore.pass"))
      sparkConf.set("es.input.json", prop.getProperty("spark.receipts.es.input.json"))
      sparkConf.set("es.index.auto.create", prop.getProperty("spark.receipts.es.auto.create"))
      sparkConf.set("es.http.timeout", prop.getProperty("spark.receipts.es.http.timeout"))
      sparkConf.set("spark.hadoop.validateOutputSpecs", "false")

      val sc = SparkContext.getOrCreate(sparkConf); //SparkContext variable.The Main entry point for Spark functionality,represents the connection to a Spark cluster.
      val fs = FileSystem.get(sc.hadoopConfiguration) //Getting the fileSystem configuration to perform operations on the file system. 
      var date:DateTime = null
      var dateOneHourBack:DateTime = null
      var dtfOut: DateTimeFormatter = null
      var partition : String = null
      if (prop.getProperty("spark.receipts.elastic.replay.run.manually").equalsIgnoreCase("yes")) {
         partition  = prop.getProperty("spark.receipts.elastic.replay.process.date")
      } else {
         date = DateTime.now();
         dateOneHourBack = date.minusHours(1);
         dtfOut= DateTimeFormat.forPattern(prop.getProperty("spark.receipts.replay.date.format"));
         partition = dtfOut.print(dateOneHourBack)
      }
      val location = prop.getProperty("spark.receipts.elastic.replay.path") + partition //extracting the es directory path from the property variable.
      if (fs.exists(new Path(location))) {  //checking the existence of the path on filesystem
        val esRDD = sc.textFile(location, 1)

        try {
          val elastic_index_name = prop.getProperty("spark.receipts.elastic.index.name") + es_index_date_format.format(new java.util.Date())
          val elastic_doc_name = prop.getProperty("spark.receipts.elastic.doc.name")
          esRDD.saveToEs(elastic_index_name + "/" + elastic_doc_name, Map("es.mapping.id" -> "RcptId"))
        } catch {
          case e: Exception => {
            log.error("Unable to write replay messages to ES ", e)
            val outputpath = prop.getProperty("spark.receipts.elastic.fallback.path") + new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.replay.date.format")).format(new java.util.Date())
            esRDD.map(x => x.toString()).saveAsTextFile(outputpath)
          }
        }

        if (fs.exists(new Path(location)))
          fs.delete(new Path(location), true)
      }
    } else {
      println("Properties file needs to be passed in the argument")
    }

  }
}