package com.united;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.bazaarvoice.jolt.Chainr;
import com.bazaarvoice.jolt.ContextualTransform;
import com.bazaarvoice.jolt.JoltTransform;
import com.bazaarvoice.jolt.JsonUtils;
import com.bazaarvoice.jolt.SpecDriven;
import com.bazaarvoice.jolt.Transform;
import com.bazaarvoice.jolt.chainr.spec.ChainrEntry;
import com.bazaarvoice.jolt.exception.SpecException;

public class JsonTransformer {

	private Object transform(JoltTransform joltTransform, Object input) {
		return joltTransform instanceof ContextualTransform
				? ((ContextualTransform) joltTransform).transform(input, Collections.emptyMap())
				: ((Transform) joltTransform).transform(input);
	}

	private JoltTransform getCustomTransform(final ClassLoader classLoader, final String customTransformType,
			final Object specJson) throws Exception {
		final Class clazz = classLoader.loadClass(customTransformType);
		if (SpecDriven.class.isAssignableFrom(clazz)) {
			final Constructor constructor = clazz.getConstructor(Object.class);
			return (JoltTransform) constructor.newInstance(specJson);

		} else {
			return (JoltTransform) clazz.newInstance();
		}
	}

	private List<JoltTransform> getChainrJoltTransformations(ClassLoader classLoader, Object specJson)
			throws Exception {

		List operations = (List) specJson;
		ArrayList<JoltTransform> entries = new ArrayList<>(operations.size());
		for (Object chainrEntryObj : operations) {
			if (!(chainrEntryObj instanceof Map)) {
				throw new SpecException("JOLT ChainrEntry expects a JSON map - Malformed spec");
			} else {
				Map chainrEntryMap = (Map) chainrEntryObj;

				String opString = (String) chainrEntryMap.get("operation");
				String operationClassName;

				operationClassName = ChainrEntry.STOCK_TRANSFORMS.getOrDefault(opString, opString);

				entries.add(getCustomTransform(classLoader, operationClassName, chainrEntryMap.get("spec")));
			}
		}

		return entries;

	}

	public String transform(String inputSpec, String inputJson) throws Exception {

		Object specJson = JsonUtils.jsonToObject(inputSpec, "UTF-8");
		JoltTransform joltTranform;
		Object transformedJson = null;
		joltTranform = new Chainr(
				getChainrJoltTransformations(Thread.currentThread().getContextClassLoader(), specJson));
		final Object inputJsonObj = JsonUtils.jsonToObject(inputJson);
		transformedJson = transform(joltTranform, inputJsonObj);
		return JsonUtils.toJsonString(transformedJson);

	}
	
}
