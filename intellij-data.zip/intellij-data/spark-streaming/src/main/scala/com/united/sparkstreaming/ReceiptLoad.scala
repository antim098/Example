package com.united.sparkstreaming
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapred.TableOutputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.mapred.JobConf
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.Seconds
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.kafka010.ConsumerStrategies
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies
import com.fasterxml.jackson.databind.ObjectMapper
import com.united.JsonTransformer
import org.elasticsearch.spark._
import org.apache.log4j.LogManager
import org.apache.spark.rdd.RDD
import java.io.InputStream
import java.io.FileInputStream
import java.util.Properties

object ReceiptLoad extends Serializable {

  //val inputSpec = """[{"operation":"shift","spec":{"RcptOutputEvent":{"RcptData":{"RcptId":"RcptId","RecLoc":"RecLoc","RcptTmstmp":"RcptTmstmp","Email":"Email","Phone":"Phone","Tvlr":{"*":{"LstNm":"Tvlr[&1].LstNm","FstNm":"Tvlr[&1].FstNm","FqtvNbr":"Tvlr[&1].FqtvNbr"}},"Tkt":{"*":{"TktNbr":"Tkt[&1].TktNbr","Fop":{"*":{"CCLast4":"Tkt[&3].CCLast4[&1]"}}}},"Emd":{"*":{"DocId":"Emd[&1].DocId"}},"Segment":{"*":{"FltNbr":"Segment[&1].FltNbr","DptCityCd":"Segment[&1].DptCityCd","DptDt":"Segment[&1].DptDt","ArrCityCd":"Segment[&1].ArrCityCd"}}}}}}]"""
  var Tname = "empty"
  def extractAttributes(record: String, attribute: String): String = {
    val mapper = new ObjectMapper();
    val root = mapper.readTree(record);
    var extracted_attribute = root.path("RcptOutputEvent").path("RcptData").path("RcptId").toString()
    extracted_attribute
  }

  def convertToPut(record: String): (ImmutableBytesWritable, Put) = {
    val rowkey = extractAttributes(record, "RcptId")
    val put = new Put(Bytes.toBytes(rowkey))
    put.add(Bytes.toBytes("cfamily"), Bytes.toBytes("receipts_payload"), Bytes.toBytes(record))
    return (new ImmutableBytesWritable(Bytes.toBytes(rowkey)), put)
  }

  def tranformrdd(input: String, inputSpec: String): String = {
    val output: String = new JsonTransformer().transform(inputSpec, input)
    //println(output)
    output

  }

  def getSC(sparkConf: SparkConf): SparkContext = {
    val sc = new SparkContext(sparkConf)
    sc
  }

  def hbaseConf(): org.apache.hadoop.conf.Configuration = {
    val conf = HBaseConfiguration.create()
    conf
  }

  def main(args: Array[String]) {
    val log = LogManager.getLogger(ReceiptLoad.getClass.getName)
    if (args.length > 0) {
      val is: InputStream = new FileInputStream(args(0))
      val prop: Properties = new Properties();
      prop.load(is)

      val replay_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.replay.date.format"))
      val fallout_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.fallout.date.format"))
      val es_index_date_format = new java.text.SimpleDateFormat(prop.getProperty("spark.receipts.es.index.date.format"))
      val inputSpec = prop.getProperty("spark.receipts.jolt.input.spec")
      // val sparkConf = new SparkConf().setAppName(prop.getProperty("spark.app.name"))
      val sparkConf = new SparkConf().setAppName("test")
      sparkConf.set("es.nodes", prop.getProperty("spark.receipts.es.nodes"))
      sparkConf.set("es.port", prop.getProperty("spark.receipts.es.port"))
      sparkConf.set("es.net.http.auth.user", prop.getProperty("spark.receipts.es.net.http.auth.user"))
      sparkConf.set("es.net.http.auth.pass", prop.getProperty("spark.receipts.es.net.http.auth.pass"))
      sparkConf.set("es.net.ssl", prop.getProperty("spark.receipts.es.net.ssl"))
      sparkConf.set("es.net.ssl.protocol", prop.getProperty("spark.receipts.es.net.ssl.protocol"))
      sparkConf.set("es.net.ssl.cert.allow.self.signed", prop.getProperty("spark.receipts.es.net.ssl.cert.allow.self.signed"))
      sparkConf.set("es.net.ssl.keystore.type", prop.getProperty("spark.receipts.es.net.ssl.keystore.type"))
      sparkConf.set("es.net.ssl.truststore.location", prop.getProperty("spark.receipts.es.net.ssl.truststore.location"))
      sparkConf.set("es.net.ssl.truststore.pass", prop.getProperty("spark.receipts.es.net.ssl.truststore.pass"))
      sparkConf.set("es.input.json", prop.getProperty("spark.receipts.es.input.json"))
      sparkConf.set("es.index.auto.create", prop.getProperty("spark.receipts.es.auto.create"))
      sparkConf.set("es.http.timeout", prop.getProperty("spark.receipts.es.http.timeout"))

      val ssc = new StreamingContext(sparkConf, Seconds(10))
      val spark = SparkSession
        .builder()
        .config(sparkConf)
        .getOrCreate();
      val sc = getSC(sparkConf)

      sc.setCheckpointDir("/user/v734526/checkpoint");
      val conf = hbaseConf()
      conf.set("hbase.zookeeper.quorum", prop.getProperty("spark.receipts.hbase.zookeeper.quorum"))
      conf.set("hbase.zookeeper.property.clientPort", prop.getProperty("spark.receipts.hbase.zookeeper.property.clientPort"))
      conf.set("zookeeper.connection.timeout.ms", prop.getProperty("spark.receipts.zookeeper.connection.timeout.ms"))
      conf.set("mapreduce.outputformat.class", "org.apache.hadoop.hbase.mapreduce.TableOutputFormat")
      conf.set("mapreduce.job.output.key.class", "org.apache.hadoop.hbase.io.ImmutableBytesWritable")
      conf.set("mapreduce.job.output.value.class", "org.apache.hadoop.io.Writable")
      //conf.set("hbase.mapred.outputtable", "receipts")
      conf.set(TableOutputFormat.OUTPUT_TABLE, prop.getProperty("spark.receipts.hbase.table.name"))
      val jobConfig: JobConf = new JobConf(conf, this.getClass)
      jobConfig.set("mapreduce.output.fileoutputformat.outputdir", prop.getProperty("spark.receipts.mapreduce.output.fileoutputformat.outputdir"))
      jobConfig.setOutputFormat(classOf[TableOutputFormat])
      jobConfig.set(
        TableOutputFormat.OUTPUT_TABLE, prop.getProperty("spark.receipts.hbase.table.name"))

      val sqlContext = new SQLContext(sc)

      val kafkaParams = Map[String, Object](
        "bootstrap.servers" -> prop.getProperty("spark.receipts.kafka.bootstrap.servers"),
        "key.deserializer" -> classOf[StringDeserializer],
        "value.deserializer" -> classOf[StringDeserializer],
        "group.id" -> prop.getProperty("spark.receipts.kafka.group.id"),
        "auto.offset.reset" -> prop.getProperty("spark.receipts.kafka.auto.offset.reset"),
        "enable.auto.commit" -> (false: java.lang.Boolean))

      //val offsets = Map(new TopicPartition("test", 0) -> 2L)

      val topics = Array(prop.getProperty("spark.receipts.kafka.topic.name"))
      val stream = KafkaUtils.createDirectStream[String, String](
        ssc,
        LocationStrategies.PreferConsistent, ConsumerStrategies.Subscribe[String, String](topics, kafkaParams))
      stream.checkpoint(Seconds(5))
      stream.foreachRDD(
        rdd => {
          try {
            val hbaseRdd = rdd.map(x => convertToPut(x.value().toString()))
            hbaseRdd.saveAsNewAPIHadoopDataset(jobConfig)
          } catch {
            case e: Exception => {
              log.error("Unable to write to hbase ", e)
              val outputpath = prop.getProperty("spark.receipts.hbase.replay.path") + replay_date_format.format(new java.util.Date())
              rdd.map(x => x.value().toString()).saveAsTextFile(outputpath)
            }
          }
          var transformed: RDD[String] = null
          try {
            transformed = rdd.map(x => tranformrdd(x.value(), inputSpec))
          } catch {
            case e: Exception => {
              log.error("unable to transform the json using jolt", e)
              val outputpath = prop.getProperty("spark.receipts.elastic.fallout.path") + fallout_date_format.format(new java.util.Date())
              rdd.map(x => x.value().toString()).saveAsTextFile(outputpath)
            }
          }
          try {

            val elastic_index_name = prop.getProperty("spark.receipts.elastic.index.name") + es_index_date_format.format(new java.util.Date())
            val elastic_doc_name = prop.getProperty("spark.receipts.elastic.doc.name")
            transformed.saveToEs(elastic_index_name + "/" + elastic_doc_name, Map("es.mapping.id" -> "RcptId"))

          } catch {
            case e: Exception => {
              log.error("Unable to write to ES", e)
              val outputpath = prop.getProperty("spark.receipts.elastic.replay.path") + replay_date_format.format(new java.util.Date())
              rdd.map(x => x.value().toString()).saveAsTextFile(outputpath)
            }
          }

        })
      ssc.start()
      ssc.awaitTermination()
    } else {
      println("Properties file needs to be passed in the argument")
    }
  }

}