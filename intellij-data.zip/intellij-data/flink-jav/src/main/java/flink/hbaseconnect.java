package flink;

import org.apache.flink.api.common.io.OutputFormat;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;

import static org.apache.hadoop.hbase.HConstants.ZOOKEEPER_CLIENT_PORT;
import static org.apache.hadoop.hbase.HConstants.ZOOKEEPER_QUORUM;

public class hbaseconnect implements OutputFormat<Tuple2<String, Integer>> {

    private org.apache.hadoop.conf.Configuration conf = null;
    private Table table = null;
    private String taskNumber = null;
    private int rowNumber = 0;
    private Connection conn = null;

    private static final long serialVersionUID = 1L;

    @Override
    public void configure(Configuration parameters) {
        System.out.println("===============CREATING CONNECTION======================");
        conf = HBaseConfiguration.create();
        conf.set(ZOOKEEPER_QUORUM, "172.26.32.31");
        conf.set(ZOOKEEPER_CLIENT_PORT, "2181");
        try {
            conn = ConnectionFactory.createConnection(conf);
        } catch (IOException e) {
            System.out.println("=======FAILED TO CREATE HBASE CONNECTION==========");
            e.printStackTrace();
        }
        System.out.println("===============HBASE CONNECTION CREATED======================");
    }

    @Override
    public void open(int taskNumber, int numTasks) throws IOException {
        //table = new HTable(conf, "testing");
        table = conn.getTable(TableName.valueOf("testing"));
        this.taskNumber = String.valueOf(taskNumber);
    }

    @Override
    public void writeRecord(Tuple2<String, Integer> stringIntegerTuple2) throws IOException {
        System.out.println("================ Started Writing record in hbase=====================");
        Put put = new Put(Bytes.toBytes(taskNumber + rowNumber));
        put.add(Bytes.toBytes("ct"), Bytes.toBytes("column"),
                Bytes.toBytes(rowNumber));
        rowNumber++;
        System.out.println("================RECORD =====================" + put.toJSON());
        table.put(put);
        System.out.println("================Written record in hbase=====================");
    }

//    @Override
//    public void writeRecord(String record) throws IOException {
//        Put put = new Put(Bytes.toBytes(taskNumber + rowNumber));
//        put.add(Bytes.toBytes("entry"), Bytes.toBytes("entry"),
//                Bytes.toBytes(rowNumber));
//        rowNumber++;
//        table.put(put);
//    }

    @Override
    public void close() throws IOException {
        table.close();
        conn.close();
    }

}

