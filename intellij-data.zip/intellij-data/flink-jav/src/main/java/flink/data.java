package flink;

public class data {
    public int getId() {
        return id;
    }

    public data(int id) {
        this.id = id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    private int id;
    private String value;
}
