package KafkaSpark

import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, KafkaUtils, LocationStrategies}
import org.apache.spark.streaming.{Seconds, StreamingContext}

object CreateKafkaStream {

  def main(args: Array[String]): Unit = {


    //val spark = SparkSession.builder().appName("Kafka Integration").master("local[*]").getOrCreate()
    
    val sparkConf = new SparkConf().setAppName("test").setMaster("local[*]")
    // val sc = new SparkContext(sparkConf)
    val ssc = new StreamingContext(sparkConf, Seconds(20))

 /*   val text = ssc.textFileStream("/home/impadmin/sample")
    text.foreachRDD(rdd=>println(rdd.toString()))*/

    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> "localhost:9092",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "A",
      "enable.auto.commit" -> (false: java.lang.Boolean))


    /* val textDataFrame = spark.readStream.text("/home/impadmin/sample")

     textDataFrame.writeStream.format("kafka").option("topic", "topicName")

       .option("kafka.bootstrap.servers", "localhost:9092")

       .option("checkpointLocation", "/home/impadmin/logs")

       .start()*/



    val topics = Array("antim")

    val stream = KafkaUtils.createDirectStream[String, String](
      ssc,
      LocationStrategies.PreferConsistent, ConsumerStrategies.Subscribe[String, String](topics, kafkaParams))

    stream.foreachRDD(rdd => rdd.foreach(f => print("Values are " + f.key() + " " + f.value() + " " + f.partition())))
    ssc.start()
    ssc.awaitTermination()

    /*
        val mySchema = StructType(Array(

          StructField("id", IntegerType),

          StructField("name", StringType),

          StructField("year", IntegerType),

          StructField("rating", DoubleType),

          StructField("duration", IntegerType)

        ))
    */

    print("Program is running")
    //val streamingDataFrame = spark.readStream.schema(mySchema).csv("/home/impadmin/sample")

    /*  val textDataFrame = spark.readStream.text("/home/impadmin/sample")

      textDataFrame.writeStream.format("kafka").option("topic", "topicName")

        .option("kafka.bootstrap.servers", "localhost:9092")

        .option("checkpointLocation", "/home/impadmin/logs")

        .start()*/

    /* streamingDataFrame.selectExpr("CAST(id AS STRING) AS key", "to_json(struct(*)) AS value").writeStream.
       format("kafka")

       .option("topic", "topicName")

       .option("kafka.bootstrap.servers", "localhost:9092")

       .option("checkpointLocation", "/home/impadmin/logs")

       .start()*/


    //val outStream = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "topicName").load()

    // outStream.printSchema()

    // val output = outStream.selectExpr("CAST(value AS STRING)").select("value")

    /*
    val df1 = outStream.selectExpr("CAST(value AS STRING)", "CAST(timestamp AS TIMESTAMP)").as[(String, Timestamp)]

      .select(from_json($"value", mySchema).as("data"), $"timestamp")

      .select("data.*", "timestamp")*/

    //  df1.writeStream.format("console").option("truncate", "false").start().awaitTermination()
    /* output.writeStream.format("console")
       .option("truncate", "true")
       .start().awaitTermination()*/
  }
}
