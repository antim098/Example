package main.scala.StructuredStream;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class DeviceDataProducer extends Thread {

    private final KafkaProducer<Integer, String> producer;
    private final String topic;
    private final Boolean isAsync;
    FileWriter writer;
    List<Object> data = new ArrayList<>();
    static Properties prop = new Properties();


    public static final String KAFKA_SERVER_URL = "localhost";
    public static final int KAFKA_SERVER_PORT = 9092;
    public static final String CLIENT_ID = "SampleProducer";

    public DeviceDataProducer(String topic, Boolean isAsync) {
        Properties properties = new Properties();
        properties.put("bootstrap.servers", KAFKA_SERVER_URL + ":" + KAFKA_SERVER_PORT);
        properties.put("client.id", CLIENT_ID);
        properties.put("key.serializer", "org.apache.kafka.common.serialization.IntegerSerializer");
        properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        producer = new KafkaProducer<Integer, String>(properties);
        this.topic = topic;
        this.isAsync = isAsync;
    }

    public void run() {
        int messageNo = 1;


        while (messageNo > 0) {

            if (messageNo % 15 == 0) {

                Path path = Paths.get(prop.getProperty("Sstream.input.path").replace("file:/", "/") + (messageNo / 15) + ".json");
                try {
                    writer = new FileWriter(path.toFile());
                    for (Object str : data) {
                        writer.write(str.toString());
                    }

                    writer.close();
                    data.clear();
                    sleep((long) (Math.random() * 60000));

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }

            long pNo = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
            long bin = (long) Math.floor(Math.random() * 9_00_00L) + 1_00_00L;
            long bout = (long) Math.floor(Math.random() * 9_00_00L) + 1_00_00L;
            //  String messageStr = "{" + "phoneNo" + ":" + pNo + ",bytesIn:" + bin + ",bytesOut:" + bout + ",eventTime:2019-04-12 13:18:18.0010" + "}";
            String s = "{\"phoneNo\":" + pNo + ",\"bytesIn\":" + bin + ",\"bytesOut\":" + bout + ",\"eventTime\":\"2019-04-12 13:18:18.0010\"}";

            JsonParser jsonParser = new JsonParser();
            JsonElement element = jsonParser.parse(s);
            data.add(element);

            System.out.println(element);
            long startTime = System.currentTimeMillis();
            if (isAsync) { // Send asynchronously
                producer.send(new ProducerRecord<Integer, String>(topic,
                        messageNo,
                        s), new DemoCallBack(startTime, messageNo, s));
            } else { // Send synchronously
                try {
                    producer.send(new ProducerRecord<Integer, String>(topic,
                            messageNo,
                            s)).get();
                    System.out.println("Sent message: (" + messageNo + ", " + s + ")");
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                    // handle the exception
                }
            }
            ++messageNo;


        }
    }

    public static void main(String[] args) {
        DeviceDataProducer producer = new DeviceDataProducer("devices", false);
        if (args.length > 0) {
            InputStream is = null;
            try {
                is = new FileInputStream(args[0]);
                prop.load(is);
            } catch (FileNotFoundException e) {
                System.out.println("The specified file not found");
            } catch (IOException e) {
                e.printStackTrace();
            }
            producer.start();
        } else {
            System.out.println("Properties file needs to be passed in the argument");
        }
    }
}

class DemoCallBack implements Callback {

    private final long startTime;
    private final int key;
    private final String message;

    public DemoCallBack(long startTime, int key, String message) {
        this.startTime = startTime;
        this.key = key;
        this.message = message;
    }

    /**
     * onCompletion method will be called when the record sent to the Kafka Server has been acknowledged.
     *
     * @param metadata  The metadata contains the partition and offset of the record. Null if an error occurred.
     * @param exception The exception thrown during processing of this record. Null if no error occurred.
     */
    public void onCompletion(RecordMetadata metadata, Exception exception) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        if (metadata != null) {
            System.out.println(
                    "message(" + key + ", " + message + ") sent to partition(" + metadata.partition() +
                            "), " +
                            "offset(" + metadata.offset() + ") in " + elapsedTime + " ms");
        } else {
            exception.printStackTrace();
        }
    }


}

