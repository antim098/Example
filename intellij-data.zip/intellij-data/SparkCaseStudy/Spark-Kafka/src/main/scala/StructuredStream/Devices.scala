package main.scala.StructuredStream

import java.io.{FileInputStream, InputStream}
import java.sql.Timestamp
import java.util.Properties

import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object Devices {
  def main(args: Array[String]) = {
    if (args.length > 0) {
      val is: InputStream = new FileInputStream(args(0))
      val prop: Properties = new Properties();
      prop.load(is)

      val spark = SparkSession.builder().appName("Kafka Integration").master("local[*]").getOrCreate()
      spark.sparkContext.setLogLevel("ERROR")
      val jsonSchema = StructType(
        Array(
          StructField("phoneNo", StringType, true),
          StructField("bytesIn", LongType, true),
          StructField("bytesOut", LongType, true),
          StructField("eventTime", StringType, true)
        ))


      val streamingDataFrame = spark.readStream.schema(jsonSchema).json( prop.getProperty("Sstream.input.path"))

      streamingDataFrame.selectExpr("to_json(struct(*)) AS value").writeStream.format("kafka").option("topic", "devices")
        .option("kafka.bootstrap.servers", "localhost:9092")
        .option("checkpointLocation", prop.getProperty("checkpoint.deviceckp")) //.trigger(Trigger.ProcessingTime(60, TimeUnit.SECONDS))
        .start()


      val outStream = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "devices").option("checkpointLocation", prop.getProperty("checkpoint.deviceckp1")).load();


      import org.apache.spark.sql.functions._
      import spark.implicits._
      val df1 = outStream.selectExpr("CAST(value AS STRING)", "CAST(timestamp AS TIMESTAMP)").as[(String, Timestamp)]
        .select(from_json($"value", jsonSchema).as("data"), $"timestamp").select("data.*", "timestamp")

      df1.printSchema()


      val reqDF = df1.select($"phoneNo", $"bytesIn", $"bytesOut", ($"timestamp").as("eventTime")).withColumn("Total bytes", col("bytesIn") + col("bytesOut")).withWatermark("eventTime", "60 minutes")
        .groupBy(window($"eventTime", "20 seconds"), $"Total bytes", $"phoneNo").count()
        .select("window", "Total bytes", "phoneNo")


      val query = reqDF.writeStream.trigger(Trigger.ProcessingTime("20 seconds")).foreachBatch {
        (batchDF: DataFrame, batchId: Long) =>
          val resDF = batchDF.orderBy(col("Total bytes").desc).select("window", "Total bytes", "phoneNo").limit(10)
          //  resDF.show(false)
          resDF.coalesce(1).write.mode("Append").format("json").save(prop.getProperty("Sstream.results.path") + batchId.toString())
      }.start()

      query.awaitTermination()
    }

    else {
      System.out.println("Properties file needs to be passed in the argument")
    }
  }
}