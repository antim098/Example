package main.scala.SparkStream;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class ReadDirectories {
    public static void main(String[] args) throws IOException {
        if (args.length > 0) {
            InputStream is = new FileInputStream(args[0]);
            Properties prop = new Properties();
            prop.load(is);

            String inputFilepath = prop.getProperty("deployment.center.path");
            String directoryPath = inputFilepath;
            String[] directories = new File(directoryPath).list();
            List dirNames = Arrays.asList(directories);
            Iterator itr = dirNames.iterator();
            Path path = Paths.get(prop.getProperty("summary.file.path"));
            FileWriter writer = new FileWriter(path.toFile());
            writer.flush();
            writer.append("Timestamp" + "\t\t" + "DCID");
            StringBuilder fileContent = new StringBuilder();
            while (itr.hasNext()) {
                String timeStamp = itr.next().toString();
                Path inputDir = Paths.get(directoryPath + timeStamp);

                File dir = new File(String.valueOf(inputDir));
                if (Files.isDirectory(inputDir)) {
                    List<String> fileNames = null;

                    String[] names = dir.list(new FilenameFilter() {
                        @Override
                        public boolean accept(File dir, String name) {
                            return name.endsWith(".csv");
                        }
                    });
                    fileNames = Arrays.asList(names);
                    for (String fileName : fileNames) {
                        try (FileReader fileReader = new FileReader(inputDir + "/" + fileName); BufferedReader bufferedReader = new BufferedReader(fileReader)) {
                            String line = null;
                            while ((line = bufferedReader.readLine()) != null) {
                                fileContent.append(" " + line);
                            }
                        } catch (FileNotFoundException ex) {
                            // log.error("Unable to open file {} \n Path Wrong or File Dosen't Exists", filePath);
                        } catch (IOException e) {
                            //  log.error("Error reading file {}", filePath);
                            // Or we could just do this:

                        }

                    }
                    String output = timeStamp + "\t" + fileContent.toString();
                    writer.append("\n" + output);
                    System.out.println(output);
                }
                fileContent.setLength(0);
            }
            writer.close();

        } else {
            System.out.println("Properties file needs to be passed in the argument");

        }
    }
}


