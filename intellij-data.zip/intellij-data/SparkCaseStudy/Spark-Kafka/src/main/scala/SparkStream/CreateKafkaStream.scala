package main.scala.SparkStream

import java.io.{FileInputStream, InputStream}
import java.time.format.DateTimeFormatter
import java.time.{Instant, ZoneId}
import java.util.Properties

import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.streaming._
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, KafkaUtils, LocationStrategies}

object CreateKafkaStream {

  def main(args: Array[String]): Unit = {
    if (args.length > 0) {
      val is: InputStream = new FileInputStream(args(0))
      val prop: Properties = new Properties();
      prop.load(is)

      val sparkConf = new SparkConf().setAppName("test").setMaster("local[*]")

      val ssc = new StreamingContext(sparkConf, Seconds(60))

      val sql = new HiveContext(ssc.sparkContext)

      ssc.sparkContext.setLogLevel("ERROR")
      //Setting the Logger level of default logger used by Spark
      val kafkaParams = Map[String, Object](
        "bootstrap.servers" -> "localhost:9092",
        "key.deserializer" -> classOf[StringDeserializer],
        "value.deserializer" -> classOf[StringDeserializer],
        "group.id" -> "A",
        "enable.auto.commit" -> (false: java.lang.Boolean))

      val topics = Array("website")

      val stream = KafkaUtils.createDirectStream[String, String](
        ssc,
        LocationStrategies.PreferConsistent, ConsumerStrategies.Subscribe[String, String](topics, kafkaParams))

      stream.foreachRDD((rdd, time) => {
        val StringRdd = rdd.map(x => x.value())
        val batchTime = s"${returnFormattedTime(time.milliseconds)}"
        if (!StringRdd.isEmpty()) {
          val result = sql.read.json(StringRdd)
          var df = result.toDF()
          print("Time of Batch is " + s"${returnFormattedTime(time.milliseconds)}")
          println("Data for the batch")
          df.show(false)
          df.coalesce(1).select("userid").distinct().as("Distinct Users").write.mode(SaveMode.Append).csv(prop.getProperty("dstream.uniqueUsers.path") + s"${returnFormattedTime(time.milliseconds)}")
          df.coalesce(1).select("dcid").groupBy("dcid").count().select("dcid").filter("count>=250").write.mode(SaveMode.Append).csv(prop.getProperty("dstream.deploymentCenters.path") + s"${returnFormattedTime(time.milliseconds)}")
          println("Written Data to file")
        }
        else {
          StringRdd.saveAsTextFile(prop.getProperty("dstream.uniqueUsers.path") + s"${returnFormattedTime(time.milliseconds)}")
          StringRdd.saveAsTextFile(prop.getProperty("dstream.deploymentCenters.path") + s"${returnFormattedTime(time.milliseconds)}")
          println("No Data Found. Empty file")
        }
      }
      )
      ssc.start()
      ssc.awaitTermination()
    } else {
      System.out.println("Properties file needs to be passed in the argument")
    }
  }

  def returnFormattedTime(ts: Long): String = {
    val date = Instant.ofEpochMilli(ts)
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault())
    val formattedDate = formatter.format(date)
    formattedDate
  }

}
