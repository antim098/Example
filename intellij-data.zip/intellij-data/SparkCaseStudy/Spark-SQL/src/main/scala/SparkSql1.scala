package CaseStudy

import java.io.{FileInputStream, InputStream}
import java.util.Properties

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.{col, split}

object SparkSql1 {


  def main(args: Array[String]) = {

    if (args.length > 0) {
      val is: InputStream = new FileInputStream(args(0))
      val prop: Properties = new Properties();
      prop.load(is)

      val spark = org.apache.spark.sql.SparkSession.builder
        .master("local")
        .appName("Spark CSV Reader")
        .getOrCreate

      val DF = spark.read.format("csv").option("header", "true").load(prop.getProperty("spark.sql1.input"))

      DF.createOrReplaceTempView("inpatientcharges")

      spark.sql("select * from inpatientcharges").show(150)

      val stateAvgCharges = spark.sql("select ProviderState,round(avg(AverageCoveredCharges),2) as AverageStateCoveredCharges from inpatientcharges group by ProviderState")

      stateAvgCharges.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(prop.getProperty("spark.sql1.results") + "stateAvgCharges")

      val stateAvgTotalPayments = spark.sql("select ProviderState,round(avg(AverageTotalPayments),2) as AverageStateTotalPayments from inpatientcharges group by ProviderState")

      stateAvgTotalPayments.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(prop.getProperty("spark.sql1.results") + "stateAvgTotalPayments")

      val avgMedicare = spark.sql("select ProviderState,round(avg(AverageMedicarePayments),2) as AverageMedicarePayments from inpatientcharges group by ProviderState")

      avgMedicare.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(prop.getProperty("spark.sql1.results") + "avgMedicarePayments")


      val StatewithDisease = DF.withColumn("disease", split(col("DRGDefinition"), "\\-").getItem(1))
      StatewithDisease.createOrReplaceTempView("StatewithDisease")

      val DischargePerState = spark.sql("SELECT CONCAT(ProviderState, ':',disease) as state_disease,sum(TotalDischarges) as Total_State_Discharges from StatewithDisease group by state_disease order by " +
        "Total_State_Discharges desc")

      DischargePerState.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(prop.getProperty("spark.sql1.results") + "dischargePerState")

    } else {
      System.out.println("Properties file needs to be passed in the argument")
    }
  }

}
