package CaseStudy

import java.io.{FileInputStream, InputStream}
import java.util.Properties

import org.apache.spark.sql.SaveMode

object SparkSql2 {


  def main(args: Array[String]) = {
    if (args.length > 0) {
      val is: InputStream = new FileInputStream(args(0))
      val prop: Properties = new Properties();
      prop.load(is)

      val spark = org.apache.spark.sql.SparkSession.builder
        .master("local")
        .appName("Spark CSV Reader")
        .getOrCreate

      import org.apache.spark.sql.functions._

      //Reading CSV files into respective Dataframes
      val problems = spark.read.format("csv").option("header", "true").load(prop.getProperty("spark.sql2.inputdf1"))
      val state_info = spark.read.format("csv").option("header", "true").load(prop.getProperty("spark.sql2.inputdf2"))

      //Splitting column value of title and creating new column named type
      val type_problems = problems.withColumn("type", split(col("title"), "\\:").getItem(0))

      //Registering temporary tables for the dataframes
      type_problems.createOrReplaceTempView("type_problems")
      state_info.createOrReplaceTempView("state_info")

      //Statewise type of problems and their count
      val statewiseProblems = spark.sql("SELECT CONCAT(i.state, ':', p.type) as state_type,count(*) as count from type_problems p join state_info i on p.zip=i.zip group by state_type order by count desc")

      statewiseProblems.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(prop.getProperty("spark.sql2.results") + "statewiseProblems")

      val citywiseProblems = spark.sql("SELECT CONCAT(i.city, ':', p.type) as city_type,count(*) as count from type_problems p join state_info i on p.zip=i.zip group by city_type order by count desc")
      citywiseProblems.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(prop.getProperty("spark.sql2.results") + "citywiseProblems")

    } else {
      System.out.println("Properties file needs to be passed in the argument")
    }
  }

}

