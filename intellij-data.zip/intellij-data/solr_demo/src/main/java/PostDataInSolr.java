public class PostDataInSolr {
    public static void main(String[] args) {

    }

}
