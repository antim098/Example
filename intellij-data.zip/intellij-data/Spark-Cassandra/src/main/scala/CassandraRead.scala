package main.scala


import com.datastax.spark.connector.cql.CassandraConnectorConf
import main.spark.{CassandraConnector, CassandraWriter}
import org.apache.spark.api.java.function.ForeachPartitionFunction
import org.apache.spark.sql.cassandra._
import org.apache.spark.sql.{Row, SQLContext, SparkSession}

import scala.collection.JavaConversions._

object CassandraRead {

  def main(args: Array[String]) = {

    val spark = SparkSession.builder().appName("Cassandra Integration").master("local[*]").getOrCreate()
    spark.setCassandraConf("Cluster1", CassandraConnectorConf.ConnectionHostParam.option("localhost") ++ CassandraConnectorConf.ConnectionPortParam.option(9042))
    val testdf = spark.read.format("org.apache.spark.sql.cassandra").options(Map("table" -> "test", "keyspace" -> "test", "pushdown" -> "true")).load()
    //testdf.where(expr("sku_num = 'A1253499' and catalog_id = '1'"))
    testdf.show()
    System.out.println(testdf.schema)
    val sqlContext = new SQLContext(spark.sparkContext)
    //    val castdf = testdf.withColumn("raw_ts", castUUID(col("raw_ts"))
    //    )
    //System.out.println(castdf.schema)
    val columnNames = testdf.columns.toList
    val driverInsert = new CassandraDriverInsert();
    dell_ctl.foreach(row => driverInsert.insert("test", "five_m_copy", columnNames, row.toSeq.asInstanceOf[Seq[Object]].toList))
    //val cassandraWriter = new CassandraWriter();
    testdf.foreach(row => CassandraWriter.insert("test", "test1", columnNames, row.toSeq.asInstanceOf[Seq[Object]].toList))
    //SaveToCassandra.save(testdf,"test","spark_test1")
   // System.out.println("Success Records " + CassandraDriverInsert.getProcessedRecordCount())
    //System.out.println("Failed Records " + CassandraDriverInsert.getFailedRecordCount)
    //var count = 1;
    // val newRDD = testdf.rdd.map(row => extraCol(row.toSeq, count))

  }

  //  def extraCol(r: Seq[Any], count: Int): Row = {
  //    val length = r.length
  //    var value = if (count % 20 == 0) 20 else count % 20
  //    r.add(value)
  //    Row.fromSeq(r)
  //  }

  //  def convertUUID(string: String): UUID = {
  //    UUID.fromString(string)
  //  }

  //  val castUUID: UserDefinedFunction = udf((string: String) => {
  //    UUID.fromString(string)
  //  })

}
