package main.java;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Session;
import main.spark.CassandraConnector;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

public class CassandraDriverInsert implements Serializable {

    private final static Logger LOGGER = Logger.getLogger(CassandraDriverInsert.class.getName());
    public static long totalProcessedRecords = 0;
    public static long processedRecords = 0;
    public static long failedRecords = 0;
    public static List<BoundStatement> BoundStatementList = new CopyOnWriteArrayList<>();
    public static ConcurrentHashMap<String, PreparedStatement> preparedStatementMap = new ConcurrentHashMap<>();
    //public static ConcurrentHashMap<BoundStatement, String> BoundStatementList = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String, String> insertQueryStatement = new ConcurrentHashMap<>();
    public static Queue<BoundStatement> BoundStatementQueue = new ConcurrentLinkedQueue<BoundStatement>();
    public static Session session = null;
    private static long batchEvaluationTime = Instant.now().toEpochMilli();
    private static ThreadPoolExecutor threadPoolExecutor =
            new ThreadPoolExecutor(1, 1, 30, TimeUnit.SECONDS, new LinkedBlockingDeque<>());

    //    public static void CassandraDriverInsert() {
//        if (session == null) {
//            CassandraConnector.connect(9042);
//            session = CassandraConnector.getSession();
//            System.out.println("Created session " + session.getState());
//        }
//    }
    static {
        LOGGER.info("Initializing Cassandra Insert");
    }

    public static long getProcessedRecordCount() {
        return processedRecords;
    }

    public static long getFailedRecordCount() {
        return failedRecords;
    }

    /**
     * @param keySpace
     * @param tableName
     * @param columnNames
     * @param columnValues
     */
    public static void insert(String keySpace, String tableName, List<String> columnNames, List<Object> columnValues) {
        Session session = null;
        try {
//            if (session == null) {
//                CassandraConnector.connect(9042);
//                session = CassandraConnector.getSession();
//                System.out.println("Created session " + session.getState());
//            }
            session = CassandraConnector.connect();
            System.out.println("Column names " + columnNames.toString());
            System.out.println("Column Values " + columnValues.toString());
            System.out.println("Generating prepared statement");
            PreparedStatement prepared = getPreparedStatement(session, keySpace, tableName, columnNames);
            System.out.println("Prepared Statement Generated" + prepared.getQueryString());
            BoundStatement bound = prepared.bind();
            if (((Instant.now().toEpochMilli() - batchEvaluationTime) / 1000) < 10) {
                executeBatchAsync(session);
            }
            //executeBatchAsync(session);
            //Session finalSession = session;
            BoundStatementList.add(loadIngestionBoundStatement(columnNames, columnValues, bound));
            //session.executeAsync(loadIngestionBoundStatement(columnNames, columnValues, bound));
            processedRecords++;
            if (processedRecords % 1000 == 0)
                LOGGER.info("Inserted 1000000 records. Total Records inserted = " + processedRecords +
                        "\n Total Failed Records = " + failedRecords);
        } catch (Exception e) {
            LOGGER.error("[" + CassandraDriverInsert.class + "] Exception occurred while trying to execute cassandra insert: " +
                    e.getMessage(), e);
            failedRecords++;
        } finally {
            //CassandraConnector.closeSession(session);
        }
    }


//    public static synchronized void executeBatchAsync(Session session) {
////        if (BoundStatementList.size() == 999) {
////            CopyOnWriteArrayList<BoundStatement> executionList = new CopyOnWriteArrayList<>(BoundStatementList.subList(0, 999));
////            BoundStatementList.subList(0, 999).clear();
////            for (BoundStatement statement : executionList) {
////                session.executeAsync(statement);
////            }
////            LOGGER.info("[" + CassandraDriverInsert.class.getName() + "] Processed 10,000 records");
////        }
////    }

//    public static void executeBatchAsync(Session session) {
//        if (BoundStatementList.size() == 100) {
//            //CopyOnWriteArrayList<BoundStatement> executionList = new CopyOnWriteArrayList<>(BoundStatementList.subList(0, 10000));
//            //BoundStatementList.subList(0, 10000).clear();
//            for (int i = 0; i < 100; i++) {
//                session.executeAsync(BoundStatementList.get(i));
//            }
//            BoundStatementList.subList(0, 100).clear();
//            LOGGER.info("[" + CassandraDriverInsert.class.getName() + "] Processed 100 records");
//        }
//    }

    public static synchronized void executeBatchAsync(Session session) {
        //long size = BoundStatementList.size();
        if (BoundStatementList.size() >= 100) {
            batchEvaluationTime = Instant.now().toEpochMilli();
            BoundStatementQueue.addAll(BoundStatementList.subList(0, 100));
            BoundStatementList.subList(0, 100).clear();
            for (BoundStatement boundStatement : BoundStatementQueue) {
                session.executeAsync(boundStatement);
            }
            BoundStatementQueue.clear();
//            for (int i = 0; i < size; i++) {
//                session.executeAsync(BoundStatementList.get(i));
//            }

            //BoundStatementList.subList(0, (int) size).clear();
            LOGGER.info("[" + CassandraDriverInsert.class.getName() + "] Processed 10,000 records");
        }
    }


    /**
     * @param columnNames
     * @param columnValues
     * @param boundStatement
     * @return
     */
    private static BoundStatement loadBoundStatement(List<String> columnNames, List<Object> columnValues, BoundStatement boundStatement) {
        ArrayList<String> names = new ArrayList<>();
        ArrayList<Object> values = new ArrayList<>();
        for (int i = 0; i < columnNames.size(); i++) {
            String name = columnNames.get(i);
            Object value = columnValues.get(i);
            if (value != null && value != "") {  // Skipping tombstones
                if (name.equalsIgnoreCase("ts")) {
                    boundStatement.setUUID(name, (UUID) value);
                } else {
                    boundStatement.setString(name, value.toString());
                }
            }
        }
        return boundStatement;
    }

    /**
     * @param columnNames
     * @param columnValues
     * @param boundStatement
     * @return
     */
    private static BoundStatement loadIngestionBoundStatement(List<String> columnNames, List<Object> columnValues, BoundStatement boundStatement) {
        //ArrayList<String> names = new ArrayList<>();
        //ArrayList<Object> values = new ArrayList<>();


        for (int i = 0; i < columnNames.size(); i++) {
            String name = columnNames.get(i);
            Object value = columnValues.get(i);
            if (value != null && value != "") {  // Skipping tombstones
                if (name.equals("raw_ts") || name.equals("ts")) {
                    boundStatement.setUUID(name, UUID.fromString(value.toString()));
                } else if (value instanceof Integer) {
                    boundStatement.setInt(name, (Integer) value);
                } else if (value instanceof Date) {
                    boundStatement.setTimestamp(name, (Date) value);
                } else if (value instanceof UUID) {
                    boundStatement.setUUID(name, (UUID) value);
                } else if (value instanceof Double) {
                    boundStatement.setDouble(name, (Double) value);
                } else if (value instanceof Long || value instanceof BigInteger) {
                    boundStatement.setLong(name, (Long) value);
                } else {
                    boundStatement.setString(name, value.toString());
                }
            }
        }
        //System.out.println("Bound Statement "+ boundStatement.toString());
        return boundStatement;
    }

    /**
     * @param session
     * @param keyspace
     * @param tableName
     * @param columnNames
     * @return
     */
    private static PreparedStatement getPreparedStatement(final Session session, final String keyspace, final String tableName, final List<String> columnNames) {
        System.out.println("Inside prepared statement");
        if (preparedStatementMap.get(tableName) == null) {
            preparedStatementMap.put(tableName, session.prepare(
                    prepareQueryString(keyspace, tableName, columnNames)));
        }
        System.out.println("Outside prepared statement");
        return preparedStatementMap.get(tableName);
    }

    /**
     * @param keyspace
     * @param tableName
     * @param columnNames
     * @return
     */
    private static String prepareQueryString(final String keyspace, final String tableName, final List<String> columnNames) {
        if (insertQueryStatement.get(tableName) == null) {
            System.out.println("Inside prepare Query String ");
            StringBuilder queryStringBuilder = new StringBuilder("INSERT INTO " + keyspace + "." + tableName + " (");
            StringBuilder valueBuilder = new StringBuilder("(");
            for (int i = 0; i < columnNames.size(); i++) {
                queryStringBuilder.append(columnNames.get(i));
                valueBuilder.append("?");
                if (i < columnNames.size() - 1) {
                    queryStringBuilder.append(", ");
                    valueBuilder.append(", ");
                } else {
                    queryStringBuilder.append(")");
                    valueBuilder.append(")");
                }
            }
            queryStringBuilder.append(" VALUES ").append(valueBuilder);
            System.out.println("InsertQueryStatement " + queryStringBuilder.toString());
            LOGGER.info("InsertQueryStatement " + queryStringBuilder.toString());
            insertQueryStatement.put(tableName, queryStringBuilder.toString());
        }
        System.out.println("insert statement inside map is  " + insertQueryStatement.get(tableName));
        return insertQueryStatement.get(tableName);
    }
}
