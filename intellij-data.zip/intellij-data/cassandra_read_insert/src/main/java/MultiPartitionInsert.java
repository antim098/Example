import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Session;
import javafx.scene.chart.ScatterChart;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.lang.System.clearProperty;
import static java.lang.System.out;

public class MultiPartitionInsert {
    public static void main(String[] args) throws IOException {

        long file_count = 0;
        String filePath = args[0];
        int iterations = Integer.parseInt(args[1]);
        String tableName = args[2];
        List<String> result = new ArrayList<>();
        DecimalFormat df2 = new DecimalFormat("#.####");
        String[] dates = {"1700-03-05", "1650-01-22", "2019-07-04", "2090-05-05", "2040-08-12", "2013-03-09", "1580-04-18", "1900-06-26", "1890-09-01", "1650-11-28"};
        String previous = null;

        ////File Read
        FileInputStream fis = new FileInputStream(filePath);
        byte[] b = new byte[fis.available() + 1];
        int length = b.length;
        fis.read(b);
        //We now need to convert the byte array into a bytebuffer:
        ByteBuffer buffer = ByteBuffer.wrap(b);

        //////Cassandra Connect
        final CassandraConnector client = new CassandraConnector();
        final String ipAddress = "127.0.0.1"; //args.length > 0 ? args[0] :
        final int port = 9042;
        client.connect(port);
        double total_time = 0;
        for (int i = 1; i <= iterations; i++) {
            Random r = new Random();
            int id = r.nextInt(99999);
            String date = getRandom(dates, previous);
            previous = date;

            //out.println("Start Time :" + start_time);
            //out.println("Ingesting File: ");
//            File pdfFile = new File(filePath);
//            byte[] pdfData = new byte[(int) pdfFile.length()];
//            DataInputStream dis = new DataInputStream(new FileInputStream(pdfFile));
//            dis.readFully(pdfData);  // read from file into byte[] array
//            //System.out.println("Size in bytes: " + pdfData.length);
//            dis.close();
//            ByteBuffer buffer = ByteBuffer.wrap(pdfData);

            Timestamp start_time = new Timestamp(System.currentTimeMillis());
            try {
                if (buffer != null && buffer.limit() == buffer.capacity()) {
                    String query = "insert into test." + tableName + "(id,data,date) values(?,?,?)";
                    PreparedStatement ps = client.getSession().prepare(query);
                    BoundStatement boundStatement = new BoundStatement(ps);
                    client.getSession().execute(boundStatement.bind(id, buffer, date));
//                client.getSession().execute(
//                        "INSERT INTO test.size_stats (id, data) VALUES (?, ?)",
//                        id, buffer);
                    //out.println("End Time :" + end_time);
                    Timestamp end_time = new Timestamp(System.currentTimeMillis());
//            out.println("Record added in Cassandra");
//            out.println("Id is :" + id);
                    total_time = total_time + (end_time.getTime() - start_time.getTime());
//            out.println("Time Taken:" + df2.format(time_taken / 1000));
                    file_count++;
                    out.println(file_count + " files inserted in partition " + date);
                } else {
                    out.println("Byte buffer object has become null");
                    break;
                }
            } catch (Exception e) {
                out.println("...........Exception occured.......");
                e.printStackTrace();
                System.exit(0);
            }
        }

        out.println("No of times file inserted = " + file_count);
        out.println("Time Taken taken: " + df2.format(total_time / (1000 * 60)) + " mins");
        client.close();
        //dis.close();
        System.exit(0);
    }


    public static String getRandom(String[] array, String previous) {
        int rnd = new Random().nextInt(array.length);
        String new_date = array[rnd];
        while (new_date == previous) {
            new_date = array[new Random().nextInt(array.length)];
        }
        return new_date;
    }


}


