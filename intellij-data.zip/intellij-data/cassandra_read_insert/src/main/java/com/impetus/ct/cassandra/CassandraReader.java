package com.impetus.ct.cassandra;

import java.util.Arrays;

import com.impetus.ct.cassandra.connection.CassandraSessions;

public class CassandraReader {
	public static void main(String[] args) {
		System.setProperty("com.datastax.driver.NATIVE_TRANSPORT_MAX_FRAME_SIZE_IN_MB", "2046");
		System.out.println("** Arguments Received  ***" + Arrays.toString(args));
		if (args.length < 1) {
			System.out.println("***** First Argument should be comma separated IP Address*****");
			return;
		}
		String cassandraHosts = args[0];
		System.out.println("Cassandra session is created using  hosts." + cassandraHosts);
		CassandraSessions sessions = new CassandraSessions(9042, cassandraHosts.split(","));
		System.out.println("Cassandra sessions created using  hosts." + cassandraHosts);

		String batchSize = args[1];
		String queryParameter = args[2];
		if (queryParameter.toLowerCase().contains("limit")) {
			CassandraQuery query = new CassandraSelectQuery();
			query.execute(queryParameter, batchSize, sessions);
		}
		System.out.println("** processing completed****");
	}
}
