package com.impetus.ct.cassandra;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.impetus.ct.cassandra.connection.CassandraSessions;
import com.datastax.driver.core.*;

import static java.lang.System.out;

public class CassandraSelectQuery implements CassandraQuery {

	@Override
	public void execute(String inputQuery, String batchSize, CassandraSessions sessions) {

		System.out.println("Input Query to be executed -- " + inputQuery);

		final ExecutorService pool = Executors.newFixedThreadPool(sessions.size()+1);
		final ExecutorCompletionService<Long> completionService = new ExecutorCompletionService<>(pool);

		String[] inputQueryArray = inputQuery.split("limit");
		String newLimitQuery = inputQueryArray[0] + "limit ";

		Long queryLimitEnd = new Long(inputQueryArray[1].trim());
		Long fraction = queryLimitEnd / sessions.size();

		List<Future<Long>> futures = new ArrayList<>();

		long queryLimitStart = 0;
		while (queryLimitStart < queryLimitEnd) {
			String query = newLimitQuery + fraction;
			SelectQueryCallable callable = new SelectQueryCallable(sessions.getCassandraSession().getSession(), query,
					new Integer(batchSize));
			futures.add(completionService.submit(callable));

			// handle in case any limit is left less than fraction.
			queryLimitStart = queryLimitStart + fraction;
			if ((queryLimitEnd - queryLimitStart) < fraction && (queryLimitEnd - queryLimitStart) >0) {
				queryLimitStart = queryLimitEnd - queryLimitStart;
//				query = newLimitQuery + queryLimitStart;
//				callable = new SelectQueryCallable(sessions.getCassandraSession().getSession(), query,
//						new Integer(batchSize));
//				futures.add(completionService.submit(callable));
				queryLimitStart = queryLimitEnd;
			}
		}
		System.out.println("****** All queries submitted for processing ******");
		long resultCount = 0;
		for (Future<Long> future : futures) {
			try {
				Future<Long> completedFuture = completionService.take();
				resultCount = resultCount + (long) completedFuture.get();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		sessions.closeSessions();
		pool.shutdown();
		pool.shutdownNow();
		System.out.println("****** Total Records fetched are: " + resultCount);

	}

}

class SelectQueryCallable implements Callable<Long> {
	private Session session;
	private String query;
	private int resultsPerBatch;

	SelectQueryCallable(Session session, String query, int resultsPerBatch) {
		this.session = session;
		this.query = query;
		this.resultsPerBatch = resultsPerBatch;
	}

	@Override
	public Long call() throws Exception {
		Statement st = new SimpleStatement(query);
		st.setFetchSize(resultsPerBatch);
		long startTime = System.currentTimeMillis();

		ResultSet rs = session.execute(st);
		while (!rs.isFullyFetched()) {
			rs.fetchMoreResults();
		}
		long record_count = rs.all().size();
		long endTime = System.currentTimeMillis();
		System.out.println(Thread.currentThread().getName() + " - thread finished query " + query
				+ " execution on cluster " + session.getCluster().getMetadata().getClusterName() + "  in time(ms) --"
				+ (endTime - startTime));
		return record_count;
	}

}