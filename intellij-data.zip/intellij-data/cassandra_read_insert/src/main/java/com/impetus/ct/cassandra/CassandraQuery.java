package com.impetus.ct.cassandra;

import com.impetus.ct.cassandra.connection.CassandraSessions;

public interface CassandraQuery {

	public void execute(String queryOrlimits, String batchSize, CassandraSessions sessions);
}
