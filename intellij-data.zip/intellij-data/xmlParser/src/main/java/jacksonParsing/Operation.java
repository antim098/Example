package jacksonParsing;

public class Operation {
    public Operation() {
    }

    private OperationEntry operationEntry;

    public Operation(OperationEntry operationEntry) {
        this.operationEntry = operationEntry;
    }

    public OperationEntry getOperationEntry() {
        return operationEntry;
    }

    public void setOperationEntry(OperationEntry operationEntry) {
        this.operationEntry = operationEntry;
    }
}

class OperationEntry {
    public String getName() {
        return name;
    }

    public OperationEntry() {
    }

    public OperationEntry(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    private String name;
    private String value;
}