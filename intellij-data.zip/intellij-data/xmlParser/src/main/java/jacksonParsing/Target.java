package jacksonParsing;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class Target {

    @JacksonXmlElementWrapper(localName = "customer", useWrapping = true)
    private Customer customer;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Target() {
    }
}

class Customer {
    @JacksonXmlElementWrapper(localName = "pnrId", useWrapping = true)
    private PnrId pnr;

    @JacksonXmlElementWrapper(localName = "name", useWrapping = true)
    private Name name;

    @JacksonXmlElementWrapper(localName = "loyalty", useWrapping = true)
    private Loyalty loyalty;
    private Contact contact;
    private Presentation presentation;
    private String deliverPreferenceAttempted;
    private String isIntendedTarget;
    private String isEffectiveTarget;

    public Customer() {
    }

    public Customer(PnrId pnr, Name name, Loyalty loyalty, Contact contact, Presentation presentation, String deliverPreferenceAttempted, String isIntendedTarget, String isEffectiveTarget) {
        this.pnr = pnr;
        this.name = name;
        this.loyalty = loyalty;
        this.contact = contact;
        this.presentation = presentation;
        this.deliverPreferenceAttempted = deliverPreferenceAttempted;
        this.isIntendedTarget = isIntendedTarget;
        this.isEffectiveTarget = isEffectiveTarget;
    }

    public String getIsIntendedTarget() {
        return isIntendedTarget;
    }

    public void setIsIntendedTarget(String isIntendedTarget) {
        this.isIntendedTarget = isIntendedTarget;
    }

    public String getIsEffectiveTarget() {
        return isEffectiveTarget;
    }

    public void setIsEffectiveTarget(String isEffectiveTarget) {
        this.isEffectiveTarget = isEffectiveTarget;
    }

    public PnrId getPnr() {
        return pnr;
    }

    public void setPnr(PnrId pnr) {
        this.pnr = pnr;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public Loyalty getLoyalty() {
        return loyalty;
    }

    public void setLoyalty(Loyalty loyalty) {
        this.loyalty = loyalty;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public Presentation getPresentation() {
        return presentation;
    }

    public void setPresentation(Presentation presentation) {
        this.presentation = presentation;
    }

    public String getDeliverPreferenceAttempted() {
        return deliverPreferenceAttempted;
    }

    public void setDeliverPreferenceAttempted(String deliverPreferenceAttempted) {
        this.deliverPreferenceAttempted = deliverPreferenceAttempted;
    }

    @Override
    public String toString() {

        return "Customer{" +

                "pnr='" + pnr.getPnrLocator() + '\'' +

                ", firstName='" + name.getGiven() + '\'' +

                ", lastName='" + name.getFamily() + '\'' +

                '}';

    }
}


class PnrId {


    private String pnrLocator;

    private String pnrHolderNumber;

    public String getPnrLocator() {
        return pnrLocator;
    }

    public void setPnrLocator(String pnrLocator) {
        this.pnrLocator = pnrLocator;
    }

    public PnrId() {
    }

    public PnrId(String pnrLocator, String pnrHolderNumber) {
        this.pnrLocator = pnrLocator;
        this.pnrHolderNumber = pnrHolderNumber;
    }

    public String getPnrHolderNumber() {
        return pnrHolderNumber;
    }

    public void setPnrHolderNumber(String pnrHolderNumber) {
        this.pnrHolderNumber = pnrHolderNumber;
    }

}

class Name {

    public Name() {

    }

    @JacksonXmlProperty(localName = "family")
    private String family;
    @JacksonXmlProperty(localName = "given")
    private String given;

    public Name(String given, String family) {
        this.given = given;
        this.family = family;
    }

    public String getGiven() {
        return given;
    }

    public void setGiven(String given) {
        this.given = given;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }
}


class Loyalty {

    private Club club;

    public Club getClub() {
        return club;
    }

    public void setClub(Club club) {
        this.club = club;
    }

    public Loyalty() {
    }
}

class Contact {

    @JacksonXmlElementWrapper(localName = "contactEntry", useWrapping = false)
    private ContactEntry[] contactEntry;

    public Contact() {
    }

    public ContactEntry[] getContactEntry() {
        return contactEntry;
    }

    public void setContactEntry(ContactEntry[] contactEntry) {
        this.contactEntry = contactEntry;
    }

    public Contact(ContactEntry[] contactEntry) {
        this.contactEntry = contactEntry;
    }
}

class ContactEntry {

    public ContactEntry() {
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public ContactEntry(String source, Phone phone, Email email) {
        this.source = source;
        this.phone = phone;
        this.email = email;
    }

    public Phone getPhone() {
        return phone;
    }

    public void setPhone(Phone phone) {
        this.phone = phone;
    }

    public Email getEmail() {
        return email;
    }

    public void setEmail(Email email) {
        this.email = email;
    }

    private String source;
    private Phone phone;
    private Email email;

}

class Phone {

    private String type;
    private String numericCountryCode;
    private String number;
    private String isOptedOut;
    private String deliverPreference;
    private String countryCode;
    private DeliverMessages deliverMessages;

    public DeliverMessages getDeliverMessages() {
        return deliverMessages;
    }

    public void setDeliverMessages(DeliverMessages deliverMessages) {
        this.deliverMessages = deliverMessages;
    }


    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Phone() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNumericCountryCode() {
        return numericCountryCode;
    }

    public void setNumericCountryCode(String numericCountryCode) {
        this.numericCountryCode = numericCountryCode;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getIsOptedOut() {
        return isOptedOut;
    }

    public void setIsOptedOut(String isOptedOut) {
        this.isOptedOut = isOptedOut;
    }

    public String getDeliverPreference() {
        return deliverPreference;
    }

    public void setDeliverPreference(String deliverPreference) {
        this.deliverPreference = deliverPreference;
    }

}

class DeliverMessages {
    public DeliverMessages() {
    }

    public DeliverMessages(DeliverMessageEntry deliverMessageEntry) {
        this.deliverMessageEntry = deliverMessageEntry;
    }

    public DeliverMessageEntry getDeliverMessageEntry() {
        return deliverMessageEntry;
    }

    public void setDeliverMessageEntry(DeliverMessageEntry deliverMessageEntry) {
        this.deliverMessageEntry = deliverMessageEntry;
    }

    private DeliverMessageEntry deliverMessageEntry;
}

class DeliverMessageEntry {

    public DeliverMessageEntry() {
    }

    public DeliverMessageEntry(String message) {
        this.message = message;
    }

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

class Email {
    public Email() {
    }

    private String address;

    public String getAddress() {
        return address;
    }

    public Email(String address, String deliverPreference) {
        this.address = address;
        this.deliverPreference = deliverPreference;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDeliverPreference() {
        return deliverPreference;
    }

    public void setDeliverPreference(String deliverPreference) {
        this.deliverPreference = deliverPreference;
    }

    private String deliverPreference;
}

class Club {
    public Club() {
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberLevel() {
        return memberLevel;
    }

    public void setMemberLevel(String memberLevel) {
        this.memberLevel = memberLevel;
    }

    private String carrier;
    private String memberId;
    private String memberLevel;

    public Club(String carrier, String memberId, String memberLevel) {
        this.carrier = carrier;
        this.memberId = memberId;
        this.memberLevel = memberLevel;
    }


}

class Presentation {
    public Presentation() {
    }

    private Template template;

    public Template getTemplate() {
        return template;
    }

    public void setTemplate(Template template) {
        this.template = template;
    }
}

class Template {
    public Template() {
    }

    private String templateVersion;
    private String templateContent;

    public String getTemplateVersion() {
        return templateVersion;
    }

    public void setTemplateVersion(String templateVersion) {
        this.templateVersion = templateVersion;
    }

    public String getTemplateContent() {
        return templateContent;
    }

    public void setTemplateContent(String templateContent) {
        this.templateContent = templateContent;
    }
}
