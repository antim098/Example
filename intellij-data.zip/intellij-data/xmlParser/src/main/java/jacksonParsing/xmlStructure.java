package jacksonParsing;


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName = "ns:customer")
public class xmlStructure {
    // XmLElementWrapper generates a wrapper element around XML representation

    private String id;

    private String type;

    private String createTime;

    private String correlationId;

    private String expirationTime;

    @JacksonXmlElementWrapper(localName = "trace")
    private Trace trace;


    @JacksonXmlElementWrapper(localName = "log")
    private log Log;

    @JacksonXmlElementWrapper(localName = "target")
    private Target target;

    @JacksonXmlElementWrapper(localName = "operation")
    private Operation operation;

    @JacksonXmlElementWrapper(localName = "content")
    private Content content;

    public Target getTarget() {
        return target;
    }

    public void setTarget(Target target) {
        this.target = target;
    }


    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public log getLog() {
        return Log;
    }

    public void setLog(log log) {
        Log = log;
    }

    public String getType() {
        return type;
    }


    public void setType(String type) {
        this.type = type;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(String expirationTime) {
        this.expirationTime = expirationTime;
    }


    public Trace getTrace() {
        return trace;
    }

    public void setTrace(Trace trace) {
        this.trace = trace;
    }

    public Content getContent() {
        return content;
    }

    public void setContent(Content content) {
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public xmlStructure() {
    }


}




