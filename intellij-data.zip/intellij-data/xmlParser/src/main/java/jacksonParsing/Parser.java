package jacksonParsing;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class Parser {

    static int count = 0;


    public static ArrayList<String> separateJsonMessages(String filePath) {

        StringBuilder fileContent = new StringBuilder();
        try (FileReader fileReader = new FileReader(filePath); BufferedReader bufferedReader = new BufferedReader(fileReader)) {
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                fileContent.append(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Unable to open file \n Path Wrong or File Dosen't Exists");
        } catch (IOException e) {
            System.out.println("Error reading file ");
        }


        ArrayList<String> jsonMessages = new ArrayList<String>();
        String json = fileContent.toString();
        StringBuilder jsondata = new StringBuilder();
        int BracketCount = 0;
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '{')
                ++BracketCount;
            else if (c == '}')
                --BracketCount;
            jsondata.append(c);

            if (BracketCount == 0 && c != ' ') {
                jsonMessages.add(jsondata.toString());
                jsondata.setLength(0);

            }
        }

        return jsonMessages;
    }


    public static void setFlightDetails(FlightPOJO flightDetails, JSONObject ravenObj) {
        flightDetails.setFlightDate(String.valueOf(ravenObj.get("flightDate")));
        flightDetails.setArrivalStation(String.valueOf(ravenObj.get("arrivalStation")));
        flightDetails.setRecordLocator(String.valueOf(ravenObj.get("recordLocator")));
        flightDetails.setFlightNumber(String.valueOf(ravenObj.get("flightNumber")));
        flightDetails.setBagTags(String.valueOf(ravenObj.get("bagTags")));
        flightDetails.setMpNumber(String.valueOf(ravenObj.get("mpNumber")));
        flightDetails.setClaimNumber(String.valueOf(ravenObj.get("claimNumber")));
        flightDetails.setTemplateVersion(String.valueOf(ravenObj.get("templateVersion")));
        flightDetails.setDepartureStation(String.valueOf(ravenObj.get("departureStation")));

        //  return result;

    }


    public static Object xmlParser(String xml) {
        ObjectMapper objectMapper = new XmlMapper();

        // Reads from XML and converts to POJO

        xmlStructure xmlStructure = null;
        try {
            xmlStructure = objectMapper.readValue(

                    StringUtils.toEncodedString(xml.getBytes(), StandardCharsets.UTF_8),

                    xmlStructure.class);
        } catch (IOException e) {
            System.out.println("Error in reading input file");
        }


        return xmlStructure;
    }


    public static void main(String[] args) {
        FlightPOJO result = new FlightPOJO();
        String jsonContainigXML = "/home/impadmin/Downloads/XML Parsing/sampleMessages.json";
        ArrayList<String> jsonMessages = separateJsonMessages(jsonContainigXML);

        JSONObject data = null;

        int index = 0;
        while (index < jsonMessages.size()) {
            data = new JSONObject(jsonMessages.get(index));

            JSONObject ravenArray = (JSONObject) data.get("Raven");
            String messageData = String.valueOf(data.get("message"));

            result.setMessageType((String) data.get("messageType"));
            result.setMessageTimestamp((String) data.get("messageTimestamp"));
            setFlightDetails(result, ravenArray);

            System.out.println(xmlParser(messageData));

            index++;
        }


    }
}