package jacksonParsing;

public class Content {
    private ContentEntry contentEntry;

    public ContentEntry getContentEntry() {
        return contentEntry;
    }

    public Content() {
    }

    public void setContentEntry(ContentEntry contentEntry) {
        this.contentEntry = contentEntry;
    }
}

class ContentEntry {
    private String name;
    private String encoding;
    private String value;

    public ContentEntry() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public String getValue() {
        return value;
    }

    public ContentEntry(String name, String encoding, String value) {
        this.name = name;
        this.encoding = encoding;
        this.value = value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
