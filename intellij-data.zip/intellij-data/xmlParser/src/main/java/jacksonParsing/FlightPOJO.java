package jacksonParsing;

public class FlightPOJO {


    String messageType;
    String messageTimestamp;
    String recordLocator;
    String flightNumber;


    public FlightPOJO() {
    }

    String mpNumber;

    public FlightPOJO(String messageType, String messageTimestamp, String recordLocator, String flightNumber, String mpNumber, String departureStation, String arrivalStation, String flightDate, String templateVersion, String bagTags, String claimNumber) {
        this.messageType = messageType;
        this.messageTimestamp = messageTimestamp;
        this.recordLocator = recordLocator;
        this.flightNumber = flightNumber;
        this.mpNumber = mpNumber;
        this.departureStation = departureStation;
        this.arrivalStation = arrivalStation;
        this.flightDate = flightDate;
        this.templateVersion = templateVersion;
        this.bagTags = bagTags;
        this.claimNumber = claimNumber;
    }

    String departureStation;
    String arrivalStation;
    String flightDate;
    String templateVersion;
    String bagTags;
    String claimNumber;

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessageTimestamp() {
        return messageTimestamp;
    }

    public void setMessageTimestamp(String messageTimestamp) {
        this.messageTimestamp = messageTimestamp;
    }

    public String getRecordLocator() {
        return recordLocator;
    }

    public void setRecordLocator(String recordLocator) {
        this.recordLocator = recordLocator;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getMpNumber() {
        return mpNumber;
    }

    public void setMpNumber(String mpNumber) {
        this.mpNumber = mpNumber;
    }

    public String getDepartureStation() {
        return departureStation;
    }

    public void setDepartureStation(String departureStation) {
        this.departureStation = departureStation;
    }

    public String getArrivalStation() {
        return arrivalStation;
    }

    public void setArrivalStation(String arrivalStation) {
        this.arrivalStation = arrivalStation;
    }

    public String getFlightDate() {
        return flightDate;
    }

    public void setFlightDate(String flightDate) {
        this.flightDate = flightDate;
    }

    public String getTemplateVersion() {
        return templateVersion;
    }

    public void setTemplateVersion(String templateVersion) {
        this.templateVersion = templateVersion;
    }

    public String getBagTags() {
        return bagTags;
    }

    public void setBagTags(String bagTags) {
        this.bagTags = bagTags;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }
}


