package jacksonParsing;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

public class log {

    @JacksonXmlElementWrapper(localName = "logEntry", useWrapping = false)
    public LogEntry[] getLogEntry() {
        return logEntry;
    }

    public void setLogEntry(LogEntry[] logEntry) {
        this.logEntry = logEntry;
    }

    private LogEntry[] logEntry;

    public log() {
    }

    public log(LogEntry[] logEntry) {
        this.logEntry = logEntry;
    }
}

class LogEntry {

    private String timeStamp;
    private String level;
    private String code;
    private String message;

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LogEntry() {
    }

    public LogEntry(String timeStamp, String level, String code, String message) {
        this.timeStamp = timeStamp;
        this.level = level;
        this.code = code;
        this.message = message;
    }
}