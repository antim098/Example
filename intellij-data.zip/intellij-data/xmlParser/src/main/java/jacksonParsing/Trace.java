package jacksonParsing;


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName = "trace")
public class Trace {

    @JacksonXmlProperty(localName = "pnr")
    private String pnr;

    public Trace() {
    }

    @JacksonXmlElementWrapper(localName = "through", useWrapping = true)
    private through throughs;

    public through getThroughs() {
        return throughs;


    }

    public void setThroughs(through throughs) {
        this.throughs = throughs;
    }

    public String getPnr() {
        return pnr;
    }

    public void setPnr(String pnr) {
        this.pnr = pnr;
    }


}


class through {

    @JacksonXmlElementWrapper(localName = "process", useWrapping = false)
    private Process[] process;

    public Process[] getProcess() {
        return process;
    }

    public through(Process[] process) {
        this.process = process;
    }

    public through() {
    }

    public void setProcess(Process[] process) {
        this.process = process;
    }
}


class Process {

    private String timeIn;

    private String timeOut;

    @JacksonXmlElementWrapper(localName = "triggered", useWrapping = false)
    private Trigger[] triggered;

    private String name;

    private String triggerEvent;

    public Process() {
    }

    public Process(String timeIn, String timeOut, Trigger[] triggered, String name, String triggerEvent) {
        this.timeIn = timeIn;
        this.timeOut = timeOut;
        this.triggered = triggered;
        this.name = name;
        this.triggerEvent = triggerEvent;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTriggerEvent() {
        return triggerEvent;
    }

    public void setTriggerEvent(String triggerEvent) {
        this.triggerEvent = triggerEvent;
    }

    public String getTimeIn() {
        return timeIn;
    }

    public void setTimeIn(String timeIn) {
        this.timeIn = timeIn;
    }

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

    public Trigger[] getTriggered() {
        return triggered;
    }

    public void setTriggered(Trigger[] triggered) {
        this.triggered = triggered;
    }


}

class Trigger {


    private String rule;

    public Trigger() {
    }

    public Trigger(String rule) {
        this.rule = rule;
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule;
    }
}
