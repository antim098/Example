package com.impetus.ct.cassandra.connection;

import com.datastax.driver.core.*;

import static java.lang.System.out;

/**
 * Class used for connecting to Cassandra database.
 */
public class CassandraSession {
	/** Cassandra Cluster. */
	private Cluster cluster;
	/** Cassandra Session. */
	private Session session;

	/**
	 * Connect to Cassandra Cluster specified by provided node IP address and
	 * port number.
	 *
	 * @param port
	 *            Port of cluster host.
	 */
	public CassandraSession(final String ipAddress, final int port) {
		System.setProperty("com.datastax.driver.NATIVE_TRANSPORT_MAX_FRAME_SIZE_IN_MB", "2046");
		// configure socket options
		SocketOptions options = new SocketOptions();
		options.setConnectTimeoutMillis(900000000);
		options.setReadTimeoutMillis(900000000);
		options.setTcpNoDelay(true);

		this.cluster = Cluster.builder().addContactPoints(ipAddress).withPort(port)
				.withProtocolVersion(ProtocolVersion.V3)
				// .withQueryOptions(new
				// QueryOptions().setConsistencyLevel(ConsistencyLevel.QUORUM))
				.withSocketOptions(options).build();
		final Metadata metadata = cluster.getMetadata();
		out.printf("Connected to cluster: %s\n", metadata.getClusterName());
		for (final Host host : metadata.getAllHosts()) {
			out.printf("Datacenter: %s; Host: %s; Rack: %s\n", host.getDatacenter(), host.getAddress(), host.getRack());
		}
		session = cluster.connect();
	}

	/**
	 * Provide my Session.
	 *
	 * @return My session.
	 */
	public Session getSession() {
		return this.session;
	}

	/** Close cluster. */
	public void close() {
		cluster.close();
	}
}