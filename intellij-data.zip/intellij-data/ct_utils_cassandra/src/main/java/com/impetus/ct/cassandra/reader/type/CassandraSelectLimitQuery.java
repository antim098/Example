package com.impetus.ct.cassandra.reader.type;

import java.util.ArrayList;

import java.util.List;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.impetus.ct.cassandra.connection.CassandraSessions;
import com.impetus.ct.cassandra.reader.QueryOutputVO;
import com.impetus.ct.cassandra.reader.QueryParamVO;
import static com.impetus.ct.utils.Constants.*;

public class CassandraSelectLimitQuery implements CassandraQuery {

	@Override
	public void execute(QueryParamVO vo) {

		System.out.println("Input Query to be executed -- " + vo.getLimitQuery());

		final ExecutorService pool = Executors.newFixedThreadPool(new Integer(vo.getConcurrency()));
		final ExecutorCompletionService<QueryOutputVO> completionService = new ExecutorCompletionService<>(pool);

		String[] inputQueryArray = vo.getLimitQuery().split("limit");
		String newLimitQuery = inputQueryArray[0] + "limit ";

		String limitNumber = inputQueryArray[1].trim();
		String[] limitNumberArray = limitNumber.split(SPACE);

		Long queryLimitEnd = new Long(limitNumberArray[0].trim());
		String afterLimitString = SPACE;
		if (limitNumberArray.length > 1) {
			afterLimitString = SPACE + limitNumberArray[1] + SPACE + limitNumberArray[2];
		}
		Long fraction = queryLimitEnd / vo.getConcurrency();

		List<Future<QueryOutputVO>> futures = new ArrayList<>();

		long queryLimitStart = 0;
		while (queryLimitStart < queryLimitEnd) {
			String query = newLimitQuery + fraction + afterLimitString;
			SelectQueryCallable callable = new SelectQueryCallable(
					CassandraSessions.getRandomCassandraSession().getSession(), query, new Integer(vo.getBatchSize()));
			futures.add(completionService.submit(callable));

			// handle in case any limit is left less than fraction.
			queryLimitStart = queryLimitStart + fraction;
			if ((queryLimitEnd - queryLimitStart) < fraction && (queryLimitEnd - queryLimitStart) > 0) {
				queryLimitStart = queryLimitEnd - queryLimitStart;
				query = newLimitQuery + queryLimitStart;
				// ignor for left over records.
				queryLimitStart = queryLimitEnd;
			}
		}
		System.out.println("****** All queries submitted for processing ******");

		long resultCount = 0;
		long timeTaken = 0;
		QueryOutputVO outputVO = new QueryOutputVO();
		for (Future<QueryOutputVO> future : futures) {
			try {
				Future<QueryOutputVO> completedFuture = completionService.take();
				resultCount = resultCount + ((QueryOutputVO) completedFuture.get()).getRecordCount();
				outputVO.setRecordCount(resultCount);
				timeTaken = timeTaken + ((QueryOutputVO) completedFuture.get()).getTimeTaken();
				outputVO.setTimeTaken(timeTaken);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		CassandraSessions.closeSessions();
		pool.shutdown();
		pool.shutdownNow();
		System.out.println("****** " + outputVO.getRecordCount() + " Records fetched in "
				+ (outputVO.getTimeTaken() / futures.size()) + " ms");

	}
}