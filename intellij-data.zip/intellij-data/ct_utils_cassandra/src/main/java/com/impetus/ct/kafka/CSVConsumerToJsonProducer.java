package com.impetus.ct.kafka;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.common.base.Strings;
import static com.impetus.ct.utils.Constants.*;
import com.impetus.ct.cassandra.writer.bigfile.FileSplitProcessor;

/**
 * Producer to produce data on Kafka using multiple threads
 * 
 * @author vikas.gupta, Rajesh Paul
 *
 */
public class CSVConsumerToJsonProducer {

	private static final String[] schemaCols;
	private static final Duration CONSUMER_POLL_TIMEPUT = Duration.ofMillis(1000);
	private static FileSplitProcessor processor;

	static {
		schemaCols = SCHEMA.split(COMMA);
	}

	/**
	 * 
	 * @param args
	 *            args[0] - bootstrap server details (IP + Port) args[1] - Kafka
	 *            topic for input data args[2] - Kafka topic for output data
	 * 
	 */
	public static void main(String[] args) {

		String bootstrap_servers = args[0];
		String input_topic = args[1];
		String outputTopic = args[2];
		String pathToProperty = "";
		try {
			pathToProperty = args[3];
		} catch (Exception e) {
			System.out.println();
		}
		processor = new FileSplitProcessor(pathToProperty);

		try (KafkaConsumer<String, String> consumer = createKafkaConsumer(bootstrap_servers);
				KafkaProducer<String, String> producer = createKafkaProducer(bootstrap_servers);) {

			consumer.subscribe(Arrays.asList(input_topic));
			System.out.println("Kafka consumer subscribed to topic " + consumer.listTopics());

			while (true) {
				ConsumerRecords<String, String> consumerRecords = consumer.poll(CONSUMER_POLL_TIMEPUT);
				consumerRecords.forEach(consumerRecord -> {
					if (!consumerRecord.value().isEmpty() && consumerRecord.value() != null) {

						String[] split_val = consumerRecord.value().split(COMMA, -1);
						try {
							String fileType = split_val[198].trim();
							if (OFFLINE.equalsIgnoreCase(fileType)) {

								String filePath = split_val[200].trim();
								String documentId = split_val[201].trim();
								System.out.println(" :::: initiating Big File Split  :::: ");
								processor.process(documentId, filePath);
							}
						} catch (Exception e) {
							System.out.println("***Exception occurred in processing file split***");
							e.printStackTrace();
						}

						/**
						 * schema fields must be equal to fields in input record
						 * and (schema fields - 1) must be equal to number of
						 * delimiters in input record else reject the record
						 */
						if (schemaCols.length != split_val.length) {
							System.out.println(
									"Total number of columns in the record does not match with number of schema columns!!!");
							// DocId is 2nd last column as per above defined
							// schema
							System.out.println("Doc Id of skipped record: " + split_val[split_val.length - 2]);
						} else {
							convertAndPublish(outputTopic, producer, split_val);
						}
					}
				});
			}
		} catch (Exception e) {
			System.out.println("Exception occurred running the csv to json converter.");
			e.printStackTrace();
		}
	}

	private static void convertAndPublish(String output_topic, KafkaProducer<String, String> producer,
			String[] split_val) {
		JSONObject jsonRecord = new JSONObject();
		// prepare JSON from CSV record
		// TODO: convert to lambda expression
		for (int i = 0; i < split_val.length; i++) {
			if (!(Strings.isNullOrEmpty(split_val[i]))) {
				try {
					jsonRecord.put(schemaCols[i], split_val[i].trim());
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		}
		if (jsonRecord.length() > 0) {
			producer.send(new ProducerRecord<String, String>(output_topic, jsonRecord.toString()));
		}
	}

	private static KafkaProducer<String, String> createKafkaProducer(String bootstrap_servers) {
		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", bootstrap_servers);
		properties.setProperty("auto.offset.reset", "latest");
		// properties.setProperty("timeout.ms", "30000000");
		properties.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.setProperty("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		return new KafkaProducer<String, String>(properties);
	}

	private static KafkaConsumer<String, String> createKafkaConsumer(String bootstrap_servers) {
		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", bootstrap_servers);
		properties.setProperty("group.id", "ct_group");
		properties.setProperty("enable.auto.commit", "true");
		properties.setProperty("auto.commit.interval.ms", "10000");
		// properties.setProperty("session.timeout.ms", "30000000");
		properties.setProperty("key.deserializer", "org.apache.kafka.common.serialization.ByteArrayDeserializer");
		properties.setProperty("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		return new KafkaConsumer<String, String>(properties);
	}

}
