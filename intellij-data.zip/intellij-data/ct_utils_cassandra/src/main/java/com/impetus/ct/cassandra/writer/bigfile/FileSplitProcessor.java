package com.impetus.ct.cassandra.writer.bigfile;

import com.impetus.ct.PropertyReader;
import com.impetus.ct.ftp.SFTPSession;

import static com.impetus.ct.utils.FileStatus.*;

public class FileSplitProcessor {

	private final FileSplitExcecutor executor;

	public FileSplitProcessor(String propFilePath) {
		PropertyReader.initialize(propFilePath);
		executor = new FileSplitExcecutor();
	}

	public void process(String documentId, String ftpFilePath) {
		System.out.println(" :::: inside  Big File Split  :::: ");

		String destinationFilePath = PropertyReader.getPropertyValue("ftp.file.download.location");

		try {
			executor.insertFileProcessedStatus(documentId, ftpFilePath, DOWNLOAD_STARTED, destinationFilePath,
					SPLITTING_NOT_STARTED);
			boolean fileDownloadStatus = new SFTPSession().downloadFile(ftpFilePath, destinationFilePath);
			if (fileDownloadStatus) {
				executor.updateStatusRecord(documentId, DOWNLOAD_COMPLETED, SPLITTING_NOT_STARTED);
				executor.splitFile(documentId, ftpFilePath);
				executor.updateStatusRecord(documentId, DOWNLOAD_COMPLETED, SPLITTING_COMPLETED);

			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(" ::::: ==============> " + e.getMessage());
		} finally {
			executor.close();
		}
		System.out.println(" :::: exiting  Big File Split  :::: ");
	}

}
