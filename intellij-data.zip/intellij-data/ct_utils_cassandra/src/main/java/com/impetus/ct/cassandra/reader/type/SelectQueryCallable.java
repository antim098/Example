package com.impetus.ct.cassandra.reader.type;

import java.util.concurrent.Callable;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.SimpleStatement;
import com.datastax.driver.core.Statement;
import com.impetus.ct.cassandra.reader.QueryOutputVO;

public class SelectQueryCallable implements Callable<QueryOutputVO> {
	private Session session;
	private String query;
	private int resultsPerBatch;

	SelectQueryCallable(Session session, String query, int resultsPerBatch) {
		this.session = session;
		this.query = query;
		this.resultsPerBatch = resultsPerBatch;
	}

	@Override
	public QueryOutputVO call() throws Exception {
		long record_count = 0;
		QueryOutputVO outputVo = new QueryOutputVO();
		try {
			System.out.println(Thread.currentThread().getName()
					+ " - thread started executing the query (removed all parameters from where clause):- "
					+ (query.contains("where") ? (query.length() > 100) ? query.substring(0, 100) : query : query));
			Statement st = new SimpleStatement(query);
			st.setFetchSize(resultsPerBatch);
			long startTime = System.currentTimeMillis();

			ResultSet rs = session.execute(st);
			for (Row row : rs) {
				if (record_count > resultsPerBatch && (record_count % resultsPerBatch) == 0) {
					System.out.println(Thread.currentThread().getName()
							+ "****Processing. Number of records fetched till yet -  " + record_count);
				}
				record_count = record_count + 1;
			}
			long endTime = System.currentTimeMillis();
			outputVo.setTimeTaken((endTime - startTime));
			System.out.println(Thread.currentThread().getName()
					+ " - thread finished query (removed all parameters from where clause) "
					+ (query.contains("where") ? query.substring(0, 45) : query) + " execution on cluster "
					+ session.getCluster().getMetadata().getClusterName() + "  in time(ms) --" + (endTime - startTime));
		} catch (Exception e) {
			e.printStackTrace();
		}
		outputVo.setRecordCount(record_count);
		return outputVo;
	}

}