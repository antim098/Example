package com.impetus.ct.ftp;

import java.io.File;

import com.impetus.ct.PropertyReader;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class SFTPSession {

	private Session session;
	private Channel channel;
	private ChannelSftp sftpChannel;

	public void initialize() {
		System.out.println(" :::: inside connectFtpServer() :::: ");
		System.out.println("*** Started initializing the FTP session *******");

		try {
			String server = PropertyReader.getPropertyValue("ftp.serverip");
			String user = PropertyReader.getPropertyValue("ftp.username");
			String password = PropertyReader.getPropertyValue("ftp.password");
			int port = Integer.parseInt(PropertyReader.getPropertyValue("ftp.port"));
			JSch jsch = new JSch();

			session = jsch.getSession(user, server, port);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(password);
			session.connect();
			channel = session.openChannel("sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			if (!sftpChannel.isConnected()) {
				System.out.println("Could not login to the server" + server);
			} else {
				System.out.println("LOGGED IN SERVER" + server);
			}
		} catch (JSchException e) {
			System.out.println("*** Exception occurred in connecting to ftp server.*******");
			e.printStackTrace();
		} catch (Exception ex) {
			System.out.println("*** Exception occurred in connecting to ftp server.*******");
			ex.printStackTrace();
		}
		System.out.println("** FTP Channel connection successful*** ");
	}

	public boolean downloadFile(String filePath, String destinationFilePath) {
		System.out.println("** Started dowloading file *** ");
		boolean fileDownloadStatus = false;
		try {
			if (session == null && sftpChannel == null) {
				initialize();
			}
			sftpChannel.get(filePath, destinationFilePath);
		} catch (SftpException sftpe) {
			sftpe.printStackTrace();
			System.out.println("** Exception occurred in downloading file " + filePath);
			return fileDownloadStatus;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("** Exception occurred in downloading file " + filePath);
			return fileDownloadStatus;
		} finally {
			close();
		}
		System.out.println(" :::: File downloaded successfully - " + filePath + " :::: ");
		return fileDownloadStatus;
	}

	public void close() {
		sftpChannel.disconnect();
		channel.disconnect();
		session.disconnect();
	}
}
