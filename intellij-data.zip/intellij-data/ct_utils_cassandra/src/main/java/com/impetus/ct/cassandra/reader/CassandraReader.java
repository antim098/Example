package com.impetus.ct.cassandra.reader;

import java.util.Arrays;

import com.impetus.ct.cassandra.connection.CassandraSessions;
import com.impetus.ct.cassandra.reader.type.CassandraQuery;
import com.impetus.ct.cassandra.reader.type.CassandraQueryByDocumentId;
import com.impetus.ct.cassandra.reader.type.CassandraSelectLimitQuery;
import com.impetus.ct.cassandra.reader.type.CassandraSelectQuery;
import static com.impetus.ct.utils.Constants.*;

public class CassandraReader {
	

	public static void main(String[] args) {

		System.out.println("** Arguments Received  ***" + Arrays.toString(args));
		if (args.length < 1) {
			System.out.println("***** First Argument should be comma separated IP Address*****");
			return;
		}
		String cassandraHosts = args[0];
		System.out.println("Cassandra session is created using  hosts." + cassandraHosts);
		CassandraSessions.createCassandraSessions(9042, cassandraHosts.split(COMMA));
		System.out.println("Cassandra sessions created using  hosts." + cassandraHosts);

		String concurrency = args[1];
		String batchSize = args[2];
		String limitQueryOrTableName = args[3];

		if (limitQueryOrTableName.toLowerCase().contains("limit")) {
			QueryParamVO vo = new QueryParamVO(limitQueryOrTableName, batchSize, concurrency);
			CassandraQuery query = new CassandraSelectLimitQuery();
			query.execute(vo);
		} else if (limitQueryOrTableName.toLowerCase().contains("select")) {
			QueryParamVO vo = new QueryParamVO(limitQueryOrTableName, batchSize, concurrency);
			CassandraQuery query = new CassandraSelectQuery();
			query.execute(vo);
		} else if (limitQueryOrTableName.toLowerCase().contains(SPACE)) {
			String inputParamFileName = args[4];
			QueryParamVO vo = new QueryParamVO(inputParamFileName, limitQueryOrTableName, batchSize, concurrency);
			CassandraQuery query = new CassandraQueryByDocumentId();
			query.execute(vo);
		}
		System.out.println("** processing completed****");
	}
}
