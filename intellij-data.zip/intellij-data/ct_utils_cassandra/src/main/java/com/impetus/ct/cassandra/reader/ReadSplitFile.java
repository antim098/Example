/**
 * 
 */
package com.impetus.ct.cassandra.reader;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.SimpleStatement;
import com.impetus.ct.PropertyReader;
import com.impetus.ct.cassandra.connection.CassandraSessions;
import static com.impetus.ct.utils.FileStatus.*;

/**
 * @author nirmit.jain
 *
 */
public class ReadSplitFile {

	public static void main(String[] args) {
		System.out.println(
				" ::::: Pass Document id,File Path and Property file where you want to save retrived file ::::: ");
		String documentId = args[0];
		String filePath = args[1];
		try {
			String propertyFile = args[2];
			PropertyReader.initialize(propertyFile);
			readSplitFileByDocument(documentId, filePath);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println(" :::::: ====================> " + e.getMessage());
			System.exit(0);
		}
	}

	public static void readSplitFileByDocument(String documentId, String localFilePath) throws IOException {

		System.out.println(" :::: Inside getSplitFileByDocument() :::: ");

		String keyspace = PropertyReader.getPropertyValue("cassandra.keyspace");
		String splitTable = PropertyReader.getPropertyValue("cassandra.splitTableName");
		String queryTable = new StringBuilder(keyspace).append(".").append(splitTable).toString();

		Row processedRow = readStatusData(documentId);
		if (null != processedRow) {
			String processed = processedRow.getString("fileSplitProcessedStatus");
			if (processed.equals(SPLITTING_COMPLETED)) {
				String readSplitFileQuery = new StringBuilder("SELECT  documentId, fileName, splitNo, chunk from ")
						.append(queryTable).append(" where documentId = ?").toString();
				try (OutputStreamWriter outStream = new OutputStreamWriter(new FileOutputStream(localFilePath),
						"UTF-8");) {
					SimpleStatement ss = (SimpleStatement) new SimpleStatement(readSplitFileQuery)
							.setReadTimeoutMillis(65000);
					ss.setFetchSize(5);
					Session session = CassandraSessions
							.getCassandraSession(PropertyReader.getPropertyValue("cassandra.ipaddress"),
									new Integer(PropertyReader.getPropertyValue("cassandra.port")))
							.getSession();
					ResultSet rs = session.execute(ss);

					for (Row row : rs) {
						int splitNo = row.getInt("splitNo");
						String fileName = row.getString("fileName");
						String chunk = row.getString("chunk");

						outStream.write(chunk);
						System.out.println(
								" :::: Selected Chunk == " + splitNo + "; File Name == " + fileName + " :::: ");
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				System.out.println(" :::: Desired file for document Id - " + documentId + " not present in Table : "
						+ queryTable + " :::: ");
			}
		}

		System.out.println(" :::: exiting getSplitFileByDocument() :::: ");
	}

	public static Row readStatusData(String documentId) throws IOException {
		System.out.println(" :::: inside  readStatusData() :::: ");

		String keyspace = PropertyReader.getPropertyValue("cassandra.keyspace");
		String splitTable = PropertyReader.getPropertyValue("cassandra.statusTableName");
		String queryTable = new StringBuilder(keyspace).append(".").append(splitTable).toString();

		String readQuery = new StringBuilder("SELECT * FROM ").append(queryTable).append(" WHERE doc_Id = ?")
				.toString();

		System.out.println(" :::: Read record File Process status Query :: " + readQuery);

		Session session = CassandraSessions.getCassandraSession(PropertyReader.getPropertyValue("cassandra.ipaddress"),
				new Integer(PropertyReader.getPropertyValue("cassandra.port"))).getSession();
		PreparedStatement stmt = session.prepare(readQuery);

		ResultSet rs = session.execute(stmt.bind(documentId));
		if (null != rs.one()) {
			return rs.one();
		}

		System.out.println(" :::: exiting  readStatusData() :::: ");
		return null;

	}

}
