package com.impetus.ct.kafka.datatype;

import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.common.base.Strings;
import static com.impetus.ct.utils.Constants.*;

public class CSVToJsonProducerDataType extends ProducerDataType {

	String[] schemaCols = SCHEMA.split(COMMA);

	public CSVToJsonProducerDataType(String file_path, String topicName, Properties properties) {
		super(file_path, topicName, properties);
	}

	public String createKafkaMessage(String line) {

		// convert CSV record to JSON
		JSONObject json = new JSONObject();
		String trim_value = null;
		String[] split_val = line.split(COMMA, -1);

		/**
		 * schema fields must be equal to no. of fields in input record else
		 * reject the record
		 */
		if ((schemaCols.length != split_val.length)) {
			System.out.println("Total number of columns in the record does not match with number of schema columns!!!");
			// DocId is 2nd last column as per above defined schema
			System.out.println("Doc Id of skipped record: " + split_val[split_val.length - 2]);
		}

		// prepare JSON from CSV record
		for (int i = 0; i < split_val.length; i++) {
			trim_value = split_val[i].trim();

			if (!(Strings.isNullOrEmpty(trim_value))) {
				try {
					json.put(schemaCols[i], trim_value);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		}

		return json.toString();
	}

}
