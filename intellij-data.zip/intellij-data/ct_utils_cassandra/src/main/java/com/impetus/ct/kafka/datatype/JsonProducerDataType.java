package com.impetus.ct.kafka.datatype;

import java.util.Properties;

public class JsonProducerDataType extends ProducerDataType {
	String file_path;
	String topicName;
	Properties properties;

	public JsonProducerDataType(String file_path, String topicName, Properties properties) {
		super(file_path, topicName, properties);
	}

	@Override
	protected String createKafkaMessage(String line) {
		String message = line;
		message = message.replace("[{", "{");
		message = message.replace("},", "}");
		message = message.replace("}]", "}");
		return message.trim();
	}

}
