package com.impetus.ct.kafka.datatype;

import java.util.Properties;

public class CSVProducerDataType extends ProducerDataType {

	public CSVProducerDataType(String file_path, String topicName, Properties properties) {
		super(file_path, topicName, properties);
	}

}
