package com.impetus.ct.kafka.datatype;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.stream.Stream;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

public abstract class ProducerDataType implements Callable<String> {
	protected Charset charset = Charset.forName("UTF-8");
	protected String file_path;
	protected String topicName;
	protected Properties properties;

	public ProducerDataType(String file_path, String topicName, Properties properties) {
		this.file_path = file_path;
		this.topicName = topicName;
		this.properties = properties;
	}

	@Override
	public String call() {
		KafkaProducer<String, String> producer = new KafkaProducer<>(properties);
		long startTime = System.currentTimeMillis();
		System.out.println(Thread.currentThread().getName() + " - thread started processing file --" + file_path
				+ ".....Start Time" + startTime);

		try (Stream<String> stream = Files.lines(Paths.get(file_path))) {
			stream.forEach(line -> {
				ProducerRecord<String, String> kafkaProducerRecord = new ProducerRecord<String, String>(topicName, createKafkaMessage(line));
				producer.send(kafkaProducerRecord);
			});
		} catch (Exception e) {
			System.out.println(Thread.currentThread().getName() + "****** Exception occurred in sending file "
					+ file_path + " while writing data to topic *******");
			e.printStackTrace();
		} finally {
			producer.flush();
			producer.close();
		}
		long endTime = System.currentTimeMillis();
		System.out.println(Thread.currentThread().getName() + " - thread finished sending file " + file_path
				+ "  to producer in time(ms) --" + (endTime - startTime));
		return file_path;
	}

	protected String createKafkaMessage(String line) {
		return line;
	}
}
