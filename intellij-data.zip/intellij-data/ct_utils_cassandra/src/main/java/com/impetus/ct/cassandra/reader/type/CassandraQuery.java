package com.impetus.ct.cassandra.reader.type;

import com.impetus.ct.cassandra.reader.QueryParamVO;

public interface CassandraQuery {

	public void execute(QueryParamVO vo);
}
