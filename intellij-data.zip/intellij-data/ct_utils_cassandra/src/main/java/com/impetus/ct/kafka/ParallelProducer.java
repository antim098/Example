package com.impetus.ct.kafka;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.impetus.ct.kafka.datatype.CSVProducerDataType;
import com.impetus.ct.kafka.datatype.CSVToJsonProducerDataType;
import com.impetus.ct.kafka.datatype.JsonProducerDataType;
import com.impetus.ct.kafka.datatype.ProducerDataType;

/**
 * Producer to produce data on Kafka using multiple threads
 * 
 * @author vikas.gupta
 *
 */
public class ParallelProducer {
	private static ExecutorService pool = Executors.newFixedThreadPool(10);
	private static final ExecutorCompletionService<String> completionService = new ExecutorCompletionService<>(pool);

	public static void main(String[] args) throws IOException {
		/*
		 * ************* Command line params for this script: ************** 1st
		 * - Input data file format - CSV/JSON 2nd - Bootstrap server and port
		 * details 3rd - Directory path containing all input data files 4th -
		 * Kafka topic name
		 * *****************************************************************
		 */
		if (args.length != 4) {
			System.out.println(
					"***** The entered input params are either incorrect or files do not exist at given path *****");
			return;
		}
		String input_file_type = args[0];
		String bootstrap_servers = args[1];
		String file_path = args[2].trim();
		String topic_name = args[3];

		/**
		 * Check files in directory
		 */
		File[] files = new File(file_path).listFiles();
		System.out.println("***** No. of input data files (including directories) *****: " + files.length);

		if (files.length <= 0) {
			System.out.println("***** The input data files do not exist!!! ***** ");
			System.exit(0);
		}

		Properties properties = createKafkaProducerProperties(bootstrap_servers);

		List<Future<?>> futures = new ArrayList<>();
		for (File file : files) {
			if (file.isFile()) {
				System.out.println("****** Started processing file with name: " + file.getName());
				file_path = file_path + '/' + file.getName();
				ProducerDataType producer = null;
				if (input_file_type.equals("CSV")) {
					producer = new CSVProducerDataType(file_path, topic_name, properties);
				} else if (input_file_type.equals("CSVTOJSON")) {
					producer = new CSVToJsonProducerDataType(file_path, topic_name, properties);
				} else {
					producer = new JsonProducerDataType(file_path, topic_name, properties);
				}
				futures.add(completionService.submit(producer));
			}
		}
		System.out.println("****** All files submitted for processing ******");

		for (Future<?> future : futures) {
			try {
				completionService.take();
				System.out.println(future.get().toString() + " file content is published to Kafka");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		pool.shutdown();
		System.out.println("****** All data files processed successfully ******");
	}

	private static Properties createKafkaProducerProperties(String bootstrap_servers) {
		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", bootstrap_servers);
		properties.setProperty("auto.offset.reset", "latest");
		properties.setProperty("timeout.ms", "30000000");
		properties.setProperty("batch.size", "1000000");
		properties.setProperty("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.setProperty("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		return properties;
	}
}
