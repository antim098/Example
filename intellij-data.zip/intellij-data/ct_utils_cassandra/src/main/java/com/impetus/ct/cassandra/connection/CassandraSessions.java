package com.impetus.ct.cassandra.connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class CassandraSessions {

	private static final Map<String, CassandraSession> sessionByIpAddress = new HashMap<>();
	private static final List<CassandraSession> sessions = new ArrayList<>();
	private static AtomicInteger index;

	public static void createCassandraSessions(int port, String... ipAddressArray) {
		for (String ipAddress : ipAddressArray) {
			createCassandraSession(ipAddress, port);
		}
	}

	public List<CassandraSession> getAllSessions() {
		return new ArrayList<>(sessions);
	}

	public static CassandraSession getRandomCassandraSession() {
		CassandraSession session = sessions.get((index.get() % sessions.size()));
		if (session == null) {
			System.out.println("No existing connection. Initialize cassandra session..");
		}
		index.getAndIncrement();
		return session;
	}

	public static CassandraSession getCassandraSession(String ipAddress, int port) {
		CassandraSession session = sessionByIpAddress.get(ipAddress);
		if (session == null || session.getSession() == null) {
			session = createCassandraSession(ipAddress, port);
		}
		return session;
	}

	private static CassandraSession createCassandraSession(String ipAddress, int port) {
		CassandraSession session = new CassandraSession(ipAddress, port);
		sessionByIpAddress.put(ipAddress, session);
		sessions.add(session);
		return session;
	}

	public static int size() {
		return sessions.size();
	}

	public static void closeSession(String ipAddress) {
		CassandraSession session = sessionByIpAddress.get(ipAddress);
		session.close();
	}

	public static void closeSessions() {
		for (CassandraSession session : sessions) {
			session.close();
		}
	}
}
