package com.impetus.ct.cassandra.reader.type;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.impetus.ct.cassandra.connection.CassandraSessions;
import com.impetus.ct.cassandra.reader.QueryOutputVO;
import com.impetus.ct.cassandra.reader.QueryParamVO;

public class CassandraSelectQuery implements CassandraQuery {

	@Override
	public void execute(QueryParamVO vo) {

		System.out.println("Input Query to be executed -- " + vo.getLimitQuery());

		final ExecutorService pool = Executors.newFixedThreadPool(new Integer(vo.getConcurrency()));
		final ExecutorCompletionService<QueryOutputVO> completionService = new ExecutorCompletionService<>(pool);

		List<Future<QueryOutputVO>> futures = new ArrayList<>();

		for (int i = 0; i < vo.getConcurrency(); i++) {
			SelectQueryCallable callable = new SelectQueryCallable(CassandraSessions.getRandomCassandraSession().getSession(),
					vo.getLimitQuery(), new Integer(vo.getBatchSize()));
			futures.add(completionService.submit(callable));

		}
		System.out.println("****** All queries submitted for processing ******");

		long resultCount = 0;
		long timeTaken = 0;
		QueryOutputVO outputVO = new QueryOutputVO();
		for (Future<QueryOutputVO> future : futures) {
			try {
				Future<QueryOutputVO> completedFuture = completionService.take();
				resultCount = resultCount + ((QueryOutputVO) completedFuture.get()).getRecordCount();
				outputVO.setRecordCount(resultCount);
				timeTaken = timeTaken + ((QueryOutputVO) completedFuture.get()).getTimeTaken();
				outputVO.setTimeTaken(timeTaken);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		CassandraSessions.closeSessions();
		pool.shutdown();
		pool.shutdownNow();
		System.out.println("****** " + outputVO.getRecordCount() + " Records fetched in "
				+ (outputVO.getTimeTaken() / futures.size()) + " ms");

	}
}