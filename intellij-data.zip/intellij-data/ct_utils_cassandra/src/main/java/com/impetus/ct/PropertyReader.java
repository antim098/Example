package com.impetus.ct;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Properties;

/**
 * Initialize Properties as Singleton.
 * 
 * @author Vikas Gupta
 *
 */
public class PropertyReader {

	private static PropertyReader INSTANCE;
	private static Properties properties;

	private PropertyReader(String filePath) {
		properties = new Properties();
		try {
			if (filePath != null && !filePath.isEmpty()) {
				properties.load(new FileInputStream(filePath));
			} else {
				properties.load(PropertyReader.class.getClassLoader().getResourceAsStream("application.properties"));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getPropertyValue(String key) {
		return properties.getProperty(key);
	}

	/**
	 * @return
	 * @throws IOException
	 * @throws URISyntaxException
	 */
	public static PropertyReader initialize(String filePath) {
		if (null == INSTANCE) {
			synchronized (PropertyReader.class) {
				if (null == INSTANCE) {
					INSTANCE = new PropertyReader(filePath);
				}
			}
		}
		return INSTANCE;
	}
}