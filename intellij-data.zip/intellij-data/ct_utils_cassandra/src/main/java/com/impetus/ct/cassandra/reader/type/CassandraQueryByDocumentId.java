package com.impetus.ct.cassandra.reader.type;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import com.impetus.ct.cassandra.connection.CassandraSessions;
import com.impetus.ct.cassandra.reader.QueryOutputVO;
import com.impetus.ct.cassandra.reader.QueryParamVO;
import static com.impetus.ct.utils.Constants.*;

public class CassandraQueryByDocumentId implements CassandraQuery {

	@Override
	public void execute(QueryParamVO vo) {

		System.out.println("Input Query to be executed on table-- " + vo.getTableName());

		final ExecutorService pool = Executors.newFixedThreadPool(CassandraSessions.size() + 1);
		final ExecutorCompletionService<QueryOutputVO> completionService = new ExecutorCompletionService<>(pool);

		List<Future<QueryOutputVO>> futures = new ArrayList<>();

		final Set<String> documentIds = new HashSet<>();
		final Set<String> ingestDate = new HashSet<>();
		final Set<String> application = new HashSet<>();
		// read file into stream, try-with-resources
		final AtomicInteger atomicIndex = new AtomicInteger(1);
		try (Stream<String> stream = Files.lines(Paths.get(vo.getDocumentIdFileName()))) {
			long lineCount = Files.lines(Paths.get(vo.getDocumentIdFileName())).count();
			System.out.println("Total lines in file---" + lineCount);
			long fraction = lineCount / vo.getConcurrency();
			stream.forEach(line -> {
				String[] inputAsArray = line.split(",");
				documentIds.add(inputAsArray[0]);
				ingestDate.add(inputAsArray[1]);
				application.add(inputAsArray[2]);
				if (atomicIndex.get() == fraction) {
					// submit query
					String query = "select * from " + vo.getTableName() + " where documentingesttime in ("
							+ convertToQueryString(ingestDate) + ") and application in ("
							+ convertToQueryString(application) + ") and documentid in ("
							+ convertToQueryString(documentIds) + ")";
					SelectQueryCallable callable = new SelectQueryCallable(
							CassandraSessions.getRandomCassandraSession().getSession(), query,
							new Integer(vo.getBatchSize()));
					futures.add(completionService.submit(callable));
					atomicIndex.set(new Integer("1"));
					documentIds.clear();
					ingestDate.clear();
					application.clear();
				} else {
					atomicIndex.getAndIncrement();
				}
			});

			System.out.println("****** All queries submitted for processing ******");

			long resultCount = 0;
			long timeTaken = 0;
			QueryOutputVO outputVO = new QueryOutputVO();

			for (Future<QueryOutputVO> future : futures) {
				try {
					Future<QueryOutputVO> completedFuture = completionService.take();

					resultCount = resultCount + ((QueryOutputVO) completedFuture.get()).getRecordCount();
					outputVO.setRecordCount(resultCount);
					timeTaken = timeTaken + ((QueryOutputVO) completedFuture.get()).getTimeTaken();
					outputVO.setTimeTaken(timeTaken);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			System.out.println("****** " + outputVO.getRecordCount() + " Records fetched in "
					+ (outputVO.getTimeTaken() / futures.size()) + " ms");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			CassandraSessions.closeSessions();
			pool.shutdown();
			pool.shutdownNow();

		}

	}

	private String convertToQueryString(Set<String> inputSet) {
		long startTime = System.currentTimeMillis();
		StringBuilder builder = new StringBuilder("");
		for (String s : inputSet) {
			builder.append(QUOTE).append(s).append(QUOTE).append(COMMA);
		}
		String query = builder.toString();
		query = query.substring(0, query.length() - 1);
		long endTime = System.currentTimeMillis();
		System.out.println("Time Taken for list to convert to query is --" + (endTime - startTime));
		return query;
	}

}