package com.impetus.ct.cassandra.reader;

import java.io.Serializable;

public class QueryOutputVO implements Serializable {

	private static final long serialVersionUID = -5268529672039411131L;

	private long timeTaken = 0;

	private long recordCount = 0;

	public long getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(long timeTaken) {
		this.timeTaken = timeTaken;
	}

	public long getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(long record_count) {
		this.recordCount = record_count;
	}

}
