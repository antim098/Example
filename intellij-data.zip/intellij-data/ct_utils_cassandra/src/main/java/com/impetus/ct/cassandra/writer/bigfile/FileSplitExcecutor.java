package com.impetus.ct.cassandra.writer.bigfile;

import static com.impetus.ct.utils.FileStatus.DOWNLOAD_COMPLETED;
import static com.impetus.ct.utils.FileStatus.SPLITTING_STARTED;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Update;
import com.impetus.ct.PropertyReader;
import com.impetus.ct.cassandra.connection.CassandraSessions;
import com.impetus.ct.utils.FileStatus;

public class FileSplitExcecutor {

	private Session session;

	public FileSplitExcecutor() {
		session = CassandraSessions.getCassandraSession(PropertyReader.getPropertyValue("cassandra.ipaddress"),
				new Integer(PropertyReader.getPropertyValue("cassandra.port"))).getSession();
	}

	// TODO: remove prepared statement at class level
	private static PreparedStatement stmt;

	public void splitFile(String documentId, String ftpFilePath) throws IOException {
		System.out.println(" :::: Inside  loadFileFromLocal() :::: ");

		String keyspace = PropertyReader.getPropertyValue("cassandra.keyspace");
		String splitTable = PropertyReader.getPropertyValue("cassandra.splitTableName");
		int chunkSize = new Integer(PropertyReader.getPropertyValue("file.split.chunk.size"));

		String queryTable = new StringBuilder(keyspace).append(".").append(splitTable).toString();

		long startTime = System.currentTimeMillis();
		updateStatusRecord(documentId, DOWNLOAD_COMPLETED, SPLITTING_STARTED);

		insertSplittedFile(ftpFilePath, chunkSize, queryTable, documentId);

		long endTime = System.currentTimeMillis();
		System.out.println("Total time taken to split and insert file in (ms) ::: " + (endTime - startTime));

		System.out.println(" :::: exiting  loadFileFromLocal() :::: ");
	}

	private void insertSplittedFile(String ftpFilePath, int chunkSize, String queryTable, String documentId)
			throws IOException {
		System.out.println(" :::: Inside  insertSplittedFile() :::: ");

		String insertQuery = new StringBuilder("INSERT INTO ").append(queryTable).append(" ")
				.append("(documentId,fileName,splitNo,chunk) values(?,?,?,?) if not exists").toString();
		stmt = session.prepare(insertQuery);

		System.out.println(" :::: Insert Split File  Query :: " + insertQuery);

		File inputFile = new File(ftpFilePath);
		RandomAccessFile raf = new RandomAccessFile(inputFile, "r");
		long sourceSize = raf.length();

		int maxReadBufferSize = chunkSize * 1000000; // IN MB
		long numReads = sourceSize / maxReadBufferSize;
		long remainingBytes = sourceSize % maxReadBufferSize;

		int split = 0;
		for (int i = 0; i < numReads; i++) {

			split++;
			loadFile(inputFile, maxReadBufferSize, split, inputFile.getName(), documentId);
		}
		if (remainingBytes > 0) {
			System.err.println("last batch of bytes :: ");

		}
		raf.close();
		System.out.println(" :::: exiting  insertSplittedFile() :::: ");
	}

	public void loadFile(File file, long numBytes, int splitNo, String fName, String documentId) throws IOException {
		System.out.println(" :::: Inside  loadFile() :::: ");

		byte[] buffer = new byte[(int) numBytes];
		ByteBuffer buf = ByteBuffer.wrap(buffer);

		@SuppressWarnings("resource")
		FileInputStream in = new FileInputStream(file);
		int nextByteIn = in.getChannel().read(buf);

		if (nextByteIn != -1) {
			String fileChunk = new String(buffer, "UTF-8");
			try {
				System.out.println(" ::::: Inserting File Chunk ::::: " + splitNo);
				BoundStatement bound = new BoundStatement(stmt);
				session.execute(bound.bind(documentId, fName, splitNo, fileChunk));
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(" ::::: ====>" + e.getMessage());
				System.exit(0);
			}
		}
		System.out.println(" :::: exiting  loadFile() :::: ");

	}

	public void insertFileProcessedStatus(String doc_Id, String ftpFilePath, FileStatus fileDownloadStatus,
			String localFilePath, FileStatus fileSplitProcessedStatus) throws IOException {
		System.out.println(" :::: Inside  insertFileProcessedStatus() :::: ");

		String keyspace = PropertyReader.getPropertyValue("cassandra.keyspace");
		String splitTable = PropertyReader.getPropertyValue("cassandra.statusTableName");
		String queryTable = new StringBuilder(keyspace).append(".").append(splitTable).toString();

		String insertQuery = new StringBuilder("INSERT INTO ").append(queryTable).append(" ")
				.append("(doc_Id,fileLocation,fileDownloadStatus,localFilePath,fileSplitProcessedStatus) values(?,?,?,?,?)")
				.toString();

		System.out.println(" :::: Insert File Process status Query :: " + insertQuery);
		stmt = session.prepare(insertQuery);

		BoundStatement bound = new BoundStatement(stmt);
		session.execute(
				bound.bind(doc_Id, new File(ftpFilePath), fileDownloadStatus, localFilePath, fileSplitProcessedStatus));

		System.out.println(" :::: exiting  insertFileProcessedStatus() :::: ");
	}

	public void updateStatusRecord(String documentId, FileStatus fileDownloadStatus,
			FileStatus fileSplitProcessedStatus) throws IOException {
		System.out.println(" :::: inside  updateStatusRecord() :::: ");

		String keyspace = PropertyReader.getPropertyValue("cassandra.keyspace");
		String splitTable = PropertyReader.getPropertyValue("cassandra.statusTableName");
		String queryTable = new StringBuilder(keyspace).append(".").append(splitTable).toString();

		Update updateStmt = QueryBuilder.update(queryTable);
		updateStmt.with(QueryBuilder.set("fileDownloadStatus", QueryBuilder.bindMarker()));
		updateStmt.with(QueryBuilder.set("fileSplitProcessedStatus", QueryBuilder.bindMarker()));
		updateStmt.where(QueryBuilder.eq("doc_Id", QueryBuilder.bindMarker()));

		System.out.println(" :::: update status record Query :: " + updateStmt.toString());

		stmt = session.prepare(updateStmt);
		stmt.setConsistencyLevel(ConsistencyLevel.ALL);
		session.execute(stmt.bind(fileDownloadStatus, fileSplitProcessedStatus, documentId));

		System.out.println(" :::: exiting  updateStatusRecord() :::: ");
	}

	public void close() {
		session.close();
	}

}
