import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class parsing1 {

    static Map<Integer, String[]> customerNodes = new HashMap<>();
    static FileWriter writer = null;
    static int count = 0;

    public static void visitChildNodes(NodeList nList) {
        for (int temp = 0; temp < nList.getLength(); temp++) {
            count++;
            Node node = nList.item(temp);
            String nodeName = node.getNodeName();
            if (nodeName.startsWith("ns")) {
                if (node.getNodeType() == Node.ELEMENT_NODE) {

                    if (node.getTextContent().contains("\n")) {
                        // customerNodes.add("Parent Node  " + nodeName.substring(nodeName.indexOf(":") + 1));
                        // System.out.println("Node Name = " + nodeName);
                        // customerData.put(nodeName.substring(nodeName.indexOf(":")), new String[]{nodeName, "Parent Node"});
                    } else {
                        //   customerData.put(nodeName.substring(nodeName.indexOf(":")), new String[]{nodeName, node.getTextContent()});
                        customerNodes.put(count, new String[]{nodeName.substring(nodeName.indexOf(":") + 1), node.getTextContent()});
                        System.out.println("Node Name = " + nodeName + "   value =  " + node.getTextContent());
                    }
                    if (node.hasChildNodes()) {
                        // System.out.println(nodeName + "has child nodes");
                        //We got more childs; Let's visit them as well
                        visitChildNodes(node.getChildNodes());
                    }


                }
            }
        }
    }


    public static ArrayList<String> separateJsonMessages() {

        StringBuilder fileContent = new StringBuilder();
        try (FileReader fileReader = new FileReader("/home/impadmin/Downloads/XML Parsing/sampleMessages.json"); BufferedReader bufferedReader = new BufferedReader(fileReader)) {
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                fileContent.append(line);
            }
        } catch (FileNotFoundException e) {
            // log.error("Unable to open file {} \n Path Wrong or File Dosen't Exists", filePath);
        } catch (IOException e) {
            //  log.error("Error reading file {}", filePath);
            // Or we could just do this:
        }

        //   System.out.println("\n\n\n" + fileContent.toString());
        ArrayList<String> jsonMessages = new ArrayList<String>();
        String json = fileContent.toString();
        StringBuilder jsondata = new StringBuilder();
        int BracketCount = 0;
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '{')
                ++BracketCount;
            else if (c == '}')
                --BracketCount;
            jsondata.append(c);

            if (BracketCount == 0 && c != ' ') {
                jsonMessages.add(jsondata.toString());
                jsondata.setLength(0);

            }
        }

        return jsonMessages;
    }


    public static void setRavenValues(ResultPOJO result, JSONObject ravenObj) {
        result.setFlightDate(String.valueOf(ravenObj.get("flightDate")));
        result.setArrivalStation(String.valueOf(ravenObj.get("arrivalStation")));
        result.setRecordLocator(String.valueOf(ravenObj.get("recordLocator")));
        result.setFlightNumber(ravenObj.getString("flightNumber"));
        result.setBagTags(String.valueOf(ravenObj.get("bagTags")));
        result.setMpNumber(String.valueOf(ravenObj.get("mpNumber")));
        result.setClaimNumber(String.valueOf(ravenObj.get("claimNumber")));
        result.setTemplateVersion(String.valueOf(ravenObj.get("templateVersion")));
        result.setFlightNumber(String.valueOf(ravenObj.get("flightNumber")));
        //  return result;

    }


    public static void setCustomerValues(ResultPOJO result, ArrayList<String> customers) {
        //  result.setPNR(customers.get(customers.indexOf("")));


/*        result.setFlightDate(String.valueOf(ravenObj.get("flightDate")));
        result.setArrivalStation(String.valueOf(ravenObj.get("arrivalStation")));
        result.setRecordLocator(String.valueOf(ravenObj.get("recordLocator")));
        result.setFlightNumber(ravenObj.getString("flightNumber"));
        result.setBagTags(String.valueOf(ravenObj.get("bagTags")));
        result.setMpNumber(String.valueOf(ravenObj.get("mpNumber")));
        result.setClaimNumber(String.valueOf(ravenObj.get("claimNumber")));
        result.setTemplateVersion(String.valueOf(ravenObj.get("templateVersion")));
        result.setFlightNumber(String.valueOf(ravenObj.get("flightNumber")));*/
        //  return result;

    }


    public static void xmlParser(String xml) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        // factory.setValidating(true);
        factory.setIgnoringElementContentWhitespace(true);
        DocumentBuilder builder = null;
        Document doc = null;
        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        //  File file = new File("/home/impadmin/Downloads/XML Parsing/RavenNote-2HR.xml");
        try {
            InputSource is = new InputSource(new StringReader(xml));
            is.setEncoding("ISO-8859-1");
            doc = builder.parse(is);
        } catch (SAXException e2) {
            e2.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }

        final Element root = doc.getDocumentElement();
        NodeList nList = root.getElementsByTagName("ns:customer");
        System.out.println(root);
        System.out.println("Length of list " + nList.getLength());
        visitChildNodes(nList);

    }


    public static void main(String[] args) {
        ResultPOJO result = new ResultPOJO();
        ArrayList<String> jsonMessages = separateJsonMessages();

        JSONObject data = null;
        //ustomerNodes.indexOf(customerNodes.)
        data = new org.json.JSONObject(jsonMessages.get(0));

        JSONObject ravenArray = (JSONObject) data.get("Raven");
        String messageData = String.valueOf(data.get("message"));
        System.out.println(messageData);
        System.out.println(ravenArray);
        result.setMessageType((String) data.get("messageType"));
        result.setMessageTimestamp((String) data.get("messageTimestamp"));
        setRavenValues(result, ravenArray);


        System.out.println(result.arrivalStation);
        System.out.println(result.messageType);
        System.out.println(result.flightNumber);
        System.out.println(result.recordLocator);

        xmlParser(messageData);
        // setCustomerValues(result, customerNodes);


        //String xml = XML.toString(messageData);
        //System.out.println(messageData.toString());


        /*String val = jsonMessages.get(0);
        System.out.println(val);*/


/*        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        // factory.setValidating(true);
        factory.setIgnoringElementContentWhitespace(true);
        DocumentBuilder builder = null;
        Document doc = null;
        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        //  File file = new File("/home/impadmin/Downloads/XML Parsing/RavenNote-2HR.xml");
        try {
            InputSource is = new InputSource(new StringReader(messageData.toString()));
            is.setEncoding("ISO-8859-1");
            doc = builder.parse(is);
        } catch (SAXException e2) {
            e2.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }


        final Element root = doc.getDocumentElement();

        System.out.println(doc.getTextContent()
        );
        NodeList nList = root.getElementsByTagName("ns2:customer");*/


        //  System.out.println(nList.item(0));
        //  System.out.println("Length of list " + nList.getLength());
        //  visitChildNodes(nList);

   /*     Iterator itr = customerNodes.listIterator();
        while (itr.hasNext()) {
            System.out.println(itr.next());
        }

        System.out.println(customerNodes.size());


   */
        Path path = Paths.get("/home/impadmin/Downloads/XML Parsed Data/parsed.txt");

        //  Iterator<Map.Entry<Integer, String[]>> iter = customerNodes.entrySet().iterator();
        customerNodes.forEach((k, v) -> System.out.println("Key is  " + k + "  Value is  " + v[0] + "  " + v[1]));

        /*while (customerData.entrySet().iterator().hasNext()) {
            System.out.println(customerData.entrySet().iterator().next().getKey() + "   "+customerData.entrySet().iterator().next().getValue());
        */

  /*      try {
            writer = new FileWriter(path.toFile());
            for (Object str : customerNodes) {
                writer.write("\n" + str.toString());
            }

            writer.close();

        } catch (IOException e3) {
            e3.printStackTrace();


        }*/

        /*    JSONParser parser = new JSONParser();
            //Use JSONObject for simple JSON and JSONArray for array of JSON.
            JSONObject data = null;//path to the JSON file.
            try {
                data = (JSONObject) parser.parsse(
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            String json = data.toJSONString();
            System.out.println(json);
*/
        // System.out.println(customerData.size());


    }
}