import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class parsing {
    static Map<String, String> customerData = new HashMap<String, String>();
    static ArrayList<String> customerNodes = new ArrayList<>();


    public static void main(String[] args) {

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        // factory.setValidating(true);
        factory.setIgnoringElementContentWhitespace(true);
        DocumentBuilder builder = null;
        Document doc = null;
        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        File file = new File("/home/impadmin/Downloads/XML Parsing/RavenNote-2HR.xml");
        try {
            doc = builder.parse(file);
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        final Element root = doc.getDocumentElement();
        NodeList nList = root.getChildNodes();

        //System.out.println(root.getNodeName());
        //NodeList nList = root.getElementsByTagName("target");
        System.out.println(nList.item(0));
        System.out.println("Length of list " + nList.getLength());

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node node = nList.item(temp);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                System.out.println("Node Name = " + node.getNodeName());
                if (node.getNodeName().equals("ns2:target")) {
                    NodeList targetChilds = node.getChildNodes();
                    visitChildNodes(targetChilds);
                    getAttributeValues(targetChilds);
                }
            }
        }

     /*   customerNodes.forEach(x -> {
            NodeList n = root.getElementsByTagName(x);
            for (int i = 0; i < n.getLength(); i++) {
                Node nitem = n.item(i);
                if (nitem.getNodeName().equals("ns2:customer")) {
                } else {
                    if (nitem.hasAttributes() == false &&
                            nitem.getNodeType() == Node.ELEMENT_NODE)
                        if (nitem.getTextContent().contains("\n")) {
                            customerData.put(nitem.getNodeName(), "Parent Node");
                        } else {
                            customerData.put(nitem.getNodeName(), n.item(i).getTextContent());
                        }
                }
            }
        });*/

        customerNodes.forEach(x -> System.out.println(x));

        customerData.forEach((k, v) -> System.out.println("Key = "
                + k + ", Value = " + v));


    }

    private static void getAttributeValues(NodeList targetChilds) {
        for (int t = 0; t < targetChilds.getLength(); t++) {
            Node node = targetChilds.item(t);


        }
    }

    private static void visitChildNodes(NodeList nList) {
        for (int t = 0; t < nList.getLength(); t++) {
            Node node = nList.item(t);
            String nodeName = node.getNodeName();

            while (node.getNextSibling() != null) {
               Node sibling =node.getNextSibling();
                if (sibling.getNodeName().startsWith("ns")) {
                    customerNodes.add(nodeName);

                    if (node.hasAttributes() == false &&
                            node.getNodeType() == Node.ELEMENT_NODE) {
                        if (node.getTextContent().contains("\n")) {
                            customerData.put(nodeName, "empty");

                        } else {
                            customerData.put(nodeName, node.getTextContent());

                        }
                    }
                }
            }
                /*    if (node.hasAttributes()) {
                    // get attributes names and values
                    NamedNodeMap nodeMap = node.getAttributes();
                    for (int i = 0; i < nodeMap.getLength(); i++) {
                        Node tempNode = nodeMap.item(i);
                        System.out.println("Attr name : " + tempNode.getNodeName() + "; Value = " + tempNode.getNodeValue());
                    }*/
            if (node.hasChildNodes()) {
                // System.out.println(nodeName + "has child nodes");
                //We got more childs; Let's visit them as well
                visitChildNodes(node.getChildNodes());
            }

            //   customerData.put(node.getNodeName().re, node.getTextContent());
            //   System.out.println("Attr name : " + node.getNodeName() + ":Value" + node.getTextContent());
            //  System.out.println("length"+customerParams.getLength());
        }
    }
}


//Check all attributes
       /*         if (node.hasAttributes()) {
                    // get attributes names and values
                    NamedNodeMap nodeMap = node.getAttributes();
                    for (int i = 0; i < nodeMap.getLength(); i++) {
                        Node tempNode = nodeMap.item(i);
                        System.out.println("Attr name : " + tempNode.getNodeName() + "; Value = " + tempNode.getNodeValue());
                    }
                    if (node.hasChildNodes()) {
                        //We got more childs; Let's visit them as well
                        visitChildNodes(node.getChildNodes());
                    }
                }*/



