import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.File;
import java.io.IOException;

public class xpath_xml {


    public static void main(String[] args) {

        DocumentBuilderFactory domFactory =
                DocumentBuilderFactory.newInstance();
        domFactory.setIgnoringElementContentWhitespace(true);
        domFactory.setNamespaceAware(true);
        DocumentBuilder builder = null;
        try {
            builder = domFactory.newDocumentBuilder();
            File file = new File("/home/impadmin/Downloads/XML Parsing/RavenNote-2HR.xml");
            Document doc = builder.parse(file);
            XPath xpath = XPathFactory.newInstance().newXPath();
            XPathExpression expr = xpath.compile("/ns2:target/ns2:customer/ns:pnrId");


            Object result = expr.evaluate(doc, XPathConstants.NODESET);
            NodeList nodes = (NodeList) result;
            for (int i = 0; i < nodes.getLength(); i++) {
                System.out.println("hello");
                System.out.println(nodes.item(i).getNodeName());
            }
        } catch (ParserConfigurationException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (XPathExpressionException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }


        // XPath Query for showing all nodes value


    }
}
