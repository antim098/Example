package DemoParsing;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class parser {

    public static void main(String[] args) throws IOException {

        ObjectMapper objectMapper = new XmlMapper();

        // Reads from XML and converts to POJO

        Employees employees = objectMapper.readValue(

                StringUtils.toEncodedString(Files.readAllBytes(Paths.get("./src/main/java/employees.xml")), StandardCharsets.UTF_8),

                Employees.class);

        System.out.println(employees);

        // Reads from POJO and converts to XML

      //  objectMapper.writeValue(new File("./src/main/java/employees.xml"), fieldSet);

    }

}
