package com.impetus.ct.cassandra.query;

import com.impetus.ct.cassandra.QueryParamVO;
import com.impetus.ct.cassandra.connection.CassandraSessions;

public interface CassandraQuery {

	public void execute(QueryParamVO vo, CassandraSessions sessions);
}
