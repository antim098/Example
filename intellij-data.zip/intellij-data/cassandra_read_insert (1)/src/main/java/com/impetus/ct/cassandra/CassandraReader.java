package com.impetus.ct.cassandra;

import java.util.Arrays;

import com.impetus.ct.cassandra.connection.CassandraSessions;
import com.impetus.ct.cassandra.query.CassandraQuery;
import com.impetus.ct.cassandra.query.CassandraQueryByDocumentId;
import com.impetus.ct.cassandra.query.CassandraSelectQuery;

public class CassandraReader {
	public static void main(String[] args) {

		System.out.println("** Arguments Received  ***" + Arrays.toString(args));
		if (args.length < 1) {
			System.out.println("***** First Argument should be comma separated IP Address*****");
			return;
		}
		String cassandraHosts = args[0];
		System.out.println("Cassandra session is created using  hosts." + cassandraHosts);
		CassandraSessions sessions = new CassandraSessions(9042, cassandraHosts.split(","));
		System.out.println("Cassandra sessions created using  hosts." + cassandraHosts);

		String concurrency = args[1];
		String batchSize = args[2];
		String limitQueryOrTableName = args[3];

		if (limitQueryOrTableName.toLowerCase().contains("limit")) {
			QueryParamVO vo = new QueryParamVO(limitQueryOrTableName, batchSize, concurrency);
			CassandraQuery query = new CassandraSelectQuery();
			query.execute(vo, sessions);
		} else if (limitQueryOrTableName.toLowerCase().contains(".")) {
			String inputParamFileName = args[4];
			QueryParamVO vo = new QueryParamVO(inputParamFileName, limitQueryOrTableName, batchSize, concurrency);
			CassandraQuery query = new CassandraQueryByDocumentId();
			query.execute(vo, sessions);
		}
		System.out.println("** processing completed****");
	}
}
