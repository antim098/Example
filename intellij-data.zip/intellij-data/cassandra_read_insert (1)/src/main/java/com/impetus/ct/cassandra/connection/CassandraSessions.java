package com.impetus.ct.cassandra.connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CassandraSessions {

	private Map<String, CassandraSession> sessionByIpAddress = new HashMap<>();
	private List<CassandraSession> sessions = new ArrayList<>();
	private int index;

	public CassandraSessions(int port, String... ipAddressArray) {
		for (String ipAddress : ipAddressArray) {
			final CassandraSession session = new CassandraSession(ipAddress, port);
			sessionByIpAddress.put(ipAddress, session);
		}
		sessions = new ArrayList<>(sessionByIpAddress.values());
	}

	public List<CassandraSession> getAllSessions() {
		return sessions;
	}

	public CassandraSession getCassandraSession() {
		this.index = this.index % this.sessions.size();
		CassandraSession session = this.sessions.get(this.index);
		this.index++;
		return session;
	}

	public CassandraSession getCassandraSession(String ipAddress) {
		return this.sessionByIpAddress.get(ipAddress);
	}

	public int size() {
		return sessions.size();
	}

	public void closeSessions() {
		for (CassandraSession session : sessions) {
			session.close();
		}
	}
}
