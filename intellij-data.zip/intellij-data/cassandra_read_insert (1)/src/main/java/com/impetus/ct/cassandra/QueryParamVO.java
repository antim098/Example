package com.impetus.ct.cassandra;

import java.io.Serializable;

public class QueryParamVO implements Serializable {

	private static final long serialVersionUID = -5268529672039411131L;

	private String limitQuery = "";

	private String batchSize;

	private int concurrency;

	private String documentIdFileName;

	private String tableName;

	public QueryParamVO(String limitQuery, String batchSize, String concurrency) {
		this.limitQuery = limitQuery;
		this.batchSize = batchSize;
		this.concurrency = new Integer(concurrency);
	}

	public QueryParamVO(String documentIdFileName, String tableName, String batchSize, String concurrency) {
		this(tableName, batchSize, concurrency);
		this.documentIdFileName = documentIdFileName;
		this.tableName = tableName;
	}

	public String getLimitQuery() {
		return limitQuery;
	}

	public String getDocumentIdFileName() {
		return documentIdFileName;
	}

	public String getTableName() {
		return tableName;
	}

	public String getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(String batchSize) {
		this.batchSize = batchSize;
	}

	public int getConcurrency() {
		return concurrency;
	}
}
