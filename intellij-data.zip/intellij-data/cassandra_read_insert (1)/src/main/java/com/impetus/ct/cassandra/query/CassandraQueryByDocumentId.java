package com.impetus.ct.cassandra.query;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Stream;

import com.impetus.ct.cassandra.QueryParamVO;
import com.impetus.ct.cassandra.connection.CassandraSessions;

public class CassandraQueryByDocumentId implements CassandraQuery {

	@Override
	public void execute(QueryParamVO vo, CassandraSessions sessions) {

		System.out.println("Input Query to be executed on table-- " + vo.getTableName());

		final ExecutorService pool = Executors.newFixedThreadPool(sessions.size() + 1);
		final ExecutorCompletionService<Long> completionService = new ExecutorCompletionService<>(pool);

		List<Future<Long>> futures = new ArrayList<>();

		Map<String, String> documentIdsbyPartitionColumns = new HashMap<>();

		// read file into stream, try-with-resources
		try (Stream<String> stream = Files.lines(Paths.get(vo.getDocumentIdFileName()))) {

			stream.forEach(line -> {
				String[] inputAsArray = line.split(",");
				documentIdsbyPartitionColumns.put(inputAsArray[0], line);
			});

		} catch (Exception e) {
			System.out.println(Thread.currentThread().getName() + "****** Exception occurred in reading file "
					+ vo.getDocumentIdFileName() + "*******");
			e.printStackTrace();
		}

		Set<String> documentIds = new HashSet<>();
		Set<String> ingestDate = new HashSet<>();
		Set<String> application = new HashSet<>();
		long documentIdSize = documentIdsbyPartitionColumns.keySet().size();
		long index = 1;
		long fraction = documentIdSize / vo.getConcurrency();
		for (String documentId : documentIdsbyPartitionColumns.keySet()) {
			String partitionColumns = documentIdsbyPartitionColumns.get(documentId);
			documentIds.add(documentId);
			String[] inputAsArray = partitionColumns.split(",");
			ingestDate.add(inputAsArray[0]);
			application.add(inputAsArray[1]);
			if (index == fraction) {
				// submit query

				String query = "select * from " + vo.getTableName() + " where documentingesttime in ("
						+ convertToQueryString(ingestDate) + ") and application in ("
						+ convertToQueryString(application) + ") and documentid in ("
						+ convertToQueryString(documentIds) + ")";
				SelectQueryCallable callable = new SelectQueryCallable(sessions.getCassandraSession().getSession(),
						query, new Integer(vo.getBatchSize()));
				futures.add(completionService.submit(callable));

				index = 1;
				documentIds.clear();
				ingestDate.clear();
				application.clear();
			}
			index = index + 1;
		}
		System.out.println("****** All queries submitted for processing ******");

		long resultCount = 0;
		for (Future<Long> future : futures) {
			try {
				Future<Long> completedFuture = completionService.take();
				resultCount = resultCount + (long) completedFuture.get();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		sessions.closeSessions();
		pool.shutdown();
		pool.shutdownNow();
		System.out.println("****** Total Records fetched are: " + resultCount);

	}

	private String convertToQueryString(Set<String> inputSet) {
		String queryString = "";
		for (String s : inputSet) {
			queryString = queryString + "'" + s + "',";
		}

		queryString = queryString.substring(0, queryString.length() - 1);
		return queryString;
	}

}