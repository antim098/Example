package com.impetus.ct.cassandra.query;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.impetus.ct.cassandra.QueryParamVO;
import com.impetus.ct.cassandra.connection.CassandraSessions;

public class CassandraSelectQuery implements CassandraQuery {

	@Override
	public void execute(QueryParamVO vo, CassandraSessions sessions) {

		System.out.println("Input Query to be executed -- " + vo.getLimitQuery());

		final ExecutorService pool = Executors.newFixedThreadPool(new Integer(vo.getConcurrency()));
		final ExecutorCompletionService<Long> completionService = new ExecutorCompletionService<>(pool);

		String[] inputQueryArray = vo.getLimitQuery().split("limit");
		String newLimitQuery = inputQueryArray[0] + "limit ";

		Long queryLimitEnd = new Long(inputQueryArray[1].trim());
		Long fraction = queryLimitEnd / vo.getConcurrency();

		List<Future<Long>> futures = new ArrayList<>();

		long queryLimitStart = 0;
		while (queryLimitStart < queryLimitEnd) {
			String query = newLimitQuery + fraction;
			SelectQueryCallable callable = new SelectQueryCallable(sessions.getCassandraSession().getSession(), query,
					new Integer(vo.getBatchSize()));
			futures.add(completionService.submit(callable));

			// handle in case any limit is left less than fraction.
			queryLimitStart = queryLimitStart + fraction;
			if ((queryLimitEnd - queryLimitStart) < fraction && (queryLimitEnd - queryLimitStart) > 0) {
				queryLimitStart = queryLimitEnd - queryLimitStart;
				query = newLimitQuery + queryLimitStart;
				// ignor for left over records.
				queryLimitStart = queryLimitEnd;
			}
		}
		System.out.println("****** All queries submitted for processing ******");

		long resultCount = 0;
		for (Future<Long> future : futures) {
			try {
				Future<Long> completedFuture = completionService.take();
				resultCount = resultCount + (long) completedFuture.get();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		sessions.closeSessions();
		pool.shutdown();
		pool.shutdownNow();
		System.out.println("****** Total Records fetched are: " + resultCount);

	}
}